rm(list = ls())
setwd('./')
if (! dir.exists('./08_GSEA')){
  dir.create('./08_GSEA')
}
setwd('./08_GSEA')

# 所有样本
# 相关性分析 --------------------------------------------------------------------
library(magrittr)
expr <- read.csv(file = "../00_rawdata/01.fpkm.log_GSE221521.csv", check.names = F, row.names = 1) 
gene <- read.csv('../06_expression/03.hubgene.csv', check.names = F, row.names = 1)
gene <- gene$x
group <- read.csv('../00_rawdata/01.group_GSE221521.csv')

gene_expr <- expr[gene,group$sample] %>% t %>% as.data.frame
allgene_expr <- expr[,group$sample] %>% t %>% as.data.frame
identical(rownames(gene_expr),rownames(allgene_expr))
cor_res <- cor(gene_expr, allgene_expr,method = "spearman") %>% t %>% as.data.frame #注意相关性分析输入文件格式

library(clusterProfiler)
library(enrichplot)
library(org.Hs.eg.db)
trace(gseaplot2,edit = T)
#GSEA
j <- 0
for (num in 1:length(gene)){
  i <- gene[num]
  #i <- gene[1]
  print(i)
  j <- j+1
  dat <- data.frame(row.names = rownames(cor_res),
                    cor=cor_res[,i])
  data_sort <- dat %>% dplyr::arrange(desc(cor)) %>% na.omit()#desc降序
  
  geneList <- data_sort$cor
  names(geneList) <- rownames(data_sort) #注意GSEA输入文件格式
  
  # # GOBP ------------------------------------------------------------------
  # go_set<- read.gmt("/data/nas1/liky/database/enrichment/c5.go.bp.v2023.1.Hs.symbols.gmt")
  # set.seed(1)
  # go_gsea <- GSEA(geneList, TERM2GENE = go_set, pvalueCutoff = 1) #adjp0.05有基因得不到结果
  # go_result <- go_gsea@result
  # go_result <- go_result[go_result$pvalue < 0.05,]
  # go_result <- go_result[order(go_result$pvalue, decreasing = F),]
  # write.csv(go_result,paste0('0',j,'.GSEA(gobp)_result_',i,'.csv'),row.names = F)
  # 
  # #trace(gseaplot2,edit = T)
  # gsea <- gseaplot2(go_gsea,c(1:5),color = c('#7B68EE','#CD3333','#20B2AA','#FF8C00','#FF6666'),
  #                   title = i,
  #                   base_size = 11,
  #                   rel_heights = c(1.5, 0.3, 0.5))
  # gsea
  # png(paste0('0',j,'.GSEA(gobp)_',i,'.png'),w=8,h=5,family='Times',units = "in",res = 600)
  # print(gsea)
  # dev.off()
  # pdf(paste0('0',j,'.GSEA(gobp)_',i,'.pdf'),w=8,h=5,family='Times')
  # print(gsea)
  # dev.off()
  # 
  # # GOCC ------------------------------------------------------------------
  # go_set<- read.gmt("/data/nas1/liky/database/enrichment/c5.go.cc.v2023.1.Hs.symbols.gmt")
  # set.seed(1)
  # go_gsea <- GSEA(geneList, TERM2GENE = go_set, pvalueCutoff = 1) #adjp0.05有基因得不到结果
  # go_result <- go_gsea@result
  # go_result <- go_result[go_result$pvalue < 0.05,]
  # go_result <- go_result[order(go_result$pvalue, decreasing = F),]
  # write.csv(go_result,paste0('0',j,'.GSEA(gocc)_result_',i,'.csv'),row.names = F)
  # 
  # #trace(gseaplot2,edit = T)
  # gsea <- gseaplot2(go_gsea,c(1:5),color = c('#7B68EE','#CD3333','#20B2AA','#FF8C00','#FF6666'),
  #                   title = i,
  #                   base_size = 11,
  #                   rel_heights = c(1.5, 0.3, 0.5))
  # gsea
  # png(paste0('0',j,'.GSEA(gocc)_',i,'.png'),w=8,h=5,family='Times',units = "in",res = 600)
  # print(gsea)
  # dev.off()
  # pdf(paste0('0',j,'.GSEA(gocc)_',i,'.pdf'),w=8,h=5,family='Times')
  # print(gsea)
  # dev.off()
  # 
  # # GOMF ------------------------------------------------------------------
  # go_set<- read.gmt("/data/nas1/liky/database/enrichment/c5.go.mf.v2023.1.Hs.symbols.gmt")
  # set.seed(1)
  # go_gsea <- GSEA(geneList, TERM2GENE = go_set, pvalueCutoff = 1) #adjp0.05有基因得不到结果
  # go_result <- go_gsea@result
  # go_result <- go_result[go_result$pvalue < 0.05,]
  # go_result <- go_result[order(go_result$pvalue, decreasing = F),]
  # write.csv(go_result,paste0('0',j,'.GSEA(gomf)_result_',i,'.csv'),row.names = F)
  # 
  # #trace(gseaplot2,edit = T)
  # gsea <- gseaplot2(go_gsea,c(1:5),color = c('#7B68EE','#CD3333','#20B2AA','#FF8C00','#FF6666'),
  #                   title = i,
  #                   base_size = 11,
  #                   rel_heights = c(1.5, 0.3, 0.5))
  # gsea
  # png(paste0('0',j,'.GSEA(gomf)_',i,'.png'),w=8,h=5,family='Times',units = "in",res = 600)
  # print(gsea)
  # dev.off()
  # pdf(paste0('0',j,'.GSEA(gomf)_',i,'.pdf'),w=8,h=5,family='Times')
  # print(gsea)
  # dev.off()
  # 
  # 
  # KEGG ------------------------------------------------------------------
  kegg_set<- read.gmt("../../../c2.cp.kegg.v2023.1.Hs.symbols.gmt")
  set.seed(1)
  kegg_gsea <- GSEA(geneList, TERM2GENE = kegg_set, pvalueCutoff = 1)
  kegg_result <- kegg_gsea@result
  kegg_result <- kegg_result[kegg_result$p.adjust < 0.05,]
  kegg_result <- kegg_result[order(kegg_result$p.adjust, decreasing = F),]
  write.csv(kegg_result,paste0('0',j,'.GSEA(kegg)_result_',i,'.csv'),row.names = F)
  
  #trace(gseaplot2,edit = T)
  dim(kegg_result)
  sortKEGG<-data.frame(kegg_result)
  sortKEGG<-sortKEGG[order(abs(sortKEGG$NES), decreasing = T),]#按照enrichment score从高到低排序
  paths <- rownames(sortKEGG[c(1:5),])#选取你需要展示的通路ID
  # 特定通路作图
  #trace(gseaplot2,edit=T)
  p = gseaplot2(kegg_gsea,paths,base_size =12,color = c('#7B68EE','#CD3333','#20B2AA','#FF8C00','#FF6666'),rel_heights = c(1.5, 0.3, 0.5),title=i)
  fn1 = paste0("0", j, ".", i, ".png")
  fn2 = paste0("0", j, ".", i,".pdf")
  png(fn1,w=8,h=6,units = "in",res = 600, family='Times')
  print(p)
  dev.off()
  pdf(fn2,w=8,h=6,family='Times')
  print(p)
  dev.off()
}
#包列表----
pkgs<-lapply(sessionInfo()$otherPkgs,function(x){x$Version}) %>% as.data.frame() %>%t()
write.table(pkgs,'pkgs.tsv',quote = F,sep = '\t',col.names=F)


