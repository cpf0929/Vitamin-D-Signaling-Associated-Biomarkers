rm(list=ls())
 
setwd('./')
if (! dir.exists("./14.scRNA")){
  dir.create("./14.scRNA")
}
setwd("./14.scRNA")

# 01.CreateSeurat  --------
if (! dir.exists("./01_rawdata")){
  dir.create("./01_rawdata")
}
setwd('./01_rawdata/')
dir <- './GSE248284_RAW/'
options(stringsAsFactors = F) 
library(Seurat)
library(ggplot2)
library(clustree)
library(cowplot)
library(dplyr)
library(data.table)
library(stringr)
# 批量读取10X文件；
#创建seurat List（sceList）；merge生成一个大的细胞基因表达矩阵

samples=list.files(dir)#该路径为保存每个样本对应的10X文件（细胞基因表达矩阵）；
## list.files为展示该路径下的文件
samples
source('/nas1/wangdengdong/pub/notice.r')
# sceList相当于一个个样本细胞基因表达矩阵的列表；lapply批量读取
sceList = lapply(samples,function(pro){ 
  #pro=samples[1]
  folder=file.path(dir,pro ) 
  # print(pro)
  # print(folder)
  # print(list.files(folder))
  # print( Sys.time() )
  sce=CreateSeuratObject(counts = Read10X(folder), 
                         min.cells = 3, min.features = 200,
                         project = paste0(pro) ) # 此处很关键的是Read10X针对的是标准三文件；
  #pro可用相应的样本文件夹名描述；此处的project代表细胞基因表达矩阵中metadata的orig.ident
  print( Sys.time() )
  return(sce)
})
notify('CreateSeuratObject')
sceList
# 16391 features across 5664 samples within 1 assay 
# 16753 features across 7002 samples within 1 assay 
# 17394 features across 9171 samples within 1 assay 

## 利用merge函数，将sceList的一个个细胞基因表达矩阵列表，合并成一个大的基因表达矩阵
scRNA = merge(sceList[[1]], y = sceList[-1], 
                add.cell.ids = samples,#在合并的列名前加上样本信息，如下
                merge.data = TRUE)
length(colnames(scRNA)) #cell 21837
length(rownames(scRNA)) #gene 18246

colnames(sceList[[1]]@assays$RNA)[1:6]
colnames(scRNA@assays$RNA)[1:6] #可以看见，通过add.cell.ids组别信息加到列名上去了；
## （后续其中的组别信息可以从中直接提取）

head(scRNA@meta.data, 10) # 看细胞注释信息meta.data的前10行
table(scRNA@meta.data$orig.ident)  #统计metadat中的orig.ident（样本来源信息--样本名（文件夹名））
#table(scRNA$orig.ident)#上一行代码的简写方式
# GSM7910933 GSM7910934 GSM7910935 
# 5664       7002       9171 
Patients_ID <- tstrsplit(rownames(scRNA@meta.data), "_", fixed = TRUE)[[1]] #samples
scRNA$group <- Patients_ID ##meta.data加入 #samples组别
## 为节约内存，通常会以rds的形式保存下一步运行的关键变量，
## 下一步运行时，加载时只需加载相应保存的关键变量即可运行
saveRDS(scRNA,file = 'scRNA.all.rds') 
#命名中，all代表merge成一个大的基因表达矩阵，raw代表未进行过滤，为原始表达矩阵



# 02 QC-----
setwd('./')
if (! dir.exists("./02_QC")){
  dir.create("./02_QC")
}
setwd("./02_QC")
scRNA<-readRDS('../01_rawdata/scRNA.all.rds')
# 01 计算线粒体基因比例 （人和鼠的基因名称不一样，人为英文字母全大写，小鼠为英文字母开头大写）
#str_to_upper() 转换成全大写；str_to_title()转换成开头大写
mito_genes=rownames(scRNA)[grep("^mt-", rownames(scRNA))] #抓取线粒体基因命名的开头
mito_genes #character(0) 0个线粒体基因 （看有没有抓取到相应的线粒体基因）
scRNA=PercentageFeatureSet(scRNA, "^mt-", col.name = "percent_mt")# 计算线粒体基因百分比

#02 QC 1 可视化质控前的质控指标情况-----
feats <- c("nFeature_RNA", "nCount_RNA") #, "percent_mt"没有线粒体基因
p1=VlnPlot(scRNA, group.by = "orig.ident", features = feats, pt.size = 0.005, ncol = 2) + 
  NoLegend() #绘制小提琴图，指定feats； pt.size代表点的大小；ncol代表2列
p1
library(ggplot2)
ggsave("01.vlnplot_before_qc.pdf", plot = p1, width = 10, height = 5)
ggsave("01.vlnplot_before_qc.png", plot = p1, width = 10, height = 5,dpi = 600)
write.csv(list(cell=length(colnames(scRNA)),gene=length(rownames(scRNA))),'01.before_qc_data.csv')

## 绘制nFeatrey与nCount两个指标之间的相关性图；越高代表测序越好
p3=FeatureScatter(scRNA, "nCount_RNA", "nFeature_RNA", group.by = "orig.ident", pt.size = 0.5)
p3
ggsave(filename="Scatterplot.pdf",plot=p3)


#02 QC 2 根据上述5个质控指标，过滤低质量细胞/基因-------
### 质控后 ###
### 设置质控标准
minGene=quantile(scRNA$nFeature_RNA,.02)
maxGene=quantile(scRNA$nFeature_RNA,.98)
maxUMI=quantile(scRNA$nCount_RNA,.95)
minUMI=quantile(scRNA$nCount_RNA,.02)
minGene;maxGene;maxUMI;minUMI
# 2% # 345 
# 98% # 3296.56 
# 95% # 12104.6
#2% #674.72
pctMT=5
minGene=200
maxGene=5000
maxUMI=30000 #表达量之和分子数
minUMI=200
scRNA.org<-scRNA
#length(colnames(scRNA))   #cell
#[1] 21837
#length(rownames(scRNA)) #gene
#[1] 18246
dim(scRNA.org)
#[1] 18246 21837
scRNA <- subset(scRNA.org, subset =
                  nCount_RNA < maxUMI &
                  nCount_RNA > minUMI & 
                  nFeature_RNA > minGene &
                  nFeature_RNA < maxGene &
                  percent_mt < pctMT )
dim(scRNA)
#[1] 18246 21738
if(F){
## 21 过滤指标1:最少表达基因数的细胞&最少表达细胞数的基因（先过滤两个指标）
selected_c <- WhichCells(scRNA, expression = nFeature_RNA > 300) #每个细胞至少表达300个基因
selected_f <- rownames(scRNA)[Matrix::rowSums(scRNA@assays$RNA@counts > 0 ) > 3]# 每个基因至少在3个细胞中表达
scRNA.filt <- subset(scRNA, features = selected_f, cells = selected_c) #subset取符合条件的（过滤）
dim(scRNA) # 查看过滤前的情况
dim(scRNA.filt) # filt代表过滤后，查看过滤后的情况
table(scRNA@meta.data$orig.ident) # 查看过滤前的每个样本细胞组成情况
table(scRNA.filt@meta.data$orig.ident) # 查看过滤后的每个样本细胞组成情况（看每个样本的过滤情况）
#  可以看到，主要是过滤了基因，其次才是细胞
}
# 质控后小提琴图
#feats <- c("nFeature_RNA", "nCount_RNA") #, "percent_mt"没有线粒体基因
p2=VlnPlot(scRNA, group.by = "orig.ident", features = feats, pt.size = 0.005, ncol = 2) + 
  NoLegend() #绘制小提琴图，指定feats； pt.size代表点的大小；ncol代表2列
p2
library(ggplot2)
ggsave("02.vlnplot_after_qc.pdf", plot = p2, width = 10, height = 5)
ggsave("02.vlnplot_after_qc.png", plot = p2, width = 10, height = 5,dpi = 600)
write.csv(list(cell=length(colnames(scRNA)),gene=length(rownames(scRNA))),'02.after_qc_data.csv')

system.time(save(scRNA, file = "scRNA_qc.Rdata"))
#包列表----
pkgs<-lapply(sessionInfo()$otherPkgs,function(x){x$Version}) %>% as.data.frame() %>%t()
write.table(pkgs,'pkgs.tsv',quote = F,sep = '\t',col.names=F)




