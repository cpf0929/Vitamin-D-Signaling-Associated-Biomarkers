rm(list = ls())
setwd('./')
if (! dir.exists('./09_mRNALocater')){
  dir.create('./09_mRNALocater')
}
setwd('./09_mRNALocater')

library(ggplot2)
library(lance)
mydata<-read.delim2('./00.mRNALocater.csv')%>% lc.tableToNum()
colnames(mydata)[1]<-'x'
#RAB23-----
mydata1 <- mydata[,c(1,2)]
mydata1$x = factor(mydata1$x,levels=mydata1$x,ordered = T)
head(mydata1)
nrow(mydata1)
library(RColorBrewer)
mypalette <- colorRampPalette(brewer.pal(7,"Paired"))
p <- ggplot(mydata1,
            aes(x=x,y=RAB23, fill=x)) +  #x、y轴定义；根据type填充颜色
  geom_bar(stat="identity", width=0.8) +  #柱状图宽度
  scale_fill_manual(values = mypalette(12) ) + #柱状图填充颜色
  xlab("") + #x轴标签
  ylab("score") +  #y轴标签
  labs(title = " Subceliular locations of RAB23")+ #设置标题
  theme_bw() +
  theme(text=element_text(family="Times",size = 15))+
  theme(legend.position='none')+
  theme(axis.text.x=element_text(family="Times",face = "bold", color="black",angle = 60,vjust = 1, hjust = 1 )) 
p

ggsave(filename = '01.RAB23.pdf',w=6,h=6)
ggsave(filename = '01.RAB23.png',w=6,h=6,units='in', dpi = 600)
dev.off()


#SLC36A1-----
mydata1 <- mydata[,c(1,3)]
mydata1$x = factor(mydata1$x,levels=mydata1$x,ordered = T)
head(mydata1)
p <- ggplot(mydata1,
            aes(x=x,y=SLC36A1, fill=x)) +  #x、y轴定义；根据type填充颜色
  geom_bar(stat="identity", width=0.8) +  #柱状图宽度
  scale_fill_manual(values = mypalette(12)) + #柱状图填充颜色
  xlab("") + #x轴标签
  ylab("score") +  #y轴标签
  labs(title = " Subceliular locations of SLC36A1")+ #设置标题
  theme_bw() +
  theme(text=element_text(family="Times",size = 15))+
  theme(legend.position='none')+
  theme(axis.text.x=element_text(family="Times",face = "bold", color="black",angle = 60,vjust = 1, hjust = 1 )) 
p

ggsave(filename = '01.SLC36A1.pdf',w=6,h=6)
ggsave(filename = '01.SLC36A1.png',w=6,h=6,units='in', dpi = 600)
dev.off()
#ctd disease ----
library(dplyr)
#library(lance)
library(readr)
library(ggplot2)
library(RColorBrewer)
h1<-read.delim2('SLC36A1_CTD_206358_diseases_20240529221239.tsv')%>% mutate(Inference.Score=as.numeric(Inference.Score))%>%arrange(desc(Inference.Score))%>%head(n=5)
h2<-read.delim2('RAB23_CTD_51715_diseases_20240529221447.tsv')%>% mutate(Inference.Score=as.numeric(Inference.Score))%>%arrange(desc(Inference.Score))%>%head(n=5)
pd.df<-data.frame(Disease=c(h1$Disease.Name,h2$Disease.Name),Inference.Score=c(h1$Inference.Score,h2$Inference.Score),gene=c(rep('SLC36A1',5),rep('RAB23',5)))
ncol<-length(unique(pd.df$Disease))
pd<-ggplot(pd.df,aes(x=gene,y=Inference.Score,fill=Disease))+
  geom_bar(stat = "identity",position = "dodge",width = 0.8,alpha=0.7)+
  theme_bw()+
  scale_fill_manual(values=brewer.pal(ncol, "Set3"))+
  theme(axis.title.x =element_text(size=22,color='black', face = "bold",family='Times'),
        axis.text.x =element_text(size=18,angle = 40,vjust = 1,hjust=1,color='black', face = "bold",family='Times'),
        axis.title.y =element_text(size=22,color='black', face = "bold",family='Times'),
        axis.text.y=element_text(size=18,  color='black',face = "bold",family='Times'),
        legend.title=element_text(size=20, color='black', face = "bold",family='Times'),
        legend.text=element_text(size=14, color='black', face = "bold",family='Times'),
        title=element_text(size=20, color='black', face = "bold",family='Times'),
        strip.text = element_text(size = 14,color='black',family = "Times", face = "bold"),
        legend.position = "bottom")+
  theme(panel.grid.major=element_blank(),panel.grid.minor=element_blank())+
  labs(x="Genes",y="Inference Score",fill="")
pd
ggsave('02.ctd.pdf',pd,w=10,h=8)
ggsave('02.ctd.png',pd,w=10,h=8,dpi=300)

#包列表----
pkgs<-lapply(sessionInfo()$otherPkgs,function(x){x$Version}) %>% as.data.frame() %>%t()
write.table(pkgs,'pkgs.tsv',quote = F,sep = '\t',col.names=F)
