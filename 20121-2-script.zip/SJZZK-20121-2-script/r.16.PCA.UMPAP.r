rm(list=ls())
setwd('./')
if (! dir.exists("./14.scRNA")){
  dir.create("./14.scRNA")
}
setwd("./14.scRNA")
if (! dir.exists("./04_PCA")){
  dir.create("./04_PCA")
}
setwd("./04_PCA")
load('../03_Normalize/scRNA_normalization.Rdata')

# 04.PCA####------------
scRNA <- ScaleData(scRNA) 
scRNA <- RunPCA(scRNA ,npcs = 50,pc.genes=VariableFeatures(object =scRNA) ) #PCA分析
# PC_ 1 
# Positive:  CD3E, TRBC2, IL32, TRAC, CD3D, CD7, IFITM1, CD69, CD3G, GZMM 
# LDHB, CD2, CD247, TRBC1, IL7R, ISG20, TCF7, SPOCK2, CTSW, LTB 
# EEF1A1, CD27, FCMR, CCL5, CST7, CD6, RPS12, GZMA, NKG7, ITM2A 
# Negative:  FCN1, CST3, SERPINA1, LYZ, SPI1, LST1, TYMP, FGL2, CTSS, GRN 
# TMEM176B, S100A9, CD68, PSAP, CFP, FCER1G, MNDA, CFD, AIF1, CSTA 
# NCF2, FTH1, MPEG1, MS4A6A, HCK, FTL, TNFAIP2, CD14, BRI3, CYBB 
# PC_ 2 
# Positive:  CD79A, MS4A1, BANK1, IGHD, IGHM, LINC00926, FCRLA, SPIB, FCER2, VPREB3 
# TCL1A, CD79B, CD22, HLA-DOB, HLA-DQA1, CD19, POU2AF1, TNFRSF13C, P2RX5, BLK 
# PKIG, BLNK, HLA-DQA2, LTB, EAF2, IGKC, FAM129C, CD24, GNG7, CD40 
# Negative:  NKG7, CST7, PRF1, GZMA, CTSW, FGFBP2, GZMH, KLRD1, GNLY, GZMB 
# EFHD2, CCL5, CD247, HOPX, GZMM, S100A4, ADGRG1, SPON2, FCGR3A, KLRF1 
# MATK, ANXA1, CCL4, S1PR5, TBX21, SRGN, TTC38, TRDC, FCRL6, CLIC3 
# PC_ 3 
# Positive:  TMSB10, EEF1A1, RPLP1, RPS12, CD37, RPLP0, CD79A, CD74, MS4A1, CD79B 
# CYBA, IGHD, HLA-DQA1, IGHM, FCER2, LINC00926, HLA-DQA2, HLA-DPB1, VPREB3, FCRLA 
# SPIB, TCL1A, HLA-DPA1, HLA-DQB1, CD22, LTB, P2RX5, POU2AF1, HVCN1, HLA-DOB 
# Negative:  TUBB1, SDPR, GNG11, GP9, ACRBP, PF4, SPARC, PPBP, CMTM5, C6orf25 
# CLU, TREML1, MYL9, NRGN, TMEM40, PTCRA, HIST1H2AC, CLDN5, ITGA2B, TSC22D1 
# PRKAR2B, RGS18, MAP3K7CL, C2orf88, SMOX, MTURN, CLEC1B, GMPR, HRAT92, F13A1 
# PC_ 4 
# Positive:  TCF7, IL7R, LEF1, MAL, LDHB, CD27, NOSIP, TRABD2A, CCR7, TRAC 
# RCAN3, AQP3, NELL2, FLT3LG, PIK3IP1, LDLRAP1, RGS10, EPHX2, CD3D, CD3E 
# LTB, RGCC, RP11-18H21.1, C1orf228, TRAT1, LINC01550, ACTN1, SIRPG, LRRN3, ITM2A 
# Negative:  GZMB, HLA-DPB1, HLA-DPA1, PRF1, NKG7, CST7, FGFBP2, GNLY, KLRD1, GZMA 
# GZMH, CD74, CXXC5, CLIC1, SPON2, FCGR3A, MS4A1, CD79B, CCL5, HLA-DQA2 
# KLRF1, HOPX, HLA-DQA1, CD79A, CYBA, ADGRG1, BANK1, EFHD2, CTSW, SPIB 
# PC_ 5 
# Positive:  CDKN1C, HES4, CKB, TCF7L2, CTSL, LINC01272, CTD-2006K23.1, SIGLEC10, NEURL1, MS4A4A 
# ZNF703, ICAM4, CEACAM3, BATF3, FCGR3A, CDH23, RRAS, LYPD2, CSF1R, C1QA 
# HMOX1, RHOC, LRRC25, MS4A7, CAMK1, FAM110A, IFITM3, IFI30, NR4A1, MTSS1 
# Negative:  S100A12, VCAN, S100A8, CD14, CSF3R, NCF1, S100A9, MS4A6A, CLEC4E, RBP7 
# CXCL8, PLBD1, CD36, ALDH2, LINC00937, MCEMP1, CD163, CRISPLD2, RNASE6, QPCT 
# ALDH1A1, ITGAM, CYP1B1, CAPG, MGST1, PTAFR, RNASE2, LYZ, TREM1, LGALS2 
theme.set = theme(
  #axis.title.x=element_blank(),
  axis.title = element_text(size = 20, face = "bold", family = "Times"),
  axis.text.x = element_text(size = 14,  face = "bold", family = "Times"),
  axis.text.y = element_text(size = 14,  face = "bold", family = "Times"),
  legend.text = element_text(size = 16, face = "bold", family = "Times"),
  legend.title = element_text(size = 18,face='bold',family = "Times"),
  text = element_text(family = "Times"))


##ElbowPlot,碎石图 根据ElbowPlot确定PC数量-------
pdf(file="01.ElbowPlot.pdf",width=6,height=5)
ElbowPlot(scRNA,reduction="pca",ndims = 50) +theme.set #根据ElbowPlot确定PC数量
dev.off()

png(file="01.ElbowPlot.png",width=6,height=5,units='in',res=600)
ElbowPlot(scRNA,reduction="pca",ndims = 50)+theme.set
dev.off()

##主成分分析图形
pdf("02.PCA_group.pdf",w=7,h=5)
DimPlot(scRNA, reduction = "pca",group.by = 'group',
        cols = c('#ECA8A9','#74AED4','#D3E2B7','#CFAFD4','#F7C97E','#FFFF99'))+theme.set
dev.off()
png("02.PCA_group.png",w=7,h=5,units = 'in',res = 600)
DimPlot(scRNA, reduction = "pca",group.by = 'group',
        cols = c('#ECA8A9','#74AED4','#D3E2B7','#CFAFD4','#F7C97E','#FFFF99'))+theme.set
dev.off()

scRNA.org<-scRNA
## PCA折线图
source('../../../notice.r')
scRNA <- JackStraw(scRNA, num.replicate = 100, dims = 50)
notify('JackStraw')
scRNA <- ScoreJackStraw(scRNA, dims = 1:50)
plot_pca <- JackStrawPlot(scRNA, dims = 1:50)
plot_pca #虚线以上是算法建议分成的组数。
ggsave(filename = '02.pca_cluster.pdf',plot_pca,w=13,h=8)
ggsave(filename = '02.pca_cluster.png',plot_pca,w=13,h=8,dpi = 600)

system.time(save(scRNA, file = "scRNA_pca.Rdata"))

# 05.UMAP---------
rm(list = ls())
setwd('../')
if (! dir.exists("./05_UMAP")){
  dir.create("./05_UMAP")
}
setwd("./05_UMAP")
load('../04_PCA/scRNA_pca.Rdata')

pcSelect=20
#细胞聚类 
scRNA <- FindNeighbors(object = scRNA, dims = 1:pcSelect)                #计算邻接距离
##对细胞分组,优化标准模块化
##这里的0.5决定了细胞亚群的多少，Seurat官网推荐0.4-1.2都可以进行尝试。数字越小，细胞亚群越少
##resolution参数表达聚类的分辨率，这个值大于0，一般都是在0-1范围里面调整，越大得到的cluster越多
#resolution可以反复调整，并不会改变降维的结果
#计算SNN
scRNA <- FindClusters(object = scRNA, resolution = 0.4)                  
# UMAP非线性降维分析 
scRNA  <- RunUMAP(scRNA , dims = 1:pcSelect)

library(tidyverse)
library(scales)
library(ggsci)
library(RColorBrewer)
library(IOBR)
library(grDevices)

getPalette = colorRampPalette(brewer.pal(12, "Set3")) 
##所有样本可视化
theme.set = theme(
  #axis.title.x=element_blank(),
  axis.title = element_text(size = 20, face = "bold", family = "Times"),
  axis.text.x = element_text(size = 18,  face = "bold", family = "Times"),
  axis.text.y = element_text(size = 18,  face = "bold", family = "Times"),
  legend.text = element_text(size = 18, face = "bold", family = "Times"),
  legend.title = element_text(size = 20,face='bold',family = "Times"),
  text = element_text(family = "Times"))
#绘制UMAP降维聚类图 
pdf(file="01.UMAP.pdf",width=10,height=8,family='Times')
DimPlot(scRNA ,reduction = "umap",label.size = 5,label = TRUE,pt.size=0.8,cols = palettes(category = "random",22,show_col=F))+theme.set
dev.off()

png(file="01.UMAP.png",width=10,height=8,family='Times',units='in',res=600)
DimPlot(scRNA ,reduction = "umap",label.size = 5,label = TRUE, pt.size=0.8,cols = palettes(category = "random",22,show_col=F))+theme.set
dev.off()

system.time(save(scRNA, file = "scRNA_UMAP.Rdata")) 
pkgs<-lapply(sessionInfo()$otherPkgs,function(x){x$Version}) %>% as.data.frame() %>%t()
write.table(pkgs,'pkgs.tsv',quote = F,sep = '\t',col.names=F)
