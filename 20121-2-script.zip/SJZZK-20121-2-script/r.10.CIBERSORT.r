rm(list = ls())
setwd('./')
if (! dir.exists('./10_CIBERSORT_all')){
  dir.create('./10_CIBERSORT_all/')
}
setwd('./10_CIBERSORT_all/')


library(ggpubr)
library(ggplot2)
load("../10_CIBERSORT/cibersort.RData")
rm(cibersort)
sample_tq<-group%>%dplyr::filter(type %in% c('DR'))
exprSet_tq<-exprSet[,sample_tq$sample]
library(IOBR)
methods<-c('mcpcounter',
           'epic',
           #'xcell',
           #'cibersort',原报告已做
           'cibersort_abs',
           'ips',
           'quantiseq',
           'estimate',
           #'svr',不要
           #'lsei'，不要
           'timer'
)
if(F){
for(ms in methods){
  cibersort<-switch(
    ms,
    'timer'=deconvo_timer(eset=exprSet_tq, project = 'stad', indications = rep('stad',ncol(exprSet_tq))),
    'quantiseq'=deconvo_quantiseq(eset=exprSet_tq, project = NULL, tumor=T, arrays=F, scale_mrna=F),
    deconvo_tme(eset = exprSet, method = ms, arrays = F, perm = 200,platform = 'illumina' )
  )
  saveRDS(cibersort,paste0("cibersort_",ms,"_method.rds"))
  print(ms)
}
#load("cibersort_data.RData")
}
for(ms in methods){
  tryCatch({#try start----
    setwd('./')

    
    cibersort<-readRDS(paste0("cibersort_",ms,"_method.rds"))
    if (! dir.exists(ms)){
      dir.create(ms)
    }
    setwd(ms)
    library(magrittr)
    cibersort.res <- cibersort %>% as.data.frame()
    colnames(cibersort.res) %<>% gsub('cibersort',"",.,ignore.case = T)
    #colnames(cibersort.res) %<>% gsub(paste0("_",ms),"",.,ignore.case = T)
    colnames(cibersort.res) %<>%gsub('_[^_]+$',"",.,perl = T) #去掉_MCPcounter等
    colnames(cibersort.res) %<>% gsub("_"," ",.)
    rownames(cibersort.res) <- cibersort.res$ID
    cibersort.res <- cibersort.res[,-c(1)]
    if(ms=='cibersort'){
      cibersort.res<-cibersort.res[,-c(23:25)]
    }
    if(ms=='cibersort_abs'){
      cibersort.res<-cibersort.res[,-c(23:26)]
    }
    if(ms=='timer'){
      cibersort.res<-cibersort.res[,-c(1)]
    }
    if(ms=='ips'){
      cibersort.res<-cibersort.res%>%t%>%na.omit%>%t%>%data.frame
    }
    # source('CIBERSORT.R')
    # result <- CIBERSORT("LM22.txt","00.CIBERSORT_RNA.csv", perm = 1000, QN = T)    ##QN如果是芯片设置为T，如果是测序就设置为F
    # CIBERSORT <- result[,(1:22)]#每个样本的免疫细胞浸润比例
    write.csv(cibersort.res,'01.CIBERSORT_result.csv')
    library(RColorBrewer)
    library(rstatix)
    mypalette <- colorRampPalette(brewer.pal(7,"Paired"))
    
    ###堆积图-----------------
    res1 <- data.frame(t(cibersort.res))
    res1$cell_type <- rownames(res1)
    
    pdf('01.cell_barplotData.pdf',w=10,h=8, family = 'Times')
    res1 %>%
      gather(sample, fraction, -cell_type) %>%
      merge(group,by='sample')%>%
      # 绘制堆积条形图
      ggplot(aes(x=sample, y=fraction, fill=cell_type)) +
      geom_bar(position = 'stack',stat = 'identity')+
      scale_y_continuous(expand = c(0,0))+
      theme_bw()+
      labs(x='',
           y='Relative Percent',
           fill='')+
      theme(axis.text.x = element_blank(),
            axis.ticks.x = element_blank(),
            legend.position = 'top') +
      scale_fill_manual(values = mypalette(22))+
      facet_grid(~type,scales= "free",space= "free")
    dev.off()
    
    png('01.cell_barplotData.png',w=10,h=8,units='in',res=600, family = 'Times')
    res1 %>%
      gather(sample, fraction, -cell_type) %>%
      merge(group,by='sample')%>%
      # 绘制堆积条形图
      ggplot(aes(x=sample, y=fraction, fill=cell_type)) +
      geom_bar(position = 'stack',stat = 'identity')+
      scale_y_continuous(expand = c(0,0))+
      theme_bw()+
      labs(x='',
           y='Relative Percent',
           fill='')+
      theme(axis.text.x = element_blank(),
            axis.ticks.x = element_blank(),
            legend.position = 'top') +
      scale_fill_manual(values = mypalette(22))+
      facet_grid(~type,scales= "free",space= "free")
    dev.off()
    ### 箱线图-------------
    ##  R值检验
    
    #group<-data.frame(sample=rownames(risk),Risk=risk$Risk)
    res4 <- cibersort.res
    keep <- colSums(res4 > 0) >= floor(0.20*nrow(res4)) # 过滤在至少在80%的样本中都有表达的细胞
    res4 <- res4[,keep]
    #过滤掉表达为0的
    res4 <- res4[,which(colSums(res4) > 0)]
    #res4 <- res4[,-2]
    res4 <- res4[,order(colnames(res4),decreasing = F)]
    
    identical(group$sample,rownames(res4))
    ##按照字母进行排序
    res4 <- res4 %>% as.data.frame %>% tibble::rownames_to_column(var = "sample")
    identical(res4$sample,group$sample)
    res4 <- merge(res4, group, by = "sample")
    
    
    #差异检验
    dat.test <- tidyr::gather(res4, Cell, `Cell composition`, -c(sample, type))
    library(rstatix)
    library(reshape2)
    colnames(dat.test)
    stat_res <- dat.test %>% 
      group_by(Cell) %>% 
      wilcox_test(`Cell composition` ~ type) %>% 
      adjust_pvalue(method = "BH") %>%  # method BH == fdr
      add_significance("p")
    stat_res  
    write.csv(stat_res, file = "02.cell_wilcoxon_res.csv", row.names = F, quote = F)
    # #差异细胞
    dif_cell<-stat_res[stat_res$p<0.05,]
     dif_cell$Cell

    dat.test2 <- dat.test[dat.test$Cell %in% dif_cell$Cell,]
    dif_cell2 <- stat_res[stat_res$Cell %in% dif_cell$Cell,]
    
    
    #分面图形
    library(ggplot2)
    library(ggpubr)
    dat.test2$type <- factor(dat.test2$type,levels = c('control','DR'))
    yposit<-dat.test2  %>% mutate(top=max(`Cell composition`),.by = Cell) %>% dplyr::select(Cell,top)%>% unique()
    yposit$top<-yposit$top*1.1
    exp_plot <- ggplot(dat.test2,aes(x = type, y = `Cell composition`, color= type)) +
      #geom_violin(trim=F,color='black',aes(fill=Group)) + #绘制小提琴图, “color=”设置小提琴图的轮廓线的颜色(#不要轮廓可以设为white以下设为背景为白色，其实表示不要轮廓线)
      #"trim"如果为TRUE(默认值),则将小提琴的尾部修剪到数据范围。如果为FALSE,不修剪尾部。
      stat_boxplot(geom="errorbar",
                   width=0.2,
                   color="black",
                   position = position_dodge(0.9)) +
      geom_boxplot(width=0.8,
                   aes(fill=type),
                   color="black",
                   position=position_dodge(0.9),
                   outlier.shape = NA)+ #绘制箱线图，此处width=0.1控制小提琴图中箱线图的宽窄
      geom_point(#aes(fill = Group),
        size = 0.2,
        color="black",
        position = 'jitter'
        #position = position_dodge(0.1)
      )+
      scale_fill_manual(values= c("#569dcb","#f49c4d"), name = "Group")+
      labs(title="", x="", y = "",size=20) +
      #scale_colour_manual(values = c("#569dcb","#f49c4d"))+
      # scale_color_brewer(palette = 'Set2')+
      # stat_compare_means(aes(group = Group,label = "p.format"),
      #                    method = "wilcox.test",label = 'p.signif',label.x = 1.4)+
      # stat_pvalue_manual(stat.test,
      #                    y.position = 6,
      #                    size = 3.2,
      #                    family = "Times",
      #                    label = "p1",  #选择差异分析中的结果或者w检验
      #                    #parse = T,
      #                    face = "bold")+
    stat_pvalue_manual(dif_cell2 ,
                       #x = "type",
                       y.position = yposit$top,#c(0.1,0.32,0.15,0.63),
                       size =4.5,
                       color = "black",
                       family = "Times",
                       # label = paste0("~italic(p)=={p.adj2}"),
                       label = "p.signif"
                       #parse = T
    ) +
      theme_bw()+
      theme(plot.title = element_text(hjust =0.5,colour="black",face="bold",size=15),
            axis.text.x=element_text(angle=0,hjust=0.5,colour="black",face="bold",size=12),
            axis.text.y=element_text(hjust=0.5,colour="black",face="bold",size=12),
            axis.title.x=element_text(size=16,face="bold"),
            axis.title.y=element_text(size=16,face="bold"),
            legend.text=element_text(face = "bold", hjust = 0.5,colour="black", size=12),
            legend.title = element_text(face = "bold", size = 12),
            legend.position = "top",
            panel.grid.major = element_blank(),
            panel.grid.minor = element_blank(),
            text=element_text(family='Times'))+
      facet_wrap(~Cell,scales = "free",nrow = 1,strip.position = "top")
    exp_plot
    ggsave(filename = "02.Cell_boxplot.pdf", width = 10, height = 8)
    ggsave(filename = "02.Cell_boxplot.png", width = 10, height = 8,dpi = 600)

    #细胞相关性----------
    
    res4 <- cibersort.res
    keep <- colSums(res4 > 0) >= floor(0.20*nrow(res4))
    res4 <- res4[,keep]
    #过滤掉表达为0的
    res4 <- res4[,which(colSums(res4) > 0)]
    #res4 <- res4[,-2]
    res4 <- res4[,order(colnames(res4),decreasing = F)]
    
    # diff <- read.csv('./02.cell_wilcoxon_res.csv')
    # diff <- diff[diff$p<0.05,]
    # res3 <- res4[,colnames(res4)%in%diff$Cell]
    res3 <- res4
    #res3 <- tiics_result
    # #过滤掉表达为0的
    # res3 <- res3[,which(colSums(res3) > 0)]
    # res3 <- res3[,order(colnames(res3),decreasing = F)]
    library(ggcorrplot)
    cor_data <- cor(res3,method="spearman")
    corp <- cor_pmat(res3)
    
    write.csv(cor_data,'03.cell_cor_r.csv',quote=F)
    write.csv(corp,'03.cell_cor_p.csv',quote=F)
    
    
    ##https:/www.jianshu.com/p/383c11d64267
    ##相关性热图
    library(ggcorrplot)
    library(corrplot)
    pdf("03.cell_corHeatmap.pdf",height=14,width=14,family='Times')           
    col1 <- colorRampPalette(c("#569dcb", "white", "#f49c4d"))
    corr_plot<-corrplot(cor_data,
                        tl.cex=1.5,
                        method = "square", #square,circle,method = 'shade'
                        is.corr = T,
                        type = "full", #lower,upper,full
                        p.mat = corp,
                        insig = "blank",
                        outline = "white",
                        addCoef.col ="black",
                        col = col1(200),
                        tl.col = 'black',
                        tl.offset = 0.4,
                        number.font = 2,
                        cl.cex = 0.8,
                        number.cex = 1.2
    )
    dev.off()
    
    png("03.cell_corHeatmap.png",height=14,width=14,family='Times',units='in',res=600)           
    col1 <- colorRampPalette(c("#569dcb", "white", "#f49c4d"))
    corr_plot<-corrplot(cor_data,
                        tl.cex=1.5,
                        method = "square", #square,circle,method = 'shade'
                        is.corr = T,
                        type = "full", #lower,upper,full
                        p.mat = corp,
                        insig = "blank",
                        outline = "white",
                        addCoef.col ="black",
                        col = col1(200),
                        tl.col = 'black',
                        tl.offset = 0.4,
                        number.font = 2,
                        cl.cex = 0.8,
                        number.cex = 1.2
    )
    dev.off()
    ### 细胞和基因相关性分析------------------
    res5 <- cibersort.res
    #过滤掉表达为0的
    res5 <- res5[,which(colSums(res5) > 0)]
    res5 <- res5[,dif_cell2$Cell]
    res5 <- res5[,order(colnames(res5),decreasing = F)]
    
    
    library(psych)
    y <-res5
    gene <- read.csv(file = './06_expression/03.hubgene.csv')
    x <-exprSet[gene$x,]%>%t() %>% as.data.frame()
    identical(rownames(x),rownames(y))
    
    library(psych)
    d <- corr.test(y,x,use="complete",method = 'spearman')
    r <- t(data.frame(d$r)) 
    #colnames(r)<-colnames(y)
    #rownames(r)<-colnames(y)
    p <- t(data.frame(d$p)) 
    #colnames(p)<-colnames(y)
    #rownames(p)<-colnames(y)
    write.csv(p,file="03.gene_cell_cor_p.csv",quote=F)
    write.csv(r,file="03.gene_cell_cor_r.csv",quote=F)
    
    
    ##https:/www.jianshu.com/p/383c11d64267
    
    # dat.r <- data.frame(r)
    # dat.r$cell <- rownames(dat.r)
    # dat.r <- gather(dat.r,'Gene','r',-c(cell))
    # 
    # dat.p <- data.frame(p)
    # dat.p$cell <- rownames(dat.p)
    # dat.p <- gather(dat.p,'Gene','p',-c(cell))
    # corrp <- (cbind(dat.r, dat.p))[,c("cell","Gene",'r',"p")]
    # corrp <- corrp[corrp$p<0.05,]
    
    library(corrplot)
    col <- colorRampPalette(c("#85b4d4", "white", "#f49c4d"))
    
    png(width=8,height=5,file='03.hubgene_cell_cor.png',units='in',res=600,bg='white',family = "Times")     ##par(family="serif")  :all
    par(pin = c(4,4), mar = c(6,6,6,1),family='Times',font=2,cex.axis=4) 
    plot<-corrplot(r,col=col(100),p.mat = p,  pch = 2,
                   method = 'square',
                   addgrid.col = 'black', # 边框色
                   pch.col = "black",
                   tl.cex = 1,  #指定文本标签的大小 
                   tl.col = "black",  #指定文本标签的颜色 
                   tl.offset = 0.4, 
                   tl.srt = 45, ##横坐标角度
                   cl.pos = NULL, 
                   sig.level = c(.0001,.001, .01, .05),
                   pch.cex =1,insig = "label_sig") 
    dev.off()
    
    pdf(width=8,height=5,file='03.hubgene_cell_cor.pdf',family = "Times")     ##par(family="serif")  :all
    par(pin = c(4,4), mar = c(6,6,6,1),family='Times',font=2,cex.axis=4) 
    corrplot(r,col=col(100),p.mat = p,  pch = 2,
             method = 'color',
             addgrid.col = 'black', # 边框色
             pch.col = "black",
             tl.cex = 1,  #指定文本标签的大小 
             tl.col = "black",  #指定文本标签的颜色 
             tl.offset = 0.4, 
             tl.srt = 45, ##横坐标角度
             cl.pos = NULL, 
             sig.level = c(.0001,.001, .01, .05),
             pch.cex =1,insig = "label_sig")
    dev.off()
    #提取|cor|>0.3的
    s<-abs(r[1,])>0.3 |abs(r[2,])>0.3
    
    
    ##显著的结果画散点图-------
    library(ggplot2)
    library(ggpubr)
    library(ggExtra)
    hubgene <- gene
    hub_exp<-exprSet[gene$x,] %>% as.data.frame()
    hub_exp <- hub_exp[,group$sample]
    tiic<-cibersort.res
    tiic <- tiic[group$sample,]%>%as.data.frame()
    
    colnames(tiic)
    dif_cell$Cell
    tiic2 <- tiic[,c(dif_cell$Cell)]
    cnt <- 1
    cor.all <- list()
    while (cnt<=nrow(hub_exp)) {
      x <-as.numeric(hub_exp[cnt,])
      y <-tiic2
      # 
      # library(psych)
      # d <- psych::corr.test(y,x,use="complete",method = 'spearman')
      # r <- data.frame(d$r)
      # p <- data.frame(d$p)
      # # write.table(p,file=paste(rownames(dat.hub)[cnt], "p.xls",sep='_'),sep="\t",quote=F)
      # #  write.table(r,file=paste(rownames(dat.hub)[cnt], "r.xls",sep='_'),sep="\t",quote=F)
      # correlation<-data.frame(rownames(p),r$d.r,p$d.p)
      # colnames(correlation) <- c('gene','Correlation','p.value')
      # write.table(correlation,file=paste(rownames(hub_exp)[cnt], "correlaion.xls",sep='_'),sep="\t",quote=F,row.names = F)
      for (i in 1:length(colnames(y))) {
        marker <- as.numeric(t(y)[i,])
        hubgene <- as.numeric(hub_exp[cnt,])
        df1 <- cbind(hubgene,marker)%>%as.data.frame()
        p1 <- ggplot(df1,aes(marker,hubgene))+
          xlab(colnames(tiic2[i]))+ylab(rownames(hub_exp[cnt,]))+
          geom_point()+geom_smooth(method = 'lm',formula = y~x)+
          theme_bw()+
          stat_cor(method = 'spearman',aes(x=marker,y=hubgene))
        p1  
        p2 <- ggMarginal(p1,type = 'density',xparams = list(fill='orange'),
                         yparams = list(fill='blue'))
        
        print(p2)
        ggsave(p2,filename = paste0(cnt+4,'.',rownames(hub_exp[cnt,]),'-',colnames(tiic2[i]),'.pdf'),w=5,h=5)
        ggsave(p2,filename = paste0(cnt+4,'.',rownames(hub_exp[cnt,]),'-',colnames(tiic2[i]),'.png'),w=5,h=5)
      }  
      cnt <- cnt+1
    }
    
    #try end----
  }, 
  error = function(e) {print(paste0('error: ',e))},
  finally=print(ms)
  )
}
    #包列表----
    pkgs<-lapply(sessionInfo()$otherPkgs,function(x){x$Version}) %>% as.data.frame() %>%t()
    write.table(pkgs,'pkgs.tsv',quote = F,sep = '\t',col.names=F)
