#ROC-------------
rm(list = ls())
setwd("./")
if (! dir.exists("./07_ROC")){
  dir.create("./07_ROC")
}
setwd("./07_ROC")

library(lance)
library(tidyverse)

hubgene <- read.csv('../06_expression/03.hubgene.csv',row.names = 1)
colnames(hubgene)<-'GeneSymbol'
dat<-read.csv('../00_rawdata/01.fpkm.log_GSE221521.csv',row.names = 1)
group<-read.csv('../00_rawdata/01.group_GSE221521.csv')

table(group$type)

group$type = factor(group$type, levels = c("DR", "control"))
hub_exp<-dat[hubgene$GeneSymbol,group$sample]
# hub_exp <- log2(hub_exp+1)
library(ROCR)
library(ggplot2)

hub_exp2<-t(hub_exp)
project <- 'GSE221521'
identical(rownames(hub_exp2), group$sample)
## 绘制ROC曲线
res <- data.frame()
library(pROC)
library(myplot)
for (i in c(1:length(hubgene$GeneSymbol))) {
  roc<-roc(group$type,hub_exp2[,i],levels=c("DR", "control"))
  print(paste0(colnames(hub_exp2)[i],':',roc$auc))
  plot(roc,print.auc=T,print.auc.x=0.4,print.auc.y=0.5,print.auc.pattern='AUC=%.3f',grid=c(0.5,0.2),
       grid.col=c("black","black"),
       col="#FF2E63",
       legacy.axes=T)
  roc <- data.frame(symbol=colnames(hub_exp2)[i], auc=roc$auc)
  res <- rbind(res,roc)
}

# Setting direction: controls > cases
# [1] "SLC36A1:0.780869565217391"
# Setting direction: controls > cases
# [1] "RAB23:0.671304347826087"

gene <- res[res$auc>0.7,]
write.csv(gene,'02.roc0.7.csv')

a <- read.csv('01.roc0.7.csv')
#GSE189005----
dat<-read.csv('../00_rawdata/02.expr_GSE189005.csv',row.names = 1)
group<-read.csv('../00_rawdata/02.group_GSE189005.csv')

table(group$type)

group$type = factor(group$type, levels = c("DR", "control"))
hub_exp<-dat[hubgene$GeneSymbol,group$sample]
# hub_exp <- log2(hub_exp+1)
library(ROCR)
library(ggplot2)

hub_exp2<-t(hub_exp)
project <- 'GSE189005'
identical(rownames(hub_exp2), group$sample)
## 绘制ROC曲线
res <- data.frame()
library(pROC)
for (i in c(1:length(hubgene$GeneSymbol))) {
  roc<-roc(group$type,hub_exp2[,i],levels=c("DR", "control"))
  print(paste0(colnames(hub_exp2)[i],':',roc$auc))
  png(paste0('01.', colnames(hub_exp2)[i],'-',project,".png"),width = 4,height = 4,units = 'in',res = 600)
  plot(roc,
       print.auc=T,
       print.auc.x=0.4,print.auc.y=0.5,
       print.auc.pattern='AUC=%.3f',
       #auc.polygon=T,
       #auc.polygon.con="#fff7f7",
       grid=c(0.5,0.2),
       grid.col=c("black","black"),
       #print.thres=T,
       main=paste0(colnames(hub_exp2)[i]),
       col="#FF2E63",
       legacy.axes=T)
  dev.off()
  pdf(paste0('01.', colnames(hub_exp2)[i],'-',project,".pdf"),width = 4,height = 4)
  plot(roc,
       print.auc=T,
       print.auc.x=0.4,print.auc.y=0.5,
       #auc.polygon=T,
       #auc.polygon.con="#fff7f7",
       grid=c(0.5,0.2),
       grid.col=c("black","black"),
       #print.thres=T,
       main=paste0(colnames(hub_exp2)[i]),
       col="#FF2E63",
       legacy.axes=T)
  dev.off()
  roc <- data.frame(symbol=colnames(hub_exp2)[i], auc=roc$auc)
  res <- rbind(res,roc)
}
# Setting direction: controls > cases
# [1] "SLC36A1:0.955555555555556"
# Setting direction: controls > cases
# [1] "RAB23:0.977777777777778"
#包列表----
pkgs<-lapply(sessionInfo()$otherPkgs,function(x){x$Version}) %>% as.data.frame() %>%t()
write.table(pkgs,'pkgs.tsv',quote = F,sep = '\t',col.names=F)