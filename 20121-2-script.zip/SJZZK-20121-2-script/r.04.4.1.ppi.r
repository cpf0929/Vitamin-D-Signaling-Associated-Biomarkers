rm(list = ls())
setwd('./')
if (! dir.exists('./04_4.1.ppi')) {
  dir.create('./04_4.1.ppi')
}
setwd("./04_4.1.ppi")
options(stringsAsFactors = F)
library(tidyverse)  # ggplot2 stringer dplyr tidyr readr purrr  tibble forcats
library(STRINGdb) #BiocManager::install(c("STRINGdb","igraph"),ask = F,update = F)
library(igraph)

#① STRINGdb数据库导入
#首先选择载入的STRINGdb数据（数据库版本、物种、蛋白互作得分）和之前基因差异分析得到的DEG。 STRINGdb$new设置使用最新的11.5版本数据库，物种选择为小鼠（人9606，小鼠10090 ），蛋白互作得分阈值选择700（默认400, 低150，高700，极高900，越高可信度越强）。
#（特别注意write.table要设quote = F，让字符不要带引号 ，否则后续上传 STRING容易识别错误）

######################### 选择STRINGdb类型 #########################
string_db <- STRINGdb$new( version="12.0", #数据库版本。截止2022.5.24最新为11.5
                           species=9606,   #人9606，小鼠10090 
                           score_threshold=400, #蛋白互作的得分 默认400, 低150，高700，极高900
                           input_directory="/nas1/wangdengdong/pub/db/stringdb") #可自己导入数据

#② 获取STRING_id
dat<-read.delim2('../04_candi_gene/candidate_genes.csv',header = F)
names(dat)[1]<-'gene'
#使用map获取基因名对应的STRING_id用于绘制string_PPI ， 基因名为gene symbol或ENTREZID都可以直接对应获取STRING_id

dat_map <- string_db$map(my_data_frame=dat, 
                         my_data_frame_id_col_names="gene", #使用gene symbol或ENTREZID都可
                         removeUnmappedRows = TRUE ,
                         quiet=F)

hits <- dat_map$STRING_id

#③ PPI蛋白互作网络绘制
#完成以上步骤后使用plot_network即可绘制PPI图，还可以给PPI添加上下调信息（上调标记为红色光环，下调标记为绿色光环）
## PPI
png("string_PPI.png",units="in",width = 10,height = 10, res=400)
string_db$plot_network(hits)
dev.off()
#ppi enrichmen
#options (digits=8)
enrich_ppi<-string_db$ppi_enrichment(hits)

#⑥ 获取蛋白互作信息
#最后，可使用get_interactions获取蛋白互作信息，再转换stringID为 gene symbol，去除重复（每个相互作用会出现两次），之后导出string_link.csv文件，可在Cytoscape中进一步进行多种可视化操作
############################## 获取蛋白互作信息用于后续可视化 ###############3
dat_link <- string_db$get_interactions(hits)
# 转换stringID为 gene symbol
dat_link$node1 <- dat_map[match(dat_link$from,dat_map$STRING_id),'gene']
dat_link$node2 <- dat_map[match(dat_link$to,dat_map$STRING_id),'gene']  
dat_link<-dat_link %>% dplyr::select('node1','node2','from','to','combined_score')
colnames(dat_link) <- c('node1','node2','node1_string_id','node2_string_id','combined_score')
dat_link$combined_score<-dat_link$combined_score/1000
# 去除重复
dat_link <- dat_link %>% distinct(node1, node2, .keep_all = T)
#有连接的基因
genes<-unique(c(dat_link$node1,dat_link$node2))
genes<-intersect(dat,genes) #node2可能会包含数据库里的基因
#112
write.csv(dat_link,'string_link.csv',row.names = F,quote = F)
writeLines(genes,'interaction_genes.csv')
nrow(dat_map)
#nodes 229
enrich_ppi
#$enrichment P
#[1] 0.00012
#$edges
#[1] 152
#$lambda
#[1] 111
