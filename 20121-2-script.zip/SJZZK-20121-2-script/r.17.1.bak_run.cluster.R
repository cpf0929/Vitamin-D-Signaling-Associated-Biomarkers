rm(list=ls())
source('../../../notice.r')
setwd('./')
if (! dir.exists("./14.scRNA")){
  dir.create("./14.scRNA")
}
setwd("./14.scRNA")
# 06.singleR ------
if (! dir.exists("./06_singleR")){
  dir.create("./06_singleR")
}
setwd("./06_singleR")
load('../05_UMAP/scRNA_UMAP.Rdata')
options(stringsAsFactors = F)
library(Seurat)
library(ggplot2)
library(clustree)
library(cowplot)
library(dplyr)
library(stringr)  
library(harmony)
library(tidyverse)
library(patchwork)
library(data.table)
## 6.1 识别各celltype中的marker基因 ----
#利用FindAllMarkers寻找每一种细胞类型的topMarker基因
# check the current active plan
library(future)
plan()
plan("multicore", workers = 24)
plan()
print('start at:')
Sys.time()
DefaultAssay(scRNA) <- "RNA"
scRNA <- JoinLayers(scRNA)
all.markers <- FindAllMarkers(
  scRNA,
  only.pos = TRUE,
  min.pct = 0.25,
  logfc.threshold = 0.5,
  test.use = 'wilcox',
  return.thresh = 0.01
)
print('FindAllMarkers:');Sys.time()
write.csv(all.markers,file = '06.AllMarkers_cluster.csv',quote = F)
saveRDS(all.markers,'all.markers_cluster.rds')
# all.markers <- readRDS('all.markers_cluster.rds')
