rm(list=ls())
source('../../../notice.r')
setwd("./")
if (! dir.exists("./14.scRNA")){
  dir.create("./14.scRNA")
}
setwd("./14.scRNA")

if (! dir.exists("./07_keycell")){
  dir.create("./07_keycell")
}
setwd("./07_keycell")
UMAP<-readRDS('../06_cell_annot/UMAP.celltype.rds')

hub<-read.csv('../../06_expression/03.hubgene.csv')%>%pull(x)
theme.set = theme(
  axis.title.x=element_blank(),
  axis.title = element_text(size = 20, face = "bold", family = "Times"),
  axis.text.x = element_text(size = 14,  face = "bold", family = "Times"),
  axis.text.y = element_text(size = 14,  face = "bold", family = "Times"),
  legend.text = element_text(size = 16, face = "bold", family = "Times"),
  legend.title = element_text(size = 18,face='bold',family = "Times"),
  text = element_text(family = "Times"))
pf <- FeaturePlot(UMAP, features = hub,slot = 'data',cols =c("#eeeeee","#ff0000")) + theme.set #'counts', 'data', or 'scale.data'
#pf
ggsave('07.1.hubgene_UMAP.png',pf,w=10,h=6)
ggsave('07.1.hubgene_UMAP.pdf',pf,w=10,h=6)
UMAP<-UMAP[,!UMAP@meta.data$celltype%in%c('other cells')]
#p1d=VlnPlot(UMAP, group.by = "celltype", features = hub, pt.size = 0.005, ncol = 2) 
p1d <-  VlnPlot(UMAP, features = rev(hub),ncol = 2, sort=T, add.noise = F,pt.size = 0) #sort=t平均值最高
#p1d+theme(plot.margin = margin(l=1,unit='in')) 
#NoLegend() #绘制小提琴图，指定feats； pt.size代表点的大小；ncol代表2列
ggsave("06.2.violin.hub.pdf", plot = p1d, width = 10, height = 5)
ggsave("06.2.violin.hub.png", plot = p1d, width = 10, height = 5,dpi = 600)

p1d=DotPlot(UMAP, group.by = "celltype", features = hub,cols = c("lightgrey", "#ff0000"),)+ theme(axis.text.x = element_text(angle = 45, hjust = 1,
                                                                                                                             color = "black",size=9))
ggsave("06.2.dotplot.hub.pdf", plot = p1d, width = 10, height = 8)
ggsave("06.2.dotplot.hub.png", plot = p1d, width = 10, height = 8,dpi = 600)
#B cells  
#classical monocytes         
#UMAP.key <- subset(UMAP,idents = c('Myofibroblastic','Pericytes'))
UMAP.key<-UMAP[,UMAP@meta.data$celltype%in%c('B cells','classical monocytes')]
UMAP.key@meta.data$celltype%<>%droplevels()
saveRDS(UMAP.key, file = "UMAP.key_cells.RData")


pf <- FeaturePlot(UMAP, features = hub,slot = 'data',cols =c("#eeeeee","#ff0000")) + theme.set #'counts', 'data', or 'scale.data'
#pf
ggsave('01.hubgene_UMAP.png',pf,w=10,h=6)
ggsave('01.hubgene_UMAP.pdf',pf,w=10,h=6)

#p1d=VlnPlot(UMAP, group.by = "celltype", features = hub, pt.size = 0.005, ncol = 2) 
#NoLegend() #
p1d <-  VlnPlot(UMAP, features = hub,ncol = 2, sort=T, add.noise = F,pt.size = 0) #sort=t平均值最高

#p1d=DotPlot(UMAP, group.by = "celltype", features = hub,cols =c("#00ff00","#ff0000"))  
   #绘制小提琴图，指定feats； pt.size代表点的大小；ncol代表2列
ggsave("02.dotplot.hub.pdf", plot = p1d, width = 10, height = 5)
ggsave("02.dotplot.hub.png", plot = p1d, width = 10, height = 5,dpi = 600)
p1d<-p1d$data
p1<-ggplot(p1d,aes(x=id,y=pct.exp,fill=features.plot))+
  geom_bar(position = "dodge",stat="identity",alpha=0.7)+
  theme_bw()+
  scale_fill_manual(values=brewer.pal(8, "Set3"))+
  theme(axis.title.x =element_text(size=22,color='black', face = "bold",family='Times'),
        axis.text.x =element_text(size=18,angle = 40,vjust = 1,hjust=1,color='black', face = "bold",family='Times'),
        axis.title.y =element_text(size=22,color='black', face = "bold",family='Times'),
        axis.text.y=element_text(size=18,  color='black',face = "bold",family='Times'),
        legend.title=element_text(size=20, color='black', face = "bold",family='Times'),
        legend.text=element_text(size=14, color='black', face = "bold",family='Times'),
        title=element_text(size=20, color='black', face = "bold",family='Times'),
        strip.text = element_text(size = 14,color='black',family = "Times", face = "bold"))+
  theme(panel.grid.major=element_blank(),panel.grid.minor=element_blank())+
  labs(x="Celltype",y="exp",fill="")
p1
library(ggplot2)
ggsave("02.barplot.hub.pdf", plot = p1, width = 10, height = 5)
ggsave("02.barplot.hub.png", plot = p1, width = 10, height = 5,dpi = 600)

