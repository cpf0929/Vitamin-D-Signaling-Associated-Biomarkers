rm(list=ls())
setwd('./')
if (! dir.exists("./14.scRNA")){
  dir.create("./14.scRNA")
}
setwd("./14.scRNA")
if (! dir.exists("./03_Normalize")){
  dir.create("./03_Normalize")
}
setwd("./03_Normalize")
load('../02_QC/scRNA_qc.Rdata')
# 03.Normalize--------
scRNA<- NormalizeData(scRNA, verbose = FALSE)
##前2000个高变异基因
scRNA <- FindVariableFeatures(object = scRNA, selection.method = "vst", nfeatures =2000)
write.csv(VariableFeatures(scRNA),'VariableFeatures.csv',row.names = F,col.names = F)
##输出特征方差图
top10 <- head(x = VariableFeatures(object = scRNA), 10)

theme.set= theme(axis.title.x=element_blank(),
                 axis.title = element_text(size = 16, face = "bold", family = "Times"),
                 axis.text.x = element_text(size = 10,  family = "Times"),
                 axis.text.y = element_text(size = 14,  family = "Times"),
                 legend.position = 'top',legend.direction = 'vertical',
                 legend.text = element_text(size = 14, family = "Times"),
                 legend.title = element_text(size = 16,face='bold',family = "Times"),
                 text = element_text(family = "Times"))
plot1 <- VariableFeaturePlot(object = scRNA)+theme.set
plot2 <- LabelPoints(plot = plot1, points = top10, repel = TRUE)
pdf(file="03.featureVar.pdf",width=4,height=4,family='Times',onefile=F)              #保存基因特征方差图
print(plot2)
dev.off()

png(file="03.featureVar.png",width=4,height=4,family='Times',units='in',res=600)              #保存基因特征方差图
plot2 <- LabelPoints(plot = plot1, points = top10, repel = TRUE)
print(plot2)
dev.off()
system.time(save(scRNA, file = "scRNA_normalization.Rdata"))
