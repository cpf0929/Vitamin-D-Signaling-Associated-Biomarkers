rm(list=ls())
source('../../../notice.r')
setwd('./')
if (! dir.exists("./14.scRNA")){
  dir.create("./14.scRNA")
}
setwd("./14.scRNA")

if (! dir.exists("./06_cell_annot")){
  dir.create("./06_cell_annot")
}
setwd("./06_cell_annot")
load('../05_UMAP/scRNA_UMAP.Rdata')
library(tidyverse)
library(scales)
library(RColorBrewer)
library(ggsci)
library(IOBR)
library(grDevices)

## 6.1 识别各cluster中的marker基因 ----
#利用FindAllMarkers寻找每一种细胞类型的topMarker基因
#/data/nas1/wangdengdong/SJZZK-20121-2/r.17.1.bak_run.cluster.R
all.markers<-readRDS('all.markers_cluster.rds')
all.markers$gene%>%unique()%>%length()
#4735
theme.set = theme(
  axis.title = element_text(size = 20, face = "bold", family = "Times"),
  axis.text.x = element_text(size = 14,  face = "bold", family = "Times"),
  axis.text.y = element_text(size = 14,  face = "bold", family = "Times"),
  legend.text = element_text(size = 16, face = "bold", family = "Times"),
  legend.title = element_blank(),
  text = element_text(family = "Times"))

library(tidyverse)
top <- all.markers %>% group_by(cluster) %>% top_n (n=3,wt=avg_log2FC) #提取每个cluster的top3基因,*20个cluster=60

# 点阵图
dotplot1 <- DotPlot(scRNA,features = unique(top$gene)) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1,
                                   color = "black",size=9))
dotplot1
ggsave(filename = '06.markers_dotplot(cluster).png',dotplot1,w=14,h=8,dpi = 600)
ggsave(filename = '06.markers_dotplot(cluster).pdf',dotplot1,w=14,h=8)

# 热图
heatmap1 <- DoHeatmap(scRNA,features = top$gene,label = F)+
  labs(title="", x="Cells separated by clusters", y = "",size=40)
heatmap1
ggsave(filename = '06.topheat(cluster).png',heatmap1,w=8,h=7)
ggsave(filename = '06.topheat(cluster).pdf',heatmap1,w=8,h=7)
#marker umap
top20<-all.markers %>% group_by(cluster) %>% top_n (n=1,wt=avg_log2FC) # all.markers%>%arrange(desc(avg_log2FC))%>%head(20)
pu <- FeaturePlot(scRNA, features = top20$gene,slot='counts') + theme.set
pu
ggsave('01.top20_marker_UMAP.png',pu,w=12,h=10)
ggsave('01.top20_marker_UMAP.pdf',pu,w=12,h=10)

if(F){#表达很低
##hubgene umap ----
hubgene<-read.csv("/nas1/wangdengdong/SJZZK-20121-2/06_expression/03.hubgene.csv",row.names = 1)
gene<-hubgene$x
theme.set = theme(
  axis.title.x=element_blank(),
  axis.title = element_text(size = 20, face = "bold", family = "Times"),
  axis.text.x = element_text(size = 14,  face = "bold", family = "Times"),
  axis.text.y = element_text(size = 14,  face = "bold", family = "Times"),
  legend.text = element_text(size = 16, face = "bold", family = "Times"),
  legend.title = element_text(size = 18,face='bold',family = "Times"),
  text = element_text(family = "Times"))
pf <- FeaturePlot(scRNA, features = gene,slot = 'data') + theme.set #'counts', 'data', or 'scale.data'
pf
ggsave('01.hubgene_UMAP.png',pf,w=8,h=5)
ggsave('01.hubgene_UMAP.pdf',pf,w=8,h=5)
}

#细胞类型------

DefaultAssay(scRNA) <- "RNA"
scRNA <- JoinLayers(scRNA)
if(F){
# 06.singleR ------
scRNA_singleR = LayerData(scRNA, layer = "count", assay = "RNA")
scRNA_singleR[1:6,1:6]
#scRNA_singleR <- GetAssayData(scRNA, slot = "data")
library(celldex)
library(SingleR)
#mpca.se = MouseRNAseqData() 
hpca.se <- HumanPrimaryCellAtlasData()
notify('HumanPrimaryCellAtlasData')
#hpca.se<-BlueprintEncodeData()
#hpca.se<-DatabaseImmuneCellExpressionData()
clusters=scRNA@meta.data$seurat_clusters
pred.hesc <- SingleR(test = scRNA_singleR,
                     ref = hpca.se,
                     labels = hpca.se$label.main,
                     method = "cluster", 
                     clusters = clusters, 
                     # quantile = 0.8 ,
                     assay.type.test = "logcounts", 
                     assay.type.ref = "logcounts")
table(pred.hesc$labels)
# B_cell HSC_-G-CSF   Monocyte  Myelocyte    NK_cell  Platelets    T_cells 
# 3          1          6          1          2          1          6 
celltype = data.frame(ClusterID=rownames(pred.hesc), 
                      celltype=pred.hesc$labels, 
                      stringsAsFactors = F) 
scRNA@meta.data$celltype=celltype[match(clusters,celltype$ClusterID),'celltype']
system.time(save(scRNA, file = "scRNA_singleR.Rdata")) 


## 6.1细胞注释结果的可视化展示----------

load('./scRNA_singleR.Rdata')


# table(scRNA$celltype)
getPalette = colorRampPalette(brewer.pal(12, "Set3")) 

theme.set = theme(
  #axis.title.x=element_blank(),
  axis.title = element_text(size = 20, face = "bold", family = "Times"),
  axis.text.x = element_text(size = 14,  face = "bold", family = "Times"),
  axis.text.y = element_text(size = 14,  face = "bold", family = "Times"),
  legend.text = element_text(size = 16, face = "bold", family = "Times"),
  legend.title = element_blank(),
  text = element_text(family = "Times",face='bold'))
table(scRNA$celltype)

# B_cell HSC_-G-CSF   Monocyte  Myelocyte    NK_cell  Platelets    T_cells 
# 1747        825       5502         46       2939        461      10218
write.csv(table(scRNA$celltype),'01.celltype.csv')
library(ggprism)
#### (1)细胞的UMAP图 ------------
anno_plot1 <-DimPlot(scRNA, reduction = "umap", group.by = "celltype", 
                     label = F,label.size = 6,
                     cols = palettes(category = "random",22,show_col=F))+theme.set

anno_plot1
ggsave(filename = '01.celltype.pdf',anno_plot1,w=8,h=6)
ggsave(filename = '01.celltype.png',anno_plot1,w=8,h=6,dpi = 600)
# 
# anno_plot2 <- DimPlot(scRNA, reduction = "umap", group.by = "celltype",split.by = 'group',label = T)+
#   labs(title="") + xlim(-20,15) + theme.set
# anno_plot2
# ggsave(filename = '01.celltype(split).pdf',anno_plot2,w=13,h=6)
# ggsave(filename = '01.celltype(split).png',anno_plot2,w=13,h=6,dpi = 600)
}
#文献注释
# 6.2 绘制文章注释细胞的Marker图 ----------------------------------------------------

genes_to_check =list(
  Tcs	=	c("CD3D","CCL5"),#,"CD3"
  NKcs	=	c("KLRC1","KLRF1","NKG7","KLRD1"),
  cMs	=	c("CD14","FCN1","VCAN"),
  ncMs	=	c("FCGR3A","IFITM3"),
  Bcs	=	c("MS4A1","CD79A"),
  ct2Dcs	=	c("CD1C","CD1E","FCER1A"),
  Bas	=	c("CLC","GATA2","MS4A3","MS4A2"),
  PDcs	=	c("IL3RA","CLEC4C","LILRB4","GZMB"),
  Pls	=	c("PPBP","PF4","TUBB1","GP9"),
  Mac	=	c("CD68","CD163"),#,"IBA1" #补充cd163 from cellmarker support no.1和pmid:37917183
  Ecs	=	c("CLDN5","VWF"),
  Scs	=	c("PDGFRB","CSPG4","ACTA2")
  
  # ECs= c("CLDN5","VWF"),
  # Mac= c("CD68","CD163","CD14","AIF1","LST1","LYZ"),
  # DCs= c("CLEC10A","CD1C","FLT3","FCER1A"),
  # BCs= c("CD79A","IGKC"),
  # NKs= c("KLRB1","KLRF1","KLRD1"),
  # CD8T= c("CCL5","CD8A"),
  # Tregs= c("FOXP3","CD4"),#cd25不存在，补充cd4 from cellmarker support no.19
  # VSMs= c("CNN2","MYH11"),
  # PCs= c("CSPG4","RGS5","PDGFRB","MCAM"),#"KCNJ8","ABCC9",
  # myoF= c("ACTA2","FN1","COL1A1","LUM","AEBP1","MFAP5")#"COL1A2","THBS2",,"CTHRC1"
)# "KCNJ8"  "ABCC9"  "COL1A2" "THBS2"  "CTHRC1"
unlist(genes_to_check)%>%.[duplicated(.)]
#ncMs1  Bas1 
#"LYZ" "LYZ" 
genes<-unlist(genes_to_check)%>%unique()
genes[!genes%in%rownames(scRNA)]
#"CD3"  "IBA1"
genes<-genes[genes%in%rownames(scRNA)]
p <- DotPlot(scRNA, features = genes_to_check,
             assay='RNA'  )   + theme(axis.text.x = element_text(angle = 45, hjust = 1,
                                                                 color = "black",size=9))

p
ggsave('02.check_paper_markers.pdf',height = 11,width = 15)
ggsave('02.check_paper_markers.png',height = 11,width = 15)

 new.cluster.ids = c(
   # "0"="CD8 T cells",
   # "1"="Macrophage",
   # "2"="NK cells",
   # "3"="vascular smooth muscle cells",
   # "4"="vascular smooth muscle cells",
   # "5"="CD8 T cells",
   # "6"="Macrophage",
   # "7"="B cells",
   # "8"="CD8 T cells",
   # "9"="Macrophage",
   # "10"="other",
   # "11"="NK cells",
   # "12"="B cells",
   # "13"="CD8 T cells",
   # "14"="Macrophage",
   # "15"="Dendritic cells",
   # "16"="B cells",
   # "17"="B cells",
   # "18"="B cells",
   # "19"="Macrophage"
  "0"="T&NK cells",
  "1"="classical monocytes",
  "2"="NK cells",
  "3"="T cells",
  "4"="T cells",
  "5"="T cells",
  "6"="classical monocytes",
  "7"="B cells",
  "8"="T cells",
  "9"="non-classical monocytes",
  "10"="other cells",
  "11"="T&NK cells",
  "12"="B cells",
  "13"="platelets",
  "14"="conventional type 2 dendritic cells",
  "15"="basophils",
  "16"="other cells",
  "17"="plasmacytoid dendritic cells",
  "18"="B cells",
  "19"="classical monocytes"
 ) 
UMAP<- RenameIdents(scRNA, new.cluster.ids)
UMAP$celltype = Idents(UMAP)
table(UMAP$celltype)
# T&NK cells                 classical monocytes 
# 3612                                4109 
# NK cells                             T cells 
# 2231                                7180 
# B cells             non-classical monocytes 
# 1747                                 842 
# other cells                           platelets 
# 959                                 461 
# conventional type 2 dendritic cells                           basophils 
# 311                                 175 
# plasmacytoid dendritic cells 
# 111
##_________________________________
# CD8 T cells                   Macrophage                     NK cells 
# 6180                         5262                         2939 
# vascular smooth muscle cells                      B cells                        other 
# 4365                         1992                          825 
# Dendritic cells 
# 175 
anno_plot2 <-DimPlot(UMAP, reduction = "umap", group.by = "celltype", 
                     label = F,label.size = 6,
                     cols = palettes(category = "random",22,show_col=F))+theme.set

anno_plot2
ggsave(filename = '02.check_paper_markers_celltype.pdf',anno_plot2,w=10,h=6)
ggsave(filename = '02.check_paper_markers_celltype.png',anno_plot2,w=10,h=6,dpi = 600)
#6.2.可视化细胞的上述比例情况（根据细胞类型及进行可视化） -----------------------------
#去掉小提琴图上不合适的基因
color2=palettes(category = "random",length(genes),show_col=F)
pv<-VlnPlot(UMAP,
            features = genes,
            split.by = 'celltype',stack = TRUE,
            flip=TRUE,
            cols=color2)+
  coord_flip() +
  theme.set+theme(axis.ticks.y = element_blank(), 
                  axis.text.y = element_blank(),
                  plot.margin = margin(t=0.1,r=0.1,b=0.1,l=0.5,unit = 'in')
  )
ggsave(filename = '06.2.check_paper_markers_exp.pdf',pv,w=8,h=10)
ggsave(filename = '06.2.check_paper_markers_exp.png',pv,w=8,h=10,dpi = 600)


##CellMarker细胞注释(未使用)---------
# ### 
# p1 = FeaturePlot(scRNA, features = c('EPCAM','KRT8','KRT18'),repel = T,
#                  label = T, slot = "data", cols = c("lightgrey","red"), ncol = 3, order = T)
# p1
# ggsave(filename = '02.urothelial cells.pdf',p1,w=9,h=4)
# ggsave(filename = '02.urothelial cells.png',p1,w=9,h=4,dpi = 600)
# ### 
# p2 = FeaturePlot(scRNA, features = c('CD14','CSF1R','AIF1'),repel = T, label = T, slot = "data", cols = c("lightgrey","red"), ncol =3, order = T)
# p2
# ggsave(filename = '02.myeloid_macrophage.pdf',p2,w=9,h=4)
# ggsave(filename = '02.myeloid_macrophage.png',p2,w=9,h=4,dpi = 600)
# ## 
# p3 = FeaturePlot(scRNA, features = c("CD2",'CD3D','CD3E'),repel = T, label = T, slot = "data", cols = c("lightgrey","red"), ncol = 3, order = T)
# p3
# ggsave(filename = '02.T cells.pdf',p3,w=9,h=4)
# ggsave(filename = '02.T cells.png',p3,w=9,h=4,dpi = 600)
# ## 
# p4 = FeaturePlot(scRNA, features = c('DCN','PDPN','TAGLN'),repel = T, label = T, slot = "data", cols = c("lightgrey","red"), ncol = 3, order = T)
# p4
# ggsave(filename = '02.Fibroblasts.pdf',p4,w=9,h=4)
# ggsave(filename = '02.Fibroblasts.png',p4,w=9,h=4,dpi = 600)
# 
# ##
# p5 = FeaturePlot(scRNA, features = c('PECAM1','VWF','CLDN5'),repel = T, label = T, slot = "data", cols = c("lightgrey","red"), ncol = 3, order = T)
# p5
# ggsave(filename = '02.endothelial cells.pdf',p5,w=9,h=4)
# ggsave(filename = '02.endothelial cellss.png',p5,w=9,h=4,dpi = 600)


# 细胞类型的细胞数目--------
library(ggsci)

cellnum <- table(UMAP$celltype) %>% t() %>% as.data.frame()
cellnum <- cellnum[,-1]
colnames(cellnum) <- c('cell','count')
cellnum$cell <- gsub('_',' ',cellnum$cell)
cellnum <- cellnum[order(cellnum$count,decreasing = T),]
cellnum$cell <- factor(cellnum$cell, levels = cellnum$cell)
allnum<-sum(cellnum$count)
library(ggpie)
p1 <- ggpie::ggpie(cellnum,group_key = 'cell',count_type = 'count',
            label_info = "all", label_type = "horizon",
            border_size=0,label_size=2,nudge_x = 0.5,nudge_y=0.5,
            label_pos = "in", label_threshold = 10
)+
#  labs(x = NULL, y = NULL, fill = NULL)  +
  theme_classic() +
  theme(axis.line = element_blank(),
        axis.text = element_blank(),
        axis.ticks = element_blank(),
        axis.title.x =element_blank(),
        axis.title.y =element_blank()
        )+
  #scale_color_aaas()+
  #theme_bw()+
  scale_fill_manual(values=brewer.pal(nrow(cellnum), "Set3"))


p1
library(ggfun)
#p11 <- set_font(p1, family="Times", color="black")

ggsave(filename = '02.celltype_number.pdf',p1,w=8,h=6)
ggsave(filename = '02.celltype_number.png',p1,w=8,h=6,dpi = 600)
#

# 
## (3)不同细胞在GSE样本中的比例 --------
library(tidyverse)
dat_cell <- as.data.frame(table(UMAP$group,UMAP$celltype))
colnames(dat_cell) <- c('id', 'cell', 'number')
dat_cell2 <- spread(dat_cell,cell,number)

dat_cell2 <- dat_cell2 %>% column_to_rownames(., var = "id")
dat_cell2 <- dat_cell2 %>% mutate(rowsum = base::rowSums(.[1:dim(dat_cell2)[2]]))

dat_cell3 <- dat_cell2

for (i in 1:dim(dat_cell3)[1]){
  for (j in 1:(dim(dat_cell3)[2]-1)){
    # print(dat_cell3[i,j])
    dat_cell3[i,j] <- dat_cell3[i,j]/ dat_cell3[i,dim(dat_cell3)[2]]
  }
}
dat_cell3 <- dat_cell3[,-dim(dat_cell3)[2]]
dat_cell3 <- dat_cell3 %>% rownames_to_column('sample')
write.csv(dat_cell3,'04.cell_type_GSE.csv')

# 绘图
mydata <- melt(dat_cell3,id.vars="sample",variable.name="Celltype",value.name="Quantity")
ggplot(mydata,aes(x=sample,y=Quantity ,fill=Celltype))+
  geom_bar(position = "fill",stat="identity",alpha=0.7)+
  theme_bw()+
  scale_fill_manual(values=brewer.pal(ncol(dat_cell3)-1, "Set3"))+
  scale_y_continuous(labels = scales::percent) + #纵轴百分比
  theme(axis.title.x =element_text(size=22,color='black', face = "bold",family='Times'),
        axis.text.x =element_text(size=18,color='black', face = "bold",family='Times'),
        axis.title.y =element_text(size=22,color='black', face = "bold",family='Times'),
        axis.text.y=element_text(size=18,  color='black',face = "bold",family='Times'),
        legend.title=element_text(size=20, color='black', face = "bold",family='Times'),
        legend.text=element_text(size=14, color='black', face = "bold",family='Times'),
        title=element_text(size=20, color='black', face = "bold",family='Times'),
        strip.text = element_text(size = 14,color='black',family = "Times", face = "bold"))+
  theme(panel.grid.major=element_blank(),panel.grid.minor=element_blank())+
  labs(y="Proportion(%)",x="GSE",fill="")
  # facet_grid(~group,scales= "free",space= "free")

ggsave('04.Proportion_GSE.pdf',w=10,h=8)
ggsave('04.Proportion_GSE.png',w=10,h=8)


# 6.3 识别各celltype中的marker基因 ----
#利用FindAllMarkers寻找每一种细胞类型的topMarker基因
#/data/nas1/wangdengdong/SJZZK-20121-2/r.17.2.bak_run.celltype.R
all.markers <- readRDS('all.markers_celltype.rds')
all.markers$gene%>%unique()%>%length()
#1266
theme.set = theme(
  axis.title = element_text(size = 20, face = "bold", family = "Times"),
  axis.text.x = element_text(size = 14,  face = "bold", family = "Times"),
  axis.text.y = element_text(size = 14,  face = "bold", family = "Times"),
  legend.text = element_text(size = 16, face = "bold", family = "Times"),
  legend.title = element_blank(),
  text = element_text(family = "Times"))

library(tidyverse)
head(all.markers$cluster)
#[1] Endothelial cells Endothelial cells Endothelial cells Endothelial cells Endothelial cells Endothelial cells
#Levels: Endothelial cells Myofibroblastic Pericytes other Macrophage CD8 T cells NK cells B cells
top <- all.markers %>% group_by(cluster) %>% top_n (n=20,wt=avg_log2FC) #提取每个cluster的top2基因
nrow(top)
#140
# 点阵图
# dotplot2 <- DotPlot(scRNA,features = unique(top$gene),group.by = 'celltype') +
#   theme(axis.text.x = element_text(angle = 45, hjust = 1,
#                                    color = "black",size=9))
# dotplot2
# ggsave(filename = '07.markers_dotplot(celltype).png',dotplot2,w=12,h=6,dpi = 600)
# ggsave(filename = '07.markers_dotplot(celltype).pdf',dotplot2,w=12,h=6)

mycolor <- pal_npg(palette = c("nrc"), alpha = 0.5)(7)
# 热图
#heatmap2 <- DoHeatmap(UMAP,features = top$gene,label = F,group.by = 'celltype',group.colors =mycolor)+
#  labs(title="", x="Cells separated by clusters", y = "",size=40)
# 
# ggsave(filename = '06.3.topheat(celltype).png',heatmap2,w=8,h=10)
#ggsave(filename = '06.3.topheat(celltype).pdf',heatmap2,w=8,h=10)

# system.time(save(scRNA, file = "scRNA_singleR.Rdata")) 
# 热图
heatmap1 <- DoHeatmap(UMAP,features = top$gene,label = F)+
  labs(title="", x="Cells separated by celltype", y = "",size=40)+
  theme(axis.text.y =element_blank())
heatmap1
ggsave(filename = '06.3.topheat(celltype).png',heatmap1,w=12,h=8)
ggsave(filename = '06.3.topheat(celltype).pdf',heatmap1,w=12,h=8)
write.csv(top,'06.3.topheat(celltype).csv',row.names = F)

library(clusterProfiler)
library(org.Hs.eg.db)
library(ggsci)
library(RColorBrewer)
##富集结果 ----------
mycolor <- pal_npg(palette = c("nrc"), alpha = 0.5)(9)
cellnum <- table(all.markers$cluster)%>% as.data.frame()
colnames(cellnum) <- c('cell','number')
cellnum$cell <- gsub('_',' ',cellnum$cell)
cellnum <- cellnum[order(cellnum$number,decreasing = T),]
cellnum$cell <- factor(cellnum$cell, levels = cellnum$cell)

p1 <- ggplot(cellnum,aes(x=cell,y=number,fill=cell))+
  geom_bar(stat="identity", width=0.8) +
  geom_text(aes(label = number,y = number + 20))+
  scale_color_aaas()+
  theme_bw()+
  scale_fill_manual(values=brewer.pal(9, "Set3"))+
  theme(axis.title.x =element_text(size=16,color='black', face = "bold",family='Times'),
        axis.text.x =element_text(size=12,color='black', face = "bold",family='Times',angle=45,hjust=1),
        axis.title.y =element_text(size=16,color='black', face = "bold",family='Times'),
        axis.text.y=element_text(size=12,  color='black',face = "bold",family='Times'),
        # legend.title=element_text(size=20, color='black', face = "bold",family='Times'),
        # legend.text=element_text(size=10, color='black', face = "bold",family='Times'),
        title=element_text(size=20, color='black', face = "bold",family='Times'),
        strip.text = element_text(size = 14,color='black',family = "Times", face = "bold"),
        text = element_text(size = 8,face = "bold",family = "Times"))+
  theme(panel.grid.major=element_blank(),panel.grid.minor=element_blank())+ NoLegend()+
  labs(x="",y="Marker gene number",fill="")

library(ggfun)
p11 <- set_font(p1, family="Times", color="black")
ggsave(filename = '06.3.celltype_marker_number.pdf',p11,w=6,h=6)
ggsave(filename = '06.3.celltype_marker_number.png',p11,w=6,h=6,dpi = 600)

##### 富集
#keycell.markers <- all.markers[all.markers$cluster == 'Fibroblasts',]
# geneList <- keycell.markers$gene
geneList<-all.markers$gene%>%unique()
# 柱状图----------
gene_symbol <- clusterProfiler::bitr(
  geneID = geneList,
  fromType = "SYMBOL",
  toType = "ENTREZID",
  OrgDb = "org.Hs.eg.db")
enrich_go <- enrichGO(gene = gene_symbol[,2],
                      OrgDb = org.Hs.eg.db,
                      keyType = "ENTREZID",
                      ont = "ALL",
                      pAdjustMethod = "fdr",
                      pvalueCutoff = 1,
                      qvalueCutoff = 1,
                      readable = TRUE)
#保存GO注释文件
GO_ALL <- enrich_go@result
GO_ALL <- GO_ALL[GO_ALL$p.adjust < 0.05,]
BP <- GO_ALL[GO_ALL$ONTOLOGY=='BP', ]
BP <- BP[order(BP$Count,decreasing = T),]
CC <- GO_ALL[GO_ALL$ONTOLOGY=='CC', ]
CC <- CC[order(CC$Count,decreasing = T),]
MF <- GO_ALL[GO_ALL$ONTOLOGY=='MF', ]
MF <- MF[order(MF$Count,decreasing = T),]
paste0("得到",dim(GO_ALL)[[1]],"个结果，其中",dim(BP)[[1]],"个生物学过程，",dim(CC)[[1]],"个细胞组分，",dim(MF)[[1]],"个分子功能")
#
#"得到1365个结果，其中1170个生物学过程，101个细胞组分，94个分子功能"
write.csv(GO_ALL,file = "06.3.go_ALL.csv",quote = F,row.names = F)
# write.csv(as.data.frame(BP), '01.GO_BP.csv',row.names = FALSE, quote = FALSE)
# write.csv(as.data.frame(CC), '01.GO_CC.csv',row.names = FALSE, quote = FALSE)
# write.csv(as.data.frame(MF), '01.GO_MF.csv',row.names = FALSE, quote = FALSE)
ego_result_BP <- head(BP,5)
ego_result_CC <- head(CC,5)
ego_result_MF <- head(MF,5)
display_number <- c(5,5,5)
if(T){
  go_enrich_df <- data.frame(
    ID=c(ego_result_BP$ID, ego_result_CC$ID, ego_result_MF$ID),
    Description=c(ego_result_BP$Description,ego_result_CC$Description,ego_result_MF$Description),
    GeneNumber=c(ego_result_BP$Count, ego_result_CC$Count, ego_result_MF$Count),
    type=factor(c(rep("BP:biological process", display_number[1]), 
                  rep("CC:cellular component", display_number[2]),
                  rep("MF:molecular function", display_number[3])), 
                levels=c("BP:biological process", "CC:cellular component","MF:molecular function" )))
  write.csv(go_enrich_df,'06.3.go_enrich_df.csv')
  ##开始绘制GO柱状图
  ###横着的柱状图
  go_enrich_df$type_order=factor(rev(as.integer(rownames(go_enrich_df))),labels=rev(go_enrich_df$Description))#这一步是必须的，为了让柱子按顺序显示，不至于很乱
  COLS <- c("#EE0000B2", "#4DBBD5B2", "#00A087B2")#设定颜色
  
  p <- ggplot(data=go_enrich_df, aes(x=type_order,y=GeneNumber, fill=type)) + #横纵轴取值
    geom_bar(stat="identity", width=0.8) + #柱状图的宽度，可以自己设置
    scale_fill_manual(values = COLS) + ###颜色
    coord_flip() + ##这一步是让柱状图横过来，不加的话柱状图是竖着的
    xlab("GO term") + 
    ylab("Gene Number") + 
    labs(title = "GO Terms")+
    theme_bw()+theme(
      legend.background = element_rect(fill = "white", color = "black", size = 0.2),
      legend.text = element_text(face="bold",color="black",family = "Times",size=12),
      plot.title = element_text(hjust = 0.5, face = "bold",color = "black",family = "Times",size = 18),
      axis.text.x = element_text(face = "bold",color = "black",size = 14),
      axis.text.y = element_text(face = "bold",color = "black",size = 14),
      axis.title.x = element_text(face = "bold",color = "black",family = "Times",size = 18),
      axis.title.y = element_text(face = "bold",color = "black",family = "Times",size = 18),
      plot.subtitle = element_text(hjust = 0.5,family = "Times", size = 14, face = "italic", colour = "black")
    )+ scale_x_discrete(labels=function(x) str_wrap(x, width=40))

  ggsave(filename = "06.3.go_barplot.pdf", height = 8, width = 12, p)
  ggsave(filename = "06.3.go_barplot.png", height = 8, width = 12, p)
} 
saveRDS(UMAP,'UMAP.celltype.rds')
#UMAP<-readRDS('UMAP.celltype.rds')
#包列表----
pkgs<-lapply(sessionInfo()$otherPkgs,function(x){x$Version}) %>% as.data.frame() %>%t()
write.table(pkgs,'pkgs.tsv',quote = F,sep = '\t',col.names=F)
