# 4 GSVA富集分析--------------
rm(list = ls())
setwd('./')
if (! dir.exists("./10_GSVA")){
  dir.create("./10_GSVA")
}
setwd("./10_GSVA")
load('../../00_rawdata/SJZZK-20121-2/14.scRNA/05_UMAP/scRNA_UMAP.Rdata')


library(ReactomeGSA)
library(Seurat)

# 方法1：使用DietSeurat转换为兼容模式（推荐）
object <- DietSeurat(scRNA, counts = TRUE, data = TRUE, scale.data = FALSE)
DefaultAssay(object) <- "RNA"

# 检查细胞类型
cell_types <- unique(Idents(object))
print(cell_types)

# 准备基因集 - 这里以KEGG为例，您可以根据需要替换
# 您需要准备自己的基因集，例如：
library(msigdbr)
# 获取KEGG基因集
kegg_sets <- msigdbr(species = "Homo sapiens", category = "C2", subcategory = "CP:KEGG")
# 转换为list格式
gene_sets <- split(kegg_sets$gene_symbol, kegg_sets$gs_name)

# 如果上面的基因集太大，可以用一个小的测试集
# 或者使用Reactome通路
reactome_sets <- msigdbr(species = "Homo sapiens", category = "C2", subcategory = "CP:REACTOME")
gene_sets <- split(reactome_sets$gene_symbol, reactome_sets$gs_name)

# 提取表达矩阵 - 使用兼容模式后的对象
expr_matrix <- GetAssayData(object, slot = "data")  # 使用归一化数据
expr_matrix <- as.matrix(expr_matrix)

# 确保基因集与表达矩阵匹配
filtered_gene_sets <- lapply(gene_sets, function(genes) {
  intersect(genes, rownames(expr_matrix))
})
# 移除空的基因集
filtered_gene_sets <- filtered_gene_sets[sapply(filtered_gene_sets, length) > 0]

print(paste("剩余基因集数量:", length(filtered_gene_sets)))

gsva_result <- analyse_sc_clusters(object, verbose = TRUE)
# saveRDS(gsva_result,"gsva_result.rds")
##筛选p小于0.05 默认就是筛选
pathway_expression <- pathways(gsva_result)
colnames(pathway_expression) <- gsub("\\.Seurat", "", colnames(pathway_expression))
write.csv(pathway_expression,file = 'reactomegsa_object.csv',quote = F,row.names = F)

# find the maximum differently expressed pathway
max_difference <- do.call(rbind, apply(pathway_expression, 1, function(row) {
  values <- as.numeric(row[2:length(row)])
  return(data.frame(name = row[1], min = min(values), max = max(values)))
}))

max_difference$diff <- max_difference$max - max_difference$min
max_difference <- max_difference[order(max_difference$diff, decreasing = T), ]

write.csv(max_difference,"max_difference.csv")
max_difference$name[1:10]
plot_num = 10
plot_gsva <- pathway_expression[rownames(max_difference[1:plot_num,]),]


p <- pheatmap::pheatmap(
  plot_gsva[,-1],   # 使用数据矩阵，不转置
  scale = "column",       # 对列进行标准化，因为现在列是原始的行
  angle_col = 45,      # 设置列名角度为45度
  cellwidth = 15,      # 设置每个单元格的宽度
  cellheight = 15,     # 设置每个单元格的高度
  labels_row = plot_gsva[,1],  # 使用数据的第一列作为行标签
  color = colorRampPalette(c("#2B739A", "white", "#F8D7DA"))(50)  # 定义颜色渐变
)

ggsave(p,file = "max_difference.png",width = 13,height = 8)
ggsave(p,file = "max_difference.pdf",width = 13,height = 8, family = "Times")







