rm(list = ls())
setwd('./')
if (! dir.exists('./00_rawdata')) {
  dir.create('./00_rawdata')
}
setwd("./00_rawdata")

library(GEOquery)
library(Biobase)
library(tidyverse)
gset<-getGEO('GSE221521',
             destdir = '.',
             GSEMatrix = T,
             getGPL = F)

gset
# $GSE221521_series_matrix.txt.gz
# ExpressionSet (storageMode: lockedEnvironment)
# assayData: 0 features, 193 samples 
# element names: exprs 
# protocolData: none
# phenoData
# sampleNames: GSM6881210 GSM6881211 ... GSM6881439 (193 total)
# varLabels: title geo_accession ... tissue:ch1 (44 total)
# varMetadata: labelDescription
# featureData: none
# experimentData: use 'experimentData(object)'
# pubMedIds: 37334311 
# Annotation: GPL24676 
#为了解全身因素与糖尿病视网膜病变之间的关系，收集了
#50名健康对照者、
#不要DM组：74名无糖尿病视网膜病变的糖尿病患者（DM组）和
#69名糖尿病视网膜病变患者（DR组）的血液样本。
#本研究中的T1 DM和T2 DM是基于1999年WHO提出的糖尿病诊断标准。
#DR的诊断基于2002年国际眼科会议提出的DR国际临床分类。
#然后，我们使用从三个患者组的RNA-seq获得的数据进行基因表达谱分析。

#expr1<-as.data.frame(exprs(gset[[1]])) #结果为空？
#gpl<-getGEO("GPL24676",destdir = '.')
#gpl<-Table(gpl) #结果也为空？没有数据,下载附件数据
#GEO网站下载，直接用服务器上的
#gset$GSE221521_series_matrix.txt.gz@experimentData@other$supplementary_file :
#https://ftp.ncbi.nlm.nih.gov/geo/series/GSE221nnn/GSE221521/suppl/GSE221521_gene_expression.xls.gz
#expr <- read.delim2('/data/nas1/liky/project/20_CDQL-0430-9/00_rawdata/GSE221521_gene_expression.xls.gz',quote = ',') 附件数据缺失
#跳过这个方法，用/nas1/luchunlin/test/shilin.YQKM-20409-1/r-0.rawdata.r或
#/data/nas1/yuanshilin/project/05_YQKM-20409-1/r-00.rawdata.R
if(F){
  dat_expr <- expr[,-c(1,3:5)] #去ensembl gene_id description gene type
  count <- dat_expr %>% dplyr::select(ends_with(c('gene_name','count'))) #dat_expr[,c(1,195:387)] #colname _count
  fpkm  <- dat_expr %>% dplyr::select(ends_with(c('gene_name','FPKM'))) #dat_expr[,c(1,2:194)] #colname _FPKM
  
  #count------
  dat_expr.count<-count %>%
    mutate(rowMean=rowMeans(.[grep('_count',names(.))]))%>%    ## 求出平均数
    arrange(desc(rowMean))%>%       ## 把表达量的平均值从大到小排序
    distinct(gene_name,.keep_all = T)%>%      ## symbol留下第一个
    dplyr::select(-rowMean)%>%     ## 反向选择去除rowMean这一列
    tibble::column_to_rownames(colnames(.)[1])   ## 把第一列变成行名并删除
  colnames(dat_expr.count) <- gsub('_count','',colnames(dat_expr.count))
  
  #fpkm------
  dat_expr.fpkm<-fpkm %>%
    mutate(rowMean=rowMeans(.[grep('_count',names(.))]))%>%    ## 求出平均数
    arrange(desc(rowMean))%>%       ## 把表达量的平均值从大到小排序
    distinct(gene_name,.keep_all = T)%>%      ## symbol留下第一个
    dplyr::select(-rowMean)%>%     ## 反向选择去除rowMean这一列
    tibble::column_to_rownames(colnames(.)[1])   ## 把第一列变成行名并删除
  colnames(dat_expr.fpkm) <- gsub('_FPKM','',colnames(dat_expr.count))
  
  
  pcg2 <- read.delim2('/data/nas1/luchunlin/pipeline/PCG/PCG.xls(v22)')
  pcg1 <- read.delim2('/data/nas1/yuanshilin/Database/TCGA/PCG.xls(v22)')
  pcg<-expr %>% dplyr::filter(gene_type =='protein_coding') %>% select(gene_name) #直接用数据自带的gene_type比用外部数据要多出9977-9152=825个基因
  #dat_expr.count <- dat_expr.count[rownames(dat_expr.count) %in% pcg$gene_name,] %>% na.omit()
  dat_expr.count <- dat_expr.count[rownames(dat_expr.count) %in% pcg,] %>% na.omit()
  dat_expr.count <- dat_expr.count[order(rownames(dat_expr.count)),]
  dat_expr.fpkm <- dat_expr.fpkm[rownames(dat_expr.fpkm) %in% pcg,] %>% na.omit()
  dat_expr.fpkm <- dat_expr.fpkm[order(rownames(dat_expr.fpkm)),]
}
#if(F) end
urld <- "https://www.ncbi.nlm.nih.gov/geo/download/?format=file&type=rnaseq_counts"
file<-'Human.GRCh38.p13.annot.tsv.gz'
if(!file.exists(file)){
  path<-paste(urld, "&file=",file, sep="")
  download.file(url = path,destfile = file)
}
annot <- data.table::fread(file, header=T, quote="", stringsAsFactors=F, data.table=F)
rownames(annot) <- annot$GeneID
probe2symobl<-annot %>%
  filter(GeneType =='protein-coding') %>%
  dplyr::select('GeneID','Symbol')%>%
  filter('Symbol'!='')%>%
  separate('Symbol',c('symbol','drop'),sep = '///')%>%
  dplyr::select(-drop)
probe2symobl=probe2symobl[probe2symobl$symbol!='',]
colnames(probe2symobl)[1] <- 'ID'
probe2symobl$ID <- as.character(probe2symobl$ID)
getM<-function(acc,file){
  if(!file.exists(file)){
    path<-paste(urld, "&acc=",acc,"&file=",file, sep="")
    download.file(url = path,destfile = file)
  }
  tbl<-as.matrix(data.table::fread(file, header=T, colClasses="integer"), rownames="GeneID")
  dat<-as.data.frame(tbl)
  dat$ID <- rownames(dat)
  dat$ID <- as.character(dat$ID)
  dat <- dat %>%
    inner_join(probe2symobl,by='ID')%>%
    dplyr::select(-ID)%>%     ## 去除多余信息
    dplyr::select(symbol,everything())%>%     ## 重新排列
    mutate(rowMean=rowMeans(.[grep('GSM',names(.))]))%>%    ## 求出平均数
    arrange(desc(rowMean))%>%       ## 把表达量的平均值从大到小排序
    distinct(symbol,.keep_all = T)%>%      ## symbol留下第一个
    dplyr::select(-rowMean)%>%     ## 反向选择去除rowMean这一列
    tibble::column_to_rownames(colnames(.)[1])   ## 把第一列变成行名并删除
  return(dat)
}
dat_expr.count<-getM('GSE221521','GSE221521_raw_counts_GRCh38.p13_NCBI.tsv.gz')
dat_expr.fpkm<-getM('GSE221521','GSE221521_norm_counts_FPKM_GRCh38.p13_NCBI.tsv.gz')
#dat_expr.tpm<-getM('GSE221521','GSE221521_norm_counts_TPM_GRCh38.p13_NCBI.tsv.gz')

#GSE221521---------
rm(list = ls())
setwd('./')
if (! dir.exists('./00_rawdata')) {
  dir.create('./00_rawdata')
}
setwd("./00_rawdata")

library(GEOquery)
library(Biobase)
library(tidyverse)
gset<-getGEO('GSE221521',
             destdir = '.',
             GSEMatrix = T,
             getGPL = F)

gset
# $GSE221521_series_matrix.txt.gz
# ExpressionSet (storageMode: lockedEnvironment)
# assayData: 0 features, 193 samples 
# element names: exprs 
# protocolData: none
# phenoData
# sampleNames: GSM6881210 GSM6881211 ... GSM6881439 (193 total)
# varLabels: title geo_accession ... tissue:ch1 (44 total)
# varMetadata: labelDescription
# featureData: none
# experimentData: use 'experimentData(object)'
# pubMedIds: 37334311 
# Annotation: GPL24676 
#为了解全身因素与糖尿病视网膜病变之间的关系，收集了
#50名健康对照者、
#不要DM组：74名无糖尿病视网膜病变的糖尿病患者（DM组）和
#69名糖尿病视网膜病变患者（DR组）的血液样本。
#本研究中的T1 DM和T2 DM是基于1999年WHO提出的糖尿病诊断标准。
#DR的诊断基于2002年国际眼科会议提出的DR国际临床分类。
#然后，我们使用从三个患者组的RNA-seq获得的数据进行基因表达谱分析。

#expr1<-as.data.frame(exprs(gset[[1]])) #结果为空？
#gpl<-getGEO("GPL24676",destdir = '.')
#gpl<-Table(gpl) #结果也为空？没有数据,下载附件数据
#GEO网站下载，直接用服务器上的
#gset$GSE221521_series_matrix.txt.gz@experimentData@other$supplementary_file :
#https://ftp.ncbi.nlm.nih.gov/geo/series/GSE221nnn/GSE221521/suppl/GSE221521_gene_expression.xls.gz
#expr <- read.delim2('/data/nas1/liky/project/20_CDQL-0430-9/00_rawdata/GSE221521_gene_expression.xls.gz',quote = ',') 附件数据缺失
#跳过这个方法，用/nas1/luchunlin/test/shilin.YQKM-20409-1/r-0.rawdata.r或
#/data/nas1/yuanshilin/project/05_YQKM-20409-1/r-00.rawdata.R
if(F){
dat_expr <- expr[,-c(1,3:5)] #去ensembl gene_id description gene type
count <- dat_expr %>% dplyr::select(ends_with(c('gene_name','count'))) #dat_expr[,c(1,195:387)] #colname _count
fpkm  <- dat_expr %>% dplyr::select(ends_with(c('gene_name','FPKM'))) #dat_expr[,c(1,2:194)] #colname _FPKM

#count------
dat_expr.count<-count %>%
  mutate(rowMean=rowMeans(.[grep('_count',names(.))]))%>%    ## 求出平均数
  arrange(desc(rowMean))%>%       ## 把表达量的平均值从大到小排序
  distinct(gene_name,.keep_all = T)%>%      ## symbol留下第一个
  dplyr::select(-rowMean)%>%     ## 反向选择去除rowMean这一列
  tibble::column_to_rownames(colnames(.)[1])   ## 把第一列变成行名并删除
colnames(dat_expr.count) <- gsub('_count','',colnames(dat_expr.count))

#fpkm------
dat_expr.fpkm<-fpkm %>%
  mutate(rowMean=rowMeans(.[grep('_count',names(.))]))%>%    ## 求出平均数
  arrange(desc(rowMean))%>%       ## 把表达量的平均值从大到小排序
  distinct(gene_name,.keep_all = T)%>%      ## symbol留下第一个
  dplyr::select(-rowMean)%>%     ## 反向选择去除rowMean这一列
  tibble::column_to_rownames(colnames(.)[1])   ## 把第一列变成行名并删除
colnames(dat_expr.fpkm) <- gsub('_FPKM','',colnames(dat_expr.count))


pcg2 <- read.delim2('/data/nas1/luchunlin/pipeline/PCG/PCG.xls(v22)')
pcg1 <- read.delim2('/nas1/yuanshilin/Database/TCGA/PCG.xls(v22)')
pcg<-expr %>% dplyr::filter(gene_type =='protein_coding') %>% select(gene_name) #直接用数据自带的gene_type比用外部数据要多出9977-9152=825个基因
#dat_expr.count <- dat_expr.count[rownames(dat_expr.count) %in% pcg$gene_name,] %>% na.omit()
dat_expr.count <- dat_expr.count[rownames(dat_expr.count) %in% pcg,] %>% na.omit()
dat_expr.count <- dat_expr.count[order(rownames(dat_expr.count)),]
dat_expr.fpkm <- dat_expr.fpkm[rownames(dat_expr.fpkm) %in% pcg,] %>% na.omit()
dat_expr.fpkm <- dat_expr.fpkm[order(rownames(dat_expr.fpkm)),]
}
#if(F) end
urld <- "https://www.ncbi.nlm.nih.gov/geo/download/?format=file&type=rnaseq_counts"
file<-'Human.GRCh38.p13.annot.tsv.gz'
if(!file.exists(file)){
  path<-paste(urld, "&file=",file, sep="")
  download.file(url = path,destfile = file)
}
annot <- data.table::fread(file, header=T, quote="", stringsAsFactors=F, data.table=F)
rownames(annot) <- annot$GeneID
probe2symobl<-annot %>%
  filter(GeneType =='protein-coding') %>%
  dplyr::select('GeneID','Symbol')%>%
  filter('Symbol'!='')%>%
  separate('Symbol',c('symbol','drop'),sep = '///')%>%
  dplyr::select(-drop)
probe2symobl=probe2symobl[probe2symobl$symbol!='',]
colnames(probe2symobl)[1] <- 'ID'
probe2symobl$ID <- as.character(probe2symobl$ID)
getM<-function(acc,file){
  if(!file.exists(file)){
    path<-paste(urld, "&acc=",acc,"&file=",file, sep="")
    download.file(url = path,destfile = file)
  }
  tbl<-as.matrix(data.table::fread(file, header=T, colClasses="integer"), rownames="GeneID")
  dat<-as.data.frame(tbl)
  dat$ID <- rownames(dat)
  dat$ID <- as.character(dat$ID)
  dat <- dat %>%
    inner_join(probe2symobl,by='ID')%>%
    dplyr::select(-ID)%>%     ## 去除多余信息
    dplyr::select(symbol,everything())%>%     ## 重新排列
    mutate(rowMean=rowMeans(.[grep('GSM',names(.))]))%>%    ## 求出平均数
    arrange(desc(rowMean))%>%       ## 把表达量的平均值从大到小排序
    distinct(symbol,.keep_all = T)%>%      ## symbol留下第一个
    dplyr::select(-rowMean)%>%     ## 反向选择去除rowMean这一列
    tibble::column_to_rownames(colnames(.)[1])   ## 把第一列变成行名并删除
  return(dat)
}
dat_expr.count<-getM('GSE221521','GSE221521_raw_counts_GRCh38.p13_NCBI.tsv.gz')
dat_expr.fpkm<-getM('GSE221521','GSE221521_norm_counts_FPKM_GRCh38.p13_NCBI.tsv.gz')
#dat_expr.tpm<-getM('GSE221521','GSE221521_norm_counts_TPM_GRCh38.p13_NCBI.tsv.gz')
dat_expr.count <- dat_expr.count[,group$sample] %>% lance::lc.tableToNum()
dat_expr.fpkm <- dat_expr.fpkm[,group$sample] %>% lance::lc.tableToNum()
dat_expr.fpkm.log <- log2(dat_expr.fpkm + 1)
write.csv(dat_expr.count, file = '01.count_GSE221521.csv',row.names = T)
write.csv(dat_expr.fpkm.log, file = '01.fpkm.log_GSE221521.csv',row.names = T)
write.csv(dat_expr.fpkm, file = '01.fpkm_GSE221521.csv',row.names = T)

pd<-pData(gset[[1]])
colnames(pd)
#去掉DM
group <- data.frame(sample=pd$geo_accession,type=pd$title)
group$type <- substr(group$type,13,14)
table(group$type)
group <- group[which(group$type %in% c('Co','DR')),]
group$type <- ifelse(group$type == 'Co','control','DR')
#nchar('survival status (0: alive or censored, 1: dead) : ')
group <- group[order(group$type),]
table(group$type)
# control      DR 
# 50      69

#identical(rownames(dat_expr.count), rownames(dat_expr.fpkm.log))

identical(colnames(dat_expr.count), colnames(dat_expr.fpkm.log))
#dat_expr.log <- dat_expr
#write.csv(dat_expr, file = '02.expr_GSE30219.csv',row.names = T)
write.csv(group, file = '01.group_GSE221521.csv',row.names = F)
# 

if(T){
# 3. GSE13355 ---------------------------------------
rm(list = ls())
setwd('./')
if(!dir.exists('./00_rawdata')){
  dir.create('./00_rawdata')
}
setwd('./00_rawdata/')

### 常规情况（非高通量数据可以在GEO数据库直接用getGEO函数读取，否则要自己手动到网站下载表达矩阵）
library(GEOquery)
library(tidyverse)
library(lance)

GEO_data <- 'GSE13355'
gene_annotation <- 'GPL570'

if(!dir.exists(paste0(GEO_data))){
  dir.create(paste0(GEO_data))
}
setwd(paste0(GEO_data))

gset <- getGEO(GEO_data , # 前面创建GEO_data对象
               destdir = '.',
               GSEMatrix = T,
               getGPL = F) # getGEO函数自动从官网中获取对应的数据集
# gset$GSE89748_series_matrix.txt.gz@annotation
expr <- exprs(gset[[1]]) # 将获取的数据集的表达矩阵提取出来，如果没有表达矩阵，说明是高通量数据需要到网站自己下载
qx <- as.numeric(quantile(expr, c(0., 0.25, 0.5, 0.75, 0.99, 1.0), na.rm=T))
LogC <- (qx[5] > 100) ||
  (qx[6]-qx[1] > 50 && qx[2] > 0) ||
  (qx[2] > 0 && qx[2] < 1 && qx[4] > 1 && qx[4] < 2)
if (LogC) { 
  expr[which(expr <= 0)] <- 0
  expr <- log2(expr + 1) 
  print("log2 transform finished")
}else{
  print("log2 transform not needed")
}
expr <- as.data.frame(expr)
range(expr)

gpl <- getGEO('GSE13355', destdir = '.' , AnnotGPL = TRUE ) 
gpl <- featureData(gpl[[1]])
colnames(gpl)
# gpl$gene_assignment<-data.frame(sapply(gpl$gene_assignment,function(x)unlist(strsplit(x," // "))[2]),
#                                 stringsAsFactors=F)[,1]
probe2symbol <- dplyr::select(gpl@data, 'ID', 'Gene symbol')
probe2symbol <- probe2symbol %>% filter(probe2symbol$`Gene symbol`!= '')  #yes
probe2symbol <- separate(probe2symbol, 'Gene symbol', into = c('symbol', 'drop'), sep = '//')
probe2symbol <- dplyr::select(probe2symbol, -drop)
names(probe2symbol) <- c('ID', 'symbol')
probe2symbol <- probe2symbol[probe2symbol$symbol != ' --- ', ]
probe2symbol$symbol <- gsub(' ', '', probe2symbol$symbol)


dat <- expr
dat$ID <- rownames(dat)
dat$ID <- as.character(dat$ID)
probe2symbol$ID <- as.character(probe2symbol$ID)

dat <- dat %>%
  merge(probe2symbol, by='ID')%>%
  dplyr::select(-ID)%>%     ## 去除多余信息
  dplyr::select(symbol, everything())%>%     ## 重新排列
  mutate(rowMean = rowMeans(.[grep('GSM', names(.))]))%>%    ## 求出平均数
  arrange(desc(rowMean))%>%       ## 把表达量的平均值从大到小排序
  distinct(symbol, .keep_all = T)%>%      ## symbol留下第一个
  dplyr::select(-rowMean)%>%     ## 反向选择去除rowMean这一列
  tibble::column_to_rownames(colnames(.)[1])   ## 把第一列变成行名并删除

# protein_gene <- read.delim2('/data/nas3/wuyanyu/pipline/PCG/PCG.xls(v22)')
# dat <- dat[rownames(dat) %in% protein_gene$gene_name, ]

a <- gset[[1]]
pd <- pData(a)
table(pd$characteristics_ch1)
group <- data.frame(sample = pd$geo_accession, group = pd$characteristics_ch1)
table(group$group)
group <- group %>% filter(!(group %in% c("uninvolved skin from cases")))
group$group <- ifelse(group$group == 'normal skin from controls', 'control', 'psoriasis')
table(group$group) 

dat <- dat[, colnames(dat) %in% group$sample]
dat <- na.omit(dat)
group <- group[group$sample %in% colnames(dat), ]

write.csv(dat, file = paste0('dat.', GEO_data, '.csv'))
write.csv(group, file = paste0('group.', GEO_data, '.csv'), row.names = F)
#GSE189005----------
rm(list = ls())

gset<-getGEO('GSE189005',
             destdir = '.',
             GSEMatrix = T,
             getGPL = F)
gset
# $GSE189005_series_matrix.txt.gz
# ExpressionSet (storageMode: lockedEnvironment)
# assayData: 0 features, 45 samples 
# element names: exprs 
# protocolData: none
# phenoData
# sampleNames: GSM5693105 GSM5693106 ... GSM5693149 (45 total)
# varLabels: title geo_accession ... tissue:ch1 (48 total)
# varMetadata: labelDescription
# featureData: none
# experimentData: use 'experimentData(object)'
# Annotation: GPL23126 

expr<-as.data.frame(exprs(gset[[1]])) #没有数据用rawdata

library(magrittr)
library(oligo)
celFiles <- list.celfiles("/data/nas1/liky/project/20_CDQL-0430-9/00_rawdata/GSE189005_RAW/",full.names=TRUE) # 不能读入压缩形式的cel文件
rawData <- read.celfiles(celFiles) #ExonFeatureSet
ppData <- rma(rawData) # ExpressionSet标准化
probe_exp <- exprs(ppData) # matrix
expr <- probe_exp

gpl <- getGEO('GPL23126', destdir=".")  #选取网站上的GPL号
gpl<-Table(gpl)
colnames(gpl)
#gpl$gene_assignment
library(tidyverse)
probe2symobl<-gpl %>%
  dplyr::select('ID','gene_assignment')%>%
  separate('gene_assignment',c('drop','Symbol'),sep = ' // ')%>%
  dplyr::select(-drop)#%>%
#dplyr::select(-drop2)
probe2symobl=probe2symobl[probe2symobl$Symbol!='',] %>% na.omit()

dat_expr<-as.data.frame(expr)
dat_expr$ID<-rownames(dat_expr)
dat_expr$ID<-as.character(dat_expr$ID)
probe2symobl$ID<-as.character(probe2symobl$ID)
dat_expr<-dat_expr %>%
  inner_join(probe2symobl,by='ID')%>%
  dplyr::select(-ID)%>%     ## 去除多余信息
  dplyr::select(Symbol,everything())%>%     ## 重新排列
  mutate(rowMean=rowMeans(.[grep('GSM',names(.))]))%>%    ## 求出平均数
  arrange(desc(rowMean))%>%       ## 把表达量的平均值从大到小排序
  distinct(Symbol,.keep_all = T)%>%      ## symbol留下第一个
  dplyr::select(-rowMean)%>%     ## 反向选择去除rowMean这一列
  tibble::column_to_rownames(colnames(.)[1])   ## 把第一列变成行名并删除
nchar('GSM5693113')
colnames(dat_expr) <- substring(colnames(dat_expr),1,10)

pcg <- read.delim2('../../../PCG.xls(v22)')
dat_expr <- dat_expr[rownames(dat_expr) %in% pcg$gene_name,] %>% na.omit()
dim(dat_expr)
#18843    45

pd<-pData(gset[[1]])
colnames(pd)
group <- data_frame(sample = rownames(pd), type = pd$title)
group <- group[order(group$type),]
group <- data_frame(sample = group$sample[c(1:9,36:45)], type = c(rep('control',9),rep('DR',10)))

dat_expr <- dat_expr[,group$sample]
identical(colnames(dat_expr),group$sample)
table(group$type)
# control      DR
# 9      10
#dat_expr.log <- dat_expr
#dat_expr.log <- log2(dat_expr+1)
# ex <- dat_expr #把需要判断的矩阵命名为ex
# qx <- as.numeric(quantile(ex, c(0., 0.25, 0.5, 0.75, 0.99, 1.0), na.rm=T))
# LogC <- (qx[5] > 100) ||
#   (qx[6]-qx[1] > 50 && qx[2] > 0) ||
#   (qx[2] > 0 && qx[2] < 1 && qx[4] > 1 && qx[4] < 2)
# if (LogC) { ex[which(ex <= 0)] <- NaN
# exprSet <- log2(ex+1)
# print("log2 transform finished")}else{print("log2 transform not needed")}
# #"log2 transform not needed"

write.csv(dat_expr, file = '02.expr_GSE189005.csv',row.names = T)
write.csv(group, file = '02.group_GSE189005.csv',row.names = F)
}


#GSE185011-----
rm(list = ls())
setwd('./')
if (! dir.exists('./00_rawdata')) {
  dir.create('./00_rawdata')
}
setwd("./00_rawdata")

library(GEOquery)
library(Biobase)
library(tidyverse)
#group----
gset<-getGEO('GSE185011',
             destdir = '.',
             GSEMatrix = T,
             getGPL = F)
pd<-pData(gset[[1]])
colnames(pd)
group <- data_frame(sample=pd$geo_accession, type=pd$title)
group$type<-gsub('Peripheral blood_','',group$type)
group$type<-substr(group$type,1,2)
group <- group[group$type=='HC' | group$type=='DR',]
group$type <- ifelse(group$type=='DR','DR','control')
group <- group[order(group$type),]
table(group$type)
write.csv(group, file = '03.group_GSE185011.csv',row.names = F)



annot <- data.table::fread('Human.GRCh38.p13.annot.tsv.gz', header=T, quote="", stringsAsFactors=F, data.table=F)
rownames(annot) <- annot$GeneID
probe2symobl<-annot %>%
  filter(GeneType =='protein-coding') %>%
  dplyr::select('GeneID','Symbol')%>%
  filter('Symbol'!='')%>%
  separate('Symbol',c('symbol','drop'),sep = '///')%>%
  dplyr::select(-drop)
probe2symobl=probe2symobl[probe2symobl$symbol!='',]
colnames(probe2symobl)[1] <- 'ID'
probe2symobl$ID <- as.character(probe2symobl$ID)
getM<-function(acc,file){
  if(!file.exists(file)){
    path<-paste(urld, "&acc=",acc,"&file=",file, sep="")
    download.file(url = path,destfile = file)
  }
  tbl<-as.matrix(data.table::fread(file, header=T, colClasses="integer"), rownames="GeneID")
  dat<-as.data.frame(tbl)
  dat$ID <- rownames(dat)
  dat$ID <- as.character(dat$ID)
  dat <- dat %>%
    inner_join(probe2symobl,by='ID')%>%
    dplyr::select(-ID)%>%     ## 去除多余信息
    dplyr::select(symbol,everything())%>%     ## 重新排列
    mutate(rowMean=rowMeans(.[grep('GSM',names(.))]))%>%    ## 求出平均数
    arrange(desc(rowMean))%>%       ## 把表达量的平均值从大到小排序
    distinct(symbol,.keep_all = T)%>%      ## symbol留下第一个
    dplyr::select(-rowMean)%>%     ## 反向选择去除rowMean这一列
    tibble::column_to_rownames(colnames(.)[1])   ## 把第一列变成行名并删除
  return(dat)
}




dat_expr.count<-getM('GSE185011','GSE185011_raw_counts_GRCh38.p13_NCBI.tsv.gz')
dat_expr.fpkm<-getM('GSE185011','GSE185011_norm_counts_FPKM_GRCh38.p13_NCBI.tsv.gz')
dat_expr.count <- dat_expr.count[,group$sample] %>% lance::lc.tableToNum()
dat_expr.fpkm <- dat_expr.fpkm[,group$sample] %>% lance::lc.tableToNum()
dat_expr.fpkm.log <- log2(dat_expr.fpkm + 1)
write.csv(dat_expr.count, file = '03.count_GSE185011.csv',row.names = T)
write.csv(dat_expr.fpkm.log, file = '03.fpkm.log_GSE185011.csv',row.names = T)
write.csv(dat_expr.fpkm, file = '03.fpkm_GSE185011.csv',row.names = T)


#单细胞 GSE248284   GPL24676----



#包列表
pkgs<-lapply(sessionInfo()$otherPkgs,function(x){x$Version}) %>% as.data.frame() %>%t()
write.table(pkgs,'pkgs.tsv',quote = F,sep = '\t',col.names=F)










#189005----------------------
rm(list = ls())
setwd('./')
if(!dir.exists('./00_rawdata')){
  dir.create('./00_rawdata')
}
setwd('./00_rawdata/')

### 常规情况（非高通量数据可以在GEO数据库直接用getGEO函数读取，否则要自己手动到网站下载表达矩阵）
library(GEOquery)
library(tidyverse)
library(lance)

GEO_data <- 'GSE189005'
gene_annotation <- 'GPL23126'

if(!dir.exists(paste0(GEO_data))){
  dir.create(paste0(GEO_data))
}
setwd(paste0(GEO_data))

gset <- getGEO(GEO_data , # 前面创建GEO_data对象
               destdir = '.',
               GSEMatrix = T,
               getGPL = F) # getGEO函数自动从官网中获取对应的数据集
# gset$GSE89748_series_matrix.txt.gz@annotation
expr <- exprs(gset[[1]]) # 将获取的数据集的表达矩阵提取出来，如果没有表达矩阵，说明是高通量数据需要到网站自己下载
qx <- as.numeric(quantile(expr, c(0., 0.25, 0.5, 0.75, 0.99, 1.0), na.rm=T))
LogC <- (qx[5] > 100) ||
  (qx[6]-qx[1] > 50 && qx[2] > 0) ||
  (qx[2] > 0 && qx[2] < 1 && qx[4] > 1 && qx[4] < 2)
if (LogC) { 
  expr[which(expr <= 0)] <- 0
  expr <- log2(expr + 1) 
  print("log2 transform finished")
}else{
  print("log2 transform not needed")
}
expr <- as.data.frame(expr)
range(expr)

gpl <- getGEO('GSE13355', destdir = '.' , AnnotGPL = TRUE ) 
gpl <- featureData(gpl[[1]])
colnames(gpl)
# gpl$gene_assignment<-data.frame(sapply(gpl$gene_assignment,function(x)unlist(strsplit(x," // "))[2]),
#                                 stringsAsFactors=F)[,1]
probe2symbol <- dplyr::select(gpl@data, 'ID', 'Gene symbol')
probe2symbol <- probe2symbol %>% filter(probe2symbol$`Gene symbol`!= '')  #yes
probe2symbol <- separate(probe2symbol, 'Gene symbol', into = c('symbol', 'drop'), sep = '//')
probe2symbol <- dplyr::select(probe2symbol, -drop)
names(probe2symbol) <- c('ID', 'symbol')
probe2symbol <- probe2symbol[probe2symbol$symbol != ' --- ', ]
probe2symbol$symbol <- gsub(' ', '', probe2symbol$symbol)


dat <- expr
dat$ID <- rownames(dat)
dat$ID <- as.character(dat$ID)
probe2symbol$ID <- as.character(probe2symbol$ID)

dat <- dat %>%
  merge(probe2symbol, by='ID')%>%
  dplyr::select(-ID)%>%     ## 去除多余信息
  dplyr::select(symbol, everything())%>%     ## 重新排列
  mutate(rowMean = rowMeans(.[grep('GSM', names(.))]))%>%    ## 求出平均数
  arrange(desc(rowMean))%>%       ## 把表达量的平均值从大到小排序
  distinct(symbol, .keep_all = T)%>%      ## symbol留下第一个
  dplyr::select(-rowMean)%>%     ## 反向选择去除rowMean这一列
  tibble::column_to_rownames(colnames(.)[1])   ## 把第一列变成行名并删除

# protein_gene <- read.delim2('../../../PCG.xls(v22)')
# dat <- dat[rownames(dat) %in% protein_gene$gene_name, ]

a <- gset[[1]]
pd <- pData(a)
table(pd$characteristics_ch1)
group <- data.frame(sample = pd$geo_accession, group = pd$characteristics_ch1)
table(group$group)
group <- group %>% filter(!(group %in% c("uninvolved skin from cases")))
group$group <- ifelse(group$group == 'normal skin from controls', 'control', 'psoriasis')
table(group$group) 

dat <- dat[, colnames(dat) %in% group$sample]
dat <- na.omit(dat)
group <- group[group$sample %in% colnames(dat), ]

write.csv(dat, file = paste0('dat.', GEO_data, '.csv'))
write.csv(group, file = paste0('group.', GEO_data, '.csv'), row.names = F)





#GSE185011----------------------
rm(list = ls())
setwd('./')
if(!dir.exists('./00_rawdata')){
  dir.create('./00_rawdata')
}
setwd('./00_rawdata/')

library(GEOquery)
GEO_data <- 'GSE185011'

if(!dir.exists(paste0(GEO_data))){
  dir.create(paste0(GEO_data))
}
setwd(paste0(GEO_data))

urld <- "https://www.ncbi.nlm.nih.gov/geo/download/?format=file&type=rnaseq_counts"
path <- paste(urld, "acc=GSE185011", "file=GSE185011_raw_counts_GRCh38.p13_NCBI.tsv.gz", sep="&");
tbl <- as.matrix(data.table::fread(path, header=T, colClasses="integer"), rownames="GeneID")
ncol(tbl)
expr <- as.data.frame(tbl)
write.csv(expr, paste0(GEO_data, '__raw_count.csv'))
expr <- read.csv('./GSE185011__raw_count.csv', row.names = 1, check.names = F)
# load gene annotations
apath <- paste(urld, "type=rnaseq_counts", "file=Human.GRCh38.p13.annot.tsv.gz", sep="&")
annot <- data.table::fread(apath, header=T, quote="", stringsAsFactors=F, data.table=F)
rownames(annot) <- annot$GeneID
write.csv(annot, 'gene_annoation.csv')
annot <- read.csv('./gene_annoation.csv', row.names = 1, check.names = F)

table(annot$GeneType)
annot <- annot[annot$GeneType == 'protein-coding', ]
colnames(annot)
probe2symbol <- dplyr::select(annot, 'GeneID', 'Symbol')
probe2symbol <- filter(probe2symbol, `Symbol` != '')
names(probe2symbol) <- c('ID', 'symbol')
probe2symbol <- na.omit(probe2symbol)

expr$ID <- rownames(expr)
dat <- expr
dat$ID <- as.character(dat$ID)
probe2symbol$ID <- as.character(probe2symbol$ID)

dat <- dat %>%
  merge(probe2symbol, by='ID')%>%
  dplyr::select(-ID)%>%     ## 去除多余信息
  dplyr::select(symbol, everything())%>%     ## 重新排列
  mutate(rowMean = rowMeans(.[grep('GSM', names(.))]))%>%    ## 求出平均数
  arrange(desc(rowMean))%>%       ## 把表达量的平均值从大到小排序
  distinct(symbol, .keep_all = T)%>%      ## symbol留下第一个
  dplyr::select(-rowMean)%>%     ## 反向选择去除rowMean这一列
  tibble::column_to_rownames(colnames(.)[1])   ## 把第一列变成行名并删除

gset <- getGEO(GEO_data ,
               destdir = '.',
               GSEMatrix = T,
               getGPL = F)
a <- gset[[1]]
pd <- pData(a)
# write.csv(pd, 'pd.csv')
table(pd$title)
group <- data.frame(sample = pd$geo_accession, group = pd$title)
group$group<-gsub('Peripheral blood_','',group$group)
group$group<-substr(group$group,1,2)
table(group$group)
group <- group %>% filter(!(group %in% c("DN","DP", "T2")))  # 删除不需要的分组
group$group <- ifelse(group$group == 'HC', 'control', 'DR')
table(group$group)
group <- group[order(group$group), ]


colnames(dat)
group$sample
dat <- dat[, colnames(dat) %in% group$sample]
dat <- na.omit(dat)
group <- group[group$sample %in% colnames(dat), ]

write.csv(dat, file = paste0('dat.', GEO_data, '_count.csv'))
write.csv(group, file = paste0('group.', GEO_data, '.csv'), row.names = F)

## FPKM
urld <- "https://www.ncbi.nlm.nih.gov/geo/download/?format=file&type=rnaseq_counts"
path <- paste(urld, "acc=GSE185011", "file=GSE185011_norm_counts_FPKM_GRCh38.p13_NCBI.tsv.gz", sep="&");
tbl <- as.matrix(data.table::fread(path, header=T, colClasses="integer"), rownames="GeneID")
ncol(tbl)
expr <- as.data.frame(tbl)
write.csv(expr, paste0(GEO_data, '__raw_fpkm.csv'))
expr <- read.csv('./GSE185011__raw_fpkm.csv', row.names = 1, check.names = F)
# load gene annotations
apath <- paste(urld, "type=rnaseq_counts", "file=Human.GRCh38.p13.annot.tsv.gz", sep="&")
annot <- data.table::fread(apath, header=T, quote="", stringsAsFactors=F, data.table=F)
rownames(annot) <- annot$GeneID
write.csv(annot, 'gene_annoation.csv')
annot <- read.csv('./gene_annoation.csv', row.names = 1, check.names = F)

table(annot$GeneType)
annot <- annot[annot$GeneType == 'protein-coding', ]
colnames(annot)
probe2symbol <- dplyr::select(annot, 'GeneID', 'Symbol')
probe2symbol <- filter(probe2symbol, `Symbol` != '')
names(probe2symbol) <- c('ID', 'symbol')
probe2symbol <- na.omit(probe2symbol)

expr$ID <- rownames(expr)
dat <- expr
dat$ID <- as.character(dat$ID)
probe2symbol$ID <- as.character(probe2symbol$ID)

dat <- dat %>%
  merge(probe2symbol, by='ID')%>%
  dplyr::select(-ID)%>%     ## 去除多余信息
  dplyr::select(symbol, everything())%>%     ## 重新排列
  mutate(rowMean = rowMeans(.[grep('GSM', names(.))]))%>%    ## 求出平均数
  arrange(desc(rowMean))%>%       ## 把表达量的平均值从大到小排序
  distinct(symbol, .keep_all = T)%>%      ## symbol留下第一个
  dplyr::select(-rowMean)%>%     ## 反向选择去除rowMean这一列
  tibble::column_to_rownames(colnames(.)[1])   ## 把第一列变成行名并删除


colnames(dat)
group$sample
dat <- dat[, colnames(dat) %in% group$sample]
max(dat)
dat <- na.omit(dat)
qx <- as.numeric(quantile(dat, c(0., 0.25, 0.5, 0.75, 0.99, 1.0), na.rm=T))
LogC <- (qx[5] > 100) ||
  (qx[6]-qx[1] > 50 && qx[2] > 0) ||
  (qx[2] > 0 && qx[2] < 1 && qx[4] > 1 && qx[4] < 2)
if (LogC) {
  dat[which(dat < 0)] <- 0
  dat <- log2(dat + 1)
  print("log2 transform finished")
}else{
  print("log2 transform not needed")
}
dat <- as.data.frame(dat)
range(dat)
# dat <- log(dat +0.1)
write.csv(dat, file = paste0('dat.', GEO_data, '_fpkm.csv'))
