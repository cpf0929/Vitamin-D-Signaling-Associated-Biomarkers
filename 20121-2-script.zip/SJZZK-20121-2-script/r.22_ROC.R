# 1. 训练集单基因ROC---------------------------
rm(list = ls())
setwd("./")
if (! dir.exists("./15_ROC")){
  dir.create("./15_ROC")
}
setwd("./15_ROC")

library(lance)
library(tidyverse)
library(ROCR)
library(ggplot2)
library(pROC)

GEO_data <- 'GSE221521'

if(!dir.exists(paste0(GEO_data))){
  dir.create(paste0(GEO_data))
}
setwd(paste0(GEO_data))

train_data <- read.csv(file = "../../00_rawdata/SJZZK-20121-2/00_rawdata/01.fpkm_GSE221521.csv", row.names = 1) %>% lc.tableToNum()
biomarker <- c('SLC36A1','RAB23')
group <- read.csv(file = '../../00_rawdata/SJZZK-20121-2/00_rawdata/01.group_GSE221521.csv')
colnames(group) <- c('sample','group')

table(group$group)

group$group <- as.factor(group$group)
biomarker <- as.data.frame(biomarker)
colnames(biomarker) <- 'symbol'
biomarker_exp <- train_data[biomarker$symbol, ] %>% t() # 整理后的数据行为样本名，列为筛选基因的表达量(8个筛选基因)

# 新建空白数据框
inter_gene <- data.frame()
i <- 1

for (i in c(1 : nrow(biomarker))) {
  roc <- roc(group$group, biomarker_exp[, i], levels = c('control', 'DR'))
  if (roc$auc > 0) {
    inter_gene <- rbind(inter_gene, biomarker[i, ])

    png(paste0('0', i, ".", colnames(biomarker_exp)[i], ".png"), width = 4, height = 4, units = 'in', res = 600)
    plot(roc,
         print.auc=T,
         print.auc.x=0.4,print.auc.y=0.5,
         print.auc.pattern='AUC=%.3f',
         #auc.polygon=T,
         #auc.polygon.con="#fff7f7",
         grid=c(0.5,0.2),
         grid.col=c("black","black"),
         #print.thres=T,
         main=paste0(colnames(biomarker_exp)[i]),
         col="#FF2E63",
         legacy.axes=T)
    dev.off()
    pdf(paste0('0', i, ".", colnames(biomarker_exp)[i], ".pdf"),width = 4, height = 4)
    plot(roc,
         print.auc=T,
         print.auc.x=0.4,print.auc.y=0.5,
         #auc.polygon=T,
         #auc.polygon.con="#fff7f7",
         grid=c(0.5,0.2),
         grid.col=c("black","black"),
         #print.thres=T,
         main=paste0(colnames(biomarker_exp)[i]),
         col="#FF2E63",
         legacy.axes=T)
    dev.off()
  }
}







# 1. 训练集单基因ROC---------------------------
rm(list = ls())
setwd("./")
if (! dir.exists("./15_ROC")){
  dir.create("./15_ROC")
}
setwd("./15_ROC")

library(lance)
library(tidyverse)
library(ROCR)
library(ggplot2)
library(pROC)

GEO_data <- 'GSE189005 '

if(!dir.exists(paste0(GEO_data))){
  dir.create(paste0(GEO_data))
}
setwd(paste0(GEO_data))

train_data <- read.csv(file = "../../00_rawdata/SJZZK-20121-2/00_rawdata/02.expr_GSE189005.csv", row.names = 1) %>% lc.tableToNum()
biomarker <- c('SLC36A1','RAB23')
group <- read.csv(file = '../../00_rawdata/SJZZK-20121-2/00_rawdata/02.group_GSE189005.csv')
colnames(group) <- c('sample','group')

table(group$group)

group$group <- as.factor(group$group)
biomarker <- as.data.frame(biomarker)
colnames(biomarker) <- 'symbol'
biomarker_exp <- train_data[biomarker$symbol, ] %>% t() # 整理后的数据行为样本名，列为筛选基因的表达量(8个筛选基因)

# 新建空白数据框
inter_gene <- data.frame()
i <- 1

for (i in c(1 : nrow(biomarker))) {
  roc <- roc(group$group, biomarker_exp[, i], levels = c('control', 'DR'))
  if (roc$auc > 0) {
    inter_gene <- rbind(inter_gene, biomarker[i, ])
    
    png(paste0('0', i, ".", colnames(biomarker_exp)[i], ".png"), width = 4, height = 4, units = 'in', res = 600)
    plot(roc,
         print.auc=T,
         print.auc.x=0.4,print.auc.y=0.5,
         print.auc.pattern='AUC=%.3f',
         #auc.polygon=T,
         #auc.polygon.con="#fff7f7",
         grid=c(0.5,0.2),
         grid.col=c("black","black"),
         #print.thres=T,
         main=paste0(colnames(biomarker_exp)[i]),
         col="#FF2E63",
         legacy.axes=T)
    dev.off()
    pdf(paste0('0', i, ".", colnames(biomarker_exp)[i], ".pdf"),width = 4, height = 4)
    plot(roc,
         print.auc=T,
         print.auc.x=0.4,print.auc.y=0.5,
         #auc.polygon=T,
         #auc.polygon.con="#fff7f7",
         grid=c(0.5,0.2),
         grid.col=c("black","black"),
         #print.thres=T,
         main=paste0(colnames(biomarker_exp)[i]),
         col="#FF2E63",
         legacy.axes=T)
    dev.off()
  }
}




# 1. 训练集单基因ROC---------------------------
rm(list = ls())
setwd("./")
if (! dir.exists("./15_ROC")){
  dir.create("./15_ROC")
}
setwd("./15_ROC")

library(lance)
library(tidyverse)
library(ROCR)
library(ggplot2)
library(pROC)

GEO_data <- 'GSE185011 '

if(!dir.exists(paste0(GEO_data))){
  dir.create(paste0(GEO_data))
}
setwd(paste0(GEO_data))

train_data <- read.csv(file = "../../00_rawdata/SJZZK-20121-2/00_rawdata/03.fpkm_GSE185011.csv", row.names = 1) %>% lc.tableToNum()
biomarker <- c('SLC36A1','RAB23')
group <- read.csv(file = '../../00_rawdata/SJZZK-20121-2/00_rawdata/03.group_GSE185011.csv')
colnames(group) <- c('sample','group')

table(group$group)

group$group <- as.factor(group$group)
biomarker <- as.data.frame(biomarker)
colnames(biomarker) <- 'symbol'
biomarker_exp <- train_data[biomarker$symbol, ] %>% t() # 整理后的数据行为样本名，列为筛选基因的表达量(8个筛选基因)

# 新建空白数据框
inter_gene <- data.frame()
i <- 1

for (i in c(1 : nrow(biomarker))) {
  roc <- roc(group$group, biomarker_exp[, i], levels = c('control', 'DR'))
  if (roc$auc > 0) {
    inter_gene <- rbind(inter_gene, biomarker[i, ])
    
    png(paste0('0', i, ".", colnames(biomarker_exp)[i], ".png"), width = 4, height = 4, units = 'in', res = 600)
    plot(roc,
         print.auc=T,
         print.auc.x=0.4,print.auc.y=0.5,
         print.auc.pattern='AUC=%.3f',
         #auc.polygon=T,
         #auc.polygon.con="#fff7f7",
         grid=c(0.5,0.2),
         grid.col=c("black","black"),
         #print.thres=T,
         main=paste0(colnames(biomarker_exp)[i]),
         col="#FF2E63",
         legacy.axes=T)
    dev.off()
    pdf(paste0('0', i, ".", colnames(biomarker_exp)[i], ".pdf"),width = 4, height = 4)
    plot(roc,
         print.auc=T,
         print.auc.x=0.4,print.auc.y=0.5,
         #auc.polygon=T,
         #auc.polygon.con="#fff7f7",
         grid=c(0.5,0.2),
         grid.col=c("black","black"),
         #print.thres=T,
         main=paste0(colnames(biomarker_exp)[i]),
         col="#FF2E63",
         legacy.axes=T)
    dev.off()
  }
}

