rm(list = ls())
setwd('./')
if (! dir.exists('./11_ceRNA')){
  dir.create('./11_ceRNA')
}
setwd('./11_ceRNA')
library(dplyr)
library(ggvenn)
#miRNA-----
m1<-read.csv('11.miRTarBase.csv') %>% dplyr::select(miRNA,Target)
m2<-read.csv('11.miRWalk_miRNA_Targets.csv')%>% dplyr::select(mirnaid,genesymbol)
mirna<-intersect(m1$miRNA,m2$mirnaid)
writeLines(mirna,'11.mirna.intersect.csv')
p<-ggvenn(list('miRTarBase'=m1$miRNA,'miRWalk'=m2$mirnaid),
          c('miRTarBase','miRWalk'),#'ModGenes'),
          fill_color = c("#ffb2b2","#8070CC"), #"#87CEEB",
          show_percentage = T,
          stroke_alpha = 0.5,
          stroke_size = 1,
          text_size = 4,
          stroke_color="white",
          stroke_linetype="solid",
          set_name_color=c("#ffb2b2","#8070CC"),#"#87CEEB",
          text_color = 'black')
p
ggsave("11.mirna.intersect.png",p,width = 8, height = 6)
ggsave("11.mirna.intersect.pdf",p,width = 8, height = 6)

#lncrna----
library('RCurl')

#lncrna encori----
outf<-'11.lncrna.encori.map.tsv'
unlink(outf);
lncrna<-sapply(mirna,function(x){
  url<-paste0("https://rnasysu.com/encori/api/miRNATarget/?assembly=hg38&geneType=lncRNA&miRNA=",x)
  txt<-getURL(url)
  tab<-read.delim2(text = txt,comment.char = '#')
  if(nrow(tab)>1){
    write.csv(tab,paste0("lncrna_encori.",x,'.csv'))
    out=tab%>%dplyr::select(miRNAname,geneName)%>%unique();
    if(!file.exists(outf)){writeLines("miRNAname\tgeneName",outf)}
    write.table(out,outf,append = T,quote = F,row.names = F,col.names = F,sep='\t')
    return(tab$geneName)
  }else{NA}
}) %>% unlist()%>% unique()%>%na.omit()
writeLines(lncrna,'11.lncrna.encori.csv')
#unlink(outf);a<-sapply(mirna,function(x){tab<-read.csv(paste0("lncrna_encori.",x,'.csv'));if(nrow(tab)>1){out=tab%>%dplyr::select(miRNAname,geneName)%>%unique();if(!file.exists(outf)){writeLines("miRNAname\tgeneName",outf)};write.table(out,outf,append = T,quote = F,row.names = F,col.names = F);return(tab$geneName)}else{NA}}) %>% unlist() %>% unique()

#lncrna venn-----
mirn<-read.csv('11.mirnet.mir2lnc.map.csv')
mirn$ID%<>%gsub('-mir-','-miR-',.)
enco<-read.delim2('11.lncrna.encori.map.tsv')%>% setnames(1:2,c("ID","Target"))
lncI<-intersect(enco$Target,mirn$Target)
#34
p<-ggvenn(list('ENCORI'=enco$Target,'miRNet'=mirn$Target),
          c('ENCORI','miRNet'),#'ModGenes'),
          fill_color = c("#ffb2b2","#8070CC"), #"#87CEEB",
          show_percentage = T,
          stroke_alpha = 0.5,
          stroke_size = 1,
          text_size = 4,
          stroke_color="white",
          stroke_linetype="solid",
          set_name_color=c("#ffb2b2","#8070CC"),#"#87CEEB",
          text_color = 'black')
p
ggsave("11.LncRNA.intersect.png",p,width = 8, height = 6)
ggsave("11.LncRNA.intersect.pdf",p,width = 8, height = 6)
#output for cyto
lnc<-rbind(enco,mirn)%>%filter(Target %in% lncI)%>%unique()
setnames(m1,1:2,colnames(m2))
mir<-rbind(m1,m2)%>%filter(mirnaid %in% mirna)%>%unique()%>%setnames(1:2,c("ID","Target"))
all<-rbind(mir,lnc)
nrow(all)
#166条边
write.csv(all,"11.mrna_mir_lnc.map.csv",quote = F)
type<-data.frame(name=c(unique(mir$Target),unique(mir$ID),unique(lnc$Target)),type=c(rep('seed',2),rep('mir',19),rep('lnc',34)))
write.csv(type,'11.mrna_mir_lnc.type.csv',quote = F)
#包列表----
pkgs<-lapply(sessionInfo()$otherPkgs,function(x){x$Version}) %>% as.data.frame() %>%t()
write.table(pkgs,'pkgs.tsv',quote = F,sep = '\t',col.names=F)
