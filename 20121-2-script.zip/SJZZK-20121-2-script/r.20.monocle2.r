# 08 差异细胞分亚群 ------------
rm(list = ls())
setwd('./14.scRNA/09_monocle2_1')
if (! dir.exists("./01_subtype")){dir.create("./01_subtype")}
setwd("./01_subtype")

library(Seurat)
library(ggplot2)
scRNA <- readRDS('../../06_cell_annot/UMAP.celltype.rds')
table(scRNA$celltype)

celllist <- unique(scRNA$celltype)

celllist <- c('B cells','classical monocytes')#Macrophage dims=20,Smooth_muscle_cells dims=30
if(T){
for (j in 1:length(celllist)){
  cellname <- celllist[j]
  print(cellname)
  if(file.exists(paste0("scRNA.",cellname,".Rdata"))){next}
  tryCatch({
    scRNA1 <- scRNA[ ,scRNA$celltype %in% c(cellname)]
    scRNA1 <- NormalizeData(scRNA1, normalization.method = "LogNormalize", scale.factor = 10000)
    scRNA1 <- FindVariableFeatures(scRNA1, selection.method = 'vst', nfeatures = 1000)
    scRNA1 <- ScaleData(scRNA1)
    scRNA1 <- RunPCA(scRNA1, features = VariableFeatures(object = scRNA1))
    scRNA1 <- JackStraw(scRNA1, num.replicate = 100, dims = 50)
    scRNA1 <- ScoreJackStraw(scRNA1, dims = 1:50)
    system.time(save(scRNA1, file = paste0("scRNA.",celllist[j],".Rdata")))
    load(paste0("scRNA.",celllist[j],".Rdata"))
    p1 <- JackStrawPlot(scRNA1, dims = 1:50)
    ggsave(paste0('02.subtype_',cellname,'_JackStrawPlot.png'),p1,w=10,h=5)
    ggsave(paste0('02.subtype_',cellname,'_JackStrawPlot.pdf'),p1,w=10,h=5)
    
    p2 <- ElbowPlot(scRNA1, ndims = 50)
    ggsave(paste0('02.subtype_',cellname,'_ElbowPlot.png'),p2,w=6,h=5)
    ggsave(paste0('02.subtype_',cellname,'_ElbowPlot.pdf'),p2,w=6,h=5)
    
    pcSelect=20
    scRNA1 <- FindNeighbors(scRNA1, dims = 1:pcSelect)
    scRNA1 <- FindClusters(scRNA1, resolution = 0.1)
    scRNA1 <- RunUMAP(scRNA1,dims = 1:pcSelect)
    
    p3 <- DimPlot(scRNA1, reduction = "umap", group.by = "seurat_clusters", label = T)+
      ggtitle(paste0('Subtype of ',cellname))
    ggsave(filename = paste0('02.subtype_',cellname,'_UMAP.png'),p3,w=6,h=5)
    ggsave(filename = paste0('02.subtype_',cellname,'_UMAP.pdf'),p3,w=6,h=5)
    system.time(save(scRNA1, file = paste0("scRNA.",celllist[j],".Rdata")))
    
  }, error = function(e){
    print(paste(j,'error: ',e))
  },finally = {
    print("----------------------------------------------------------")
  })
}
}
# # 09拟时序分析 -----------
rm(list = ls())
setwd('./14.scRNA/')
if (! dir.exists("./09_monocle2_1")){dir.create("./09_monocle2_1")}
setwd("./09_monocle2_1")

library(monocle)
library(Seurat)
library(tidyverse)
library(ggsci)
library(dplyr)
subtype_files <- list.files('./01_subtype', pattern = ".Rdata$",full.names = T)
subtype_files
# files <- list.files('.', pattern = ".RData$",full.names = T)
# files
subtype_files <- grep('\\.B|\\.cla',subtype_files,perl = T,value = T)
library(RColorBrewer)
library(patchwork)
for( i in 1:length(subtype_files)){
  cellname <- strsplit(subtype_files[i],split='\\.')[[1]][3]
  print(cellname)
  tryCatch({
  if(!file.exists(paste0("mycds_order.",cellname,".RData"))){  
    load(subtype_files[i])
    scRNA <- scRNA1
    ## 1 计算
    cell_matrix <- GetAssayData(scRNA, layer = "counts", assay = "RNA")
    feature_ann <- data.frame(gene_id=rownames(cell_matrix),gene_short_name=rownames(cell_matrix))
    rownames(feature_ann) <- rownames(cell_matrix)
    cell_fd <- new("AnnotatedDataFrame", data = feature_ann)
    sample_ann <- scRNA@meta.data
    cell.type <- Idents(scRNA) %>% data.frame
    sample_ann <- cbind(sample_ann, cell.type)
    colnames(sample_ann)[ncol(sample_ann)] <- "Subtype"
    cell_pd <- new("AnnotatedDataFrame", data =sample_ann)
    cell.cds <- newCellDataSet(cell_matrix, phenoData =cell_pd, featureData=cell_fd, expressionFamily=negbinomial.size())
    cell.cds <- estimateSizeFactors(cell.cds)
    cell.cds <- estimateDispersions(cell.cds)
    WGCNA::collectGarbage()
    
    #plot_ordering_genes(cell.cds)
    cell.cds <- reduceDimension(cell.cds, max_components = 2, verbose = T,
                                norm_method = "log"#, residualModelFormulaStr = "~nFeature_RNA+group"
    )
    cell.cds <- orderCells(cell.cds)
    save(cell.cds, file = paste0("mycds_order.",cellname,".RData"))
  }else{
    load(paste0("mycds_order.",cellname,".RData"))
  } 
    # load(files[i])
    ## 2 绘图
    theme.set = theme(
      axis.title.x=element_text(size = 18, face = "bold", color='black',family = "Times"),
      axis.title = element_text(size = 18, face = "bold", color='black',family = "Times"),
      axis.text.x = element_text(size = 14,  face = "bold",color='black', family = "Times"),
      axis.text.y = element_text(size = 14,  face = "bold",color='black', family = "Times"),
      legend.text = element_text(size = 12, face = "bold", color='black',family = "Times"),
      legend.title = element_text(size = 16,face='bold',color='black',family = "Times"),
      text = element_text(family = "Times"))
    
    mycolor <- c(pal_npg(palette = c("nrc"), alpha = 0.8)(8),pal_simpsons(palette = c("springfield"), alpha = 1)(16))
 
    ## 拟时序分析-----
    p1 <- plot_cell_trajectory(cell.cds,color_by="Pseudotime",cell_size = 1, theta = 180,
                               size=1, show_backbone=TRUE, show_branch_points = F) +
      theme(text = element_text(size = 14)) + theme.set
    ggsave(paste0("01.PSD_Trajectory_",cellname,".png"), p1, width = 6, height = 6, units = "in", dpi = 300)
    ggsave(paste0("01.PSD_Trajectory_",cellname,".pdf"), p1, width = 6, height = 6, units = "in", dpi = 300)
    
    p2 <- plot_cell_trajectory(cell.cds,color_by="celltype",cell_size = 1, theta = 180,
                               size=1, show_backbone=TRUE, show_branch_points = F) +
      scale_color_manual(values = mycolor) + theme.set
    ggsave(paste0("02.cell_type_Trajectory_",cellname,".png"), p2, width = 6, height = 6, units = "in", dpi = 300)
    ggsave(paste0("02.cell_type_Trajectory_",cellname,".pdf"), p2, width = 6, height = 6, units = "in", dpi = 300)
    p2.1 <- plot_cell_trajectory(cell.cds,color_by="seurat_clusters",cell_size = 1, theta = 180,
                                 size=1, show_backbone=TRUE, show_branch_points = F) +
      scale_color_manual(values = mycolor) + theme.set
    ggsave(paste0("02.seurat_clusters_Trajectory_",cellname,".png"), p2.1, width = 6, height = 6, units = "in", dpi = 300)
    ggsave(paste0("02.seurat_clusters_Trajectory_",cellname,".pdf"), p2.1, width = 6, height = 6, units = "in", dpi = 300)
    p3 <- plot_cell_trajectory(cell.cds,color_by="State",cell_size = 1, theta = 180,
                               size=1, show_backbone=TRUE, show_branch_points = F) +
      scale_color_manual(values = mycolor) + theme.set
    ggsave(paste0("03.State_Trajectory_",cellname,".png"), p3, width = 6, height = 6, units = "in", dpi = 300)
    ggsave(paste0("03.State_Trajectory_",cellname,".pdf"), p3, width = 6, height = 6, units = "in", dpi = 300)
    
    p4 <- plot_cell_trajectory(cell.cds,color_by="group",cell_size = 1, theta = 180,
                               size=1, show_backbone=TRUE, show_branch_points = F) +
      scale_color_manual(values = mycolor) + theme.set +
      theme(strip.text = element_text(size = 18, face = "bold", family = "Times"))# +
    #facet_wrap(~group,nrow = 1)
    p4
    ggsave(filename = paste0("04.celltype_Trajectory.",cellname,"(group).pdf"),p4,w=10,h=6, units = "in")
    ggsave(filename = paste0("04.celltype_Trajectory.",cellname,"(group).png"),p4,w=10,h=6, units = "in", dpi = 300)
    
    # hub基因表达 ---------
    hubgene<-read.csv('../../06_expression/03.hubgene.csv')%>%pull(x)
    p5 <- plot_genes_in_pseudotime(cell.cds[hubgene,], color_by = "State",ncol = 3)+ theme.set +
      theme(axis.title = element_text(size = 18, face = "bold", family = "Times"),
            strip.text = element_text(size = 18, face = "bold", family = "Times"))
    ggsave(filename = paste0("05.sdheat_hubgene.",cellname,".pdf"),p5,w=9,h=5)
    ggsave(filename = paste0("05.sdheat_hubgene.",cellname,".png"),p5,w=9,h=5,units = 'in',dpi = 300)
    #
    p6 <- plot_genes_in_pseudotime(cell.cds[hubgene,], color_by = "Pseudotime",ncol = 3)+ theme.set +
      theme(axis.title = element_text(size = 18, face = "bold", family = "Times"),
            strip.text = element_text(size = 18, face = "bold", family = "Times"))
    ggsave(filename = paste0("05.Pseudotime_hubgene.",cellname,".pdf"),p6,w=9,h=5)
    ggsave(filename = paste0("05.Pseudotime_hubgene.",cellname,".png"),p6,w=9,h=5,units = 'in',dpi = 300)
    #
    p7 <- plot_genes_in_pseudotime(cell.cds[hubgene,], color_by = "seurat_clusters",ncol = 3)+ theme.set +
      theme(axis.title = element_text(size = 18, face = "bold", family = "Times"),
            strip.text = element_text(size = 18, face = "bold", family = "Times"))
    ggsave(filename = paste0("05.seurat_cluster_hubgene.",cellname,".pdf"),p7,w=9,h=5)
    ggsave(filename = paste0("05.seurat_cluster_hubgene.",cellname,".png"),p7,w=9,h=5,units = 'in',dpi = 300)
    ## Seurat
    scRNA$State <- cell.cds$State
    getPalette = colorRampPalette(brewer.pal(12, "Set3"))
    
    ## 小提琴图-----
    #分群已经画了
    # plots = list()
    # for(i in seq_along(hubgene)){
    #   plots[[i]] = VlnPlot(scRNA,
    #                        group.by='State',
    #                        pt.size = 0,
    #                        cols = mycolor,
    #                        features = hubgene[i]) + theme.set + NoLegend()}
    # p6 <- wrap_plots(plots = plots, ncol=3)
    # ggsave(filename = paste0("06.violin_hubgene.",cellname,".pdf"),p6,w=12,h=8)
    # ggsave(filename = paste0("06.violin_hubgene.",cellname,".png"),p6,w=12,h=8)
    # 
    # 绘制hubgene的UMAP降维聚类图
    # plots = list()
    # for(i in seq_along(hubgene)){
    #   plots[[i]] = FeaturePlot(scRNA, features = hubgene[i]) + theme.set
    # }
    # p7 <- wrap_plots(plots = plots, ncol =3)
    # ggsave(filename = paste0("07.UMAP_hubgene.",cellname,".pdf"),p7,w=12,h=8)
    # ggsave(filename = paste0("07.UMAP_hubgene.",cellname,".png"),p7,w=12,h=8,units = 'in',dpi = 300)
    
  }, error = function(e){
    print(paste(i,' error ',e))
  },finally = {
    print("----------------------------------------------------------")
  })
}

#包列表----
pkgs<-lapply(sessionInfo()$otherPkgs,function(x){x$Version}) %>% as.data.frame() %>%t()
write.table(pkgs,'pkgs.tsv',quote = F,sep = '\t',col.names=F)