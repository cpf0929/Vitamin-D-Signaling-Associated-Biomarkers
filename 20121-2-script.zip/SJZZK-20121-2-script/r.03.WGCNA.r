#wgcna-------
rm(list = ls())
setwd('./')
if (! dir.exists('./03_WGCNA')){
  dir.create('./03_WGCNA')
}
setwd('./03_WGCNA')
library(dplyr)
library(lance)
group <- read.csv('../00_rawdata/01.group_GSE221521.csv')
colnames(group) <- c('sample', 'Type')

dat_expr <- read.csv('../00_rawdata/01.fpkm.log_GSE221521.csv',row.names = 1,check.names = F) %>% lance::lc.tableToNum()
expr <- dat_expr[,group$sample]
#expr <- dat_expr

#datExprOri= t(expr_fpkm[order(apply(expr_fpkm,1,mad), decreasing = T)[1:5000],])
# m.mad <- apply(expr,1,mad)
# dataExprVar <- expr[which(m.mad >max(quantile(m.mad, probs=seq(0, 1, 0.25))[2],0.01)),]
#
eset<-expr

datExprOri=as.data.frame(t(eset))
nGenes0 = ncol(datExprOri)
nSamples0 = nrow(datExprOri)
nGenes0 ;nSamples0
# [1] 19416 #590个基因删掉
# [1] 119

## 删除方差为0基因
library(WGCNA)
##检验数据质量
gsg = goodSamplesGenes(datExprOri , verbose = 3)   #计算数据集中是否含有方差为0的基因
gsg$allOK   ##为TRUE不用删除基因
if (!gsg$allOK){
  # Optionally, print the gene and sample names that were removed:
  if (sum(!gsg$goodGenes)>0)
    printFlush(paste("Removing genes:",
                     paste(names(datExprOri)[!gsg$goodGenes], collapse = ",")));
  if (sum(!gsg$goodSamples)>0)
    printFlush(paste("Removing samples:",
                     paste(rownames(datExprOri)[!gsg$goodSamples], collapse = ",")));
  # Remove the offending genes and samples from the data:
  datExprOri = datExprOri[gsg$goodSamples, gsg$goodGenes]
  
}      ##输出的datExprOri已经过滤基因
datExpr1<-datExprOri
nGenes1<-ncol(datExpr1)      #基因数目
nSamples1 <- nrow(datExpr1) #样品名称变量
nGenes1 ;nSamples1
# [1] 18826
# [1] 119

#筛选方差前75%的基因
datExpr1 <- t(datExpr1) %>% as.data.frame()
m.mad <- apply(datExpr1,1,mad)
datExpr1 <- datExpr1[which(m.mad >
                             max(quantile(m.mad, probs=seq(0, 1, 0.25))[2],0.01)),]
datExpr1 <- t(datExpr1) %>% as.data.frame()
nGenes1<-ncol(datExpr1)      #基因数目
nSamples1 <- nrow(datExpr1) #样品名称变量
nGenes1 ;nSamples1
# [1] 14119
# [1] 119

##根据层次聚类绘制样本------
# 观察是否有离群样品需要剔除
tree=hclust(dist(datExpr1),method ='complete')   ##观察是否有离群样本  c("single", "complete", "average", "mcquitty", "ward.D", "centroid", "median", "ward.D2")
#hclust()函数是stats包中的函数,可以根据距离矩阵实现层次聚类。
save(file = 'tree.rda',tree)
library(myplot)
mp<-myplot({
par(pin = c(4,4), mar = c(6,6,6,1),family='serif')
plot(tree,xlab="", sub="", main="Sample Clustering",
     labels=F,
     cex=1.0,  ##label大小
     font=2,
     cex.axis=1.6,  ##坐标轴刻度文字的缩放倍数。类似cex。
     cex.lab=1.8,   ##坐标轴刻度文字的缩放倍数。类似cex。
     cex.main=1.8,   ##标题的缩放倍数。
     font.axis = 2,
     font.lab = 2,
     font.main = 2,
     font.sub =2)
abline(h =160, col = 'red')
})
plotsave(mp)
plotsave(mp,'01.sampleClustering.pdf',width =10,height = 7,units = 'in')
plotsave(mp,'01.sampleClustering.png',width =10,height = 7,units = 'in',dpi=600,bg='white')


## 从上图可以看出，疑似异样，考虑去除。
clust = cutreeStatic(tree, cutHeight =160, minSize = 10)
table(clust)  ###无离群样本
# clust
# 0   1 
# 4 115 
## 去除异常样品后的表达矩阵
datExpr = datExpr1[clust == 1, ]
nGenes = ncol(datExpr)      #基因数目
nSample =nrow(datExpr) #样品名称变量
nGenes ;nSample
#[1] 14119
#[1] 115
SampleName<-rownames(datExpr)
group %>% filter(!(sample %in% SampleName) )
# sample    Type
# 1 GSM6881234 control
# 2 GSM6881340 control
# 3 GSM6881240      DR
# 4 GSM6881386      DR
## 表型数据聚类树----
group <- group[group$sample %in% SampleName,]
condition <- group
rownames(condition) <- condition$sample
condition$DR<-ifelse(condition$Type=='DR',1,0)
condition$control<-ifelse(condition$Type=='control',1,0)
condition<-condition[,-c(1,2)]

# library(tidyverse)
datTraits<-condition

datExpr[1:4,1:4]

traitColors = numbers2colors(datTraits, signed = FALSE)
tree2=hclust(dist(datExpr),method ='complete')   ##可视化表型数据与基因表达量数据的联系，重构样本聚类树  c("single", "complete", "average", "mcquitty", "ward.D", "centroid", "median", "ward.D2")

mp<-myplot({
par(pin = c(4,4), mar = c(6,6,6,1),family='serif')
plotDendroAndColors(tree2,
                    traitColors,
                    dendroLabels = F,
                    hang = 0.03,
                    cex.dendroLabels = 1,
                    # addGuide = TRUE,   ##添加网格线
                    font=2,
                    guideHang = 0.05,
                    cex.axis=1.4,  ##坐标轴刻度文字的缩放倍数。类似cex。
                    cex.lab=1.6,   ##坐标轴刻度文字的缩放倍数。类似cex。
                    cex.main=1.6,   ##标题的缩放倍数。
                    font.axis = 2,
                    font.lab = 2,
                    font.main = 2,
                    font.sub =2,
                    cex.colorLabels=1,
                    groupLabels = colnames(datTraits),
                    main = "Sample Clustering and trait heatmap")
})
plotsave(mp)
plotsave(mp,'01.sampleClustering_group.pdf',width=10,height=7,unit='in')
plotsave(mp,'01.sampleClustering_group.png',width=10,height=7,units='in',dpi=600,bg='white')


# 一步构建共表达网络和划分模块------
##设置网络构建参数选择范围，计算beta值（为了计算power）
powers <- c(c(1:20))#c(seq(1, 10, by=1), seq(12, 20, by=2)) #设置beta值的取值范围
#rsquare.cut=0.85  #设置r2阈值为0.85，一般选择0.85或0.9

#开启多线程，加快运行速度
enableWGCNAThreads()
#disbleWGCNAThreads()     #如果运行pickSoftThreshold报call()相关的错误，需要运行禁用多线程
#trace(pickSoftThreshold,edit = T) #148行，2改成4，下边画图改成sft$fitIndices[,4]
#untrace(pickSoftThreshold)
#软阈值----
sft = pickSoftThreshold(datExpr, RsquaredCut = 0.8, powerVector = powers, verbose = 5)
# Power SFT.R.sq  slope truncated.R.sq mean.k. median.k. max.k.
# 1      1    0.546  1.330          0.806 3660.00  3830.000 5600.0
# 2      2    0.013 -0.101          0.454 1460.00  1500.000 2980.0
# 3      3    0.320 -0.560          0.644  711.00   690.000 1810.0
# 4      4    0.515 -0.812          0.778  392.00   352.000 1200.0
# 5      5    0.601 -0.997          0.838  234.00   192.000  839.0
# 6      6    0.646 -1.120          0.871  148.00   110.000  610.0
# 7      7    0.667 -1.270          0.888   97.60    65.900  465.0
# 8      8    0.687 -1.390          0.908   66.70    40.600  365.0
# 9      9    0.707 -1.490          0.926   46.90    25.700  292.0
# 10    10    0.707 -1.610          0.926   33.80    16.500  237.0
# 11    11    0.716 -1.700          0.935   24.90    11.000  196.0
# 12    12    0.740 -1.750          0.953   18.60     7.310  163.0
# 13    13    0.749 -1.810          0.961   14.10     4.990  137.0
# 14    14    0.764 -1.850          0.970   10.90     3.430  117.0
# 15    15    0.783 -1.860          0.978    8.46     2.400  100.0
# 16    16    0.790 -1.900          0.982    6.67     1.690   86.4
# 17    17    0.806 -1.910          0.983    5.30     1.200   75.1
# 18    18    0.820 -1.900          0.988    4.26     0.879   65.6
# 19    19    0.832 -1.900          0.991    3.45     0.640   57.6
# 20    20    0.832 -1.910          0.985    2.81     0.472   50.8
sft$powerEstimate #推荐软阈值
# 17
#3
save.image('powerEstimate.RData')
load('./powerEstimate.RData')
#软阈值选择绘图
#左图为每个候选beta对应的R2值,
#绘制阈值线0.9（红线）和0.85（蓝线），如没有超过蓝线，则没找到软阈值，sft$powerEstimate为空
#右图为每个候选beta对应的平均连接度

mp<-myplot({
par(mfrow = c(1,2),pin = c(4,4), mar = c(6,6,6,1),family='serif')
cex1=1.5
plot(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2],xlab="Soft Threshold (power)",ylab="Scale Free Topology Model Fit,signed R^2",type="n",
     cex.axis=1.6,  ##坐标轴刻度文字的缩放倍数。类似cex。
     cex.lab=1.8,   ##坐标轴刻度文字的缩放倍数。类似cex。
     cex.main=1.8,   ##标题的缩放倍数。
     font.axis = 2,
     font.lab = 2,
     font.main = 2,
     font.sub =2,
     main = paste("Scale independence"));
text(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2],labels=powers,cex=cex1,col="red");
abline(h=0.8,col="red")
plot(sft$fitIndices[,1], sft$fitIndices[,5],xlab="Soft Threshold (power)",ylab="Mean Connectivity", type="n",main = paste("Mean connectivity"),
     cex.axis=1.6,  ##坐标轴刻度文字的缩放倍数。类似cex。
     cex.lab=1.8,   ##坐标轴刻度文字的缩放倍数。类似cex。
     cex.main=1.8,   ##标题的缩放倍数。
     font.axis = 2,
     font.lab = 2,
     font.main = 2,
     font.sub =2)
text(sft$fitIndices[,1], sft$fitIndices[,5], labels=powers, cex=cex1,col="red")
})
plotsave(mp)
plotsave(mp,'02.softThreshold.pdf',width=12,height=8,units = 'in')
plotsave(mp,'02.softThreshold.png',width=12,height=8,units='in',dpi=600,bg='white')

# 横轴是Soft threshold (power)，纵轴是无标度网络的评估参数，
# 数值越高，网络越符合无标度特征 (non-scale)。
##自动构建WGCNA模型
#表达矩阵转换成邻接矩阵，然后再将邻接矩阵转换成拓扑矩阵,识别模块
cor <- WGCNA::cor
net = blockwiseModules(
  datExpr,
  power = sft$powerEstimate,
  #power = 10,
  minModuleSize =100,                    #每个模块最少的基因数
  #deepSplit = 4,                         #剪切树参数，一般设置为2，取值0-4（最灵敏）
  corType = 'pearson',
  mergeCutHeight = 0.4,                 #模块合并参数，越大模块越少，默认0.25
  numericLabels = TRUE,                  # T返回数字，F返回颜色
  networkType  = "signed",               #网络类型，一般不需要修改
  maxBlockSize = ncol(datExpr),
  pamRespectsDendro = FALSE,
  saveTOMs = TRUE,
  saveTOMFileBase = "FPKM-TOM",
  loadTOMs = F,
  verbose = 3
)

cor<-stats::cor
table(net$colors)     ## 12个模块（含gray)
# 0    1    2    3    4    5    6    7    8    9   10   11 
# 929 4594 2835 2165 1450  581  411  323  298  262  143  128 
save.image('Modules.RData')
load('./Modules.RData')
##模块重新排序
#获取模块颜色
moduleColors = labels2colors(net$colors)
#获取每个模块的特征值
MEs0 = moduleEigengenes(datExpr, moduleColors)$eigengenes
MEs = orderMEs(MEs0); #重新排序，相似颜色的挨在一起
useMEs=subset(MEs, select = -c(MEgrey))  #去掉未分组的基因(灰色模块）

# useMEs=subset(MEs)  #去掉未分组的基因(灰色模块）
# # 输出每个基因所在的模块，以及与该模块的KME值
# if(file.exists('01.All_Gene_KME.txt')) file.remove('01.All_Gene_KME.txt')
# for(module in substring(colnames(useMEs),3)){
#   ME=as.data.frame(useMEs[,paste("ME",module,sep="")])
#   colnames(ME)=module
#   datModExpr=datExpr1[,moduleColors==module]
#   datKME = signedKME(datModExpr, ME)
#   datKME= cbind(datKME,rep(module,length(datKME)))
#   write.csv(datKME,quote = F,row.names = T,file = "01.All_Gene_KME.csv",col.names = F)
# }

##模块绘图
mergedColors = labels2colors(net$colors)
mergedColors[net$blockGenes[[1]]]
mp<-myplot({
par(mfrow = c(1,2),pin = c(4,4), mar = c(6,6,6,1),family='serif')
plotDendroAndColors(net$dendrograms[[1]], mergedColors[net$blockGenes[[1]]],"Module colors",
                    dendroLabels = FALSE, hang = 0.03,addGuide = TRUE, guideHang = 0.05,
                    cex.axis=1.6,  ##坐 标轴刻度文字的缩放倍数。类似cex。
                    cex.lab=1.8,   ##坐标轴刻度文字的缩放倍数。类似cex。
                    cex.main=1.8,   ##标题的缩放倍数。
                    font.axis = 2,
                    font.lab = 2,
                    font.main = 2,
                    cex.colorLabels=1,
                    font.sub =2)

})
plotsave(mp)
plotsave(mp,"03.wgcna.dendroColors.pdf",height = 7,width = 9,units = 'in')
plotsave(mp,"03.wgcna.dendroColors.png",height = 7,width = 9,units='in',dpi=600,bg='white')


# 将结果保存成cytoscape的输入文件格式
#读入构建时保存的TOM矩阵
#load('FPKM-TOM-block.1.RData')
#TOM=as.matrix(TOM)
#save(file="WGCNA.RData",datExpr1,SampleName,useMEs)


##模块与表型的关联分析-----
#load('WGCNA.RData')
# if (corType=="pearson") {
#   modTraitCor = cor(useMEs, datTraits, use = "p")
#   modTraitP = corPvalueStudent(moduleTraitCor, nrow(datExpr1)) %>% signif(3)
#   modTraitPadj = p.adjust(modTraitP, method = "BH")
# } else {
#   modTraitCorP = bicorAndPvalue(useMEs, datTraits, robustY=robustY)
#   modTraitCor = modTraitCorP$bicor
#   modTraitP   = modTraitCorP$p
#   modTraitPadj = p.adjust(modTraitP, method = "BH")
# }

#分数
score <- read.csv('../02_ssGSEA/02.ssgsea_result.csv',check.names = F,row.names = 1)
# score <- score[,c('X','Macrophages_M2')]
# colnames(score) <- c('sample','Macrophages.M2')
# rownames(score) <- score$sample
# rownames(score) <- score$X
# score <- score[,-1]
score <- data.frame(t(score))
score$sample <- rownames(score)

MRGs_score<-score[SampleName,]
#datTraits <- MRGs_score[,-1]
datTraits<-data.frame(row.names=MRGs_score$sample,VDRGs_score=MRGs_score$VDscore)
identical(rownames(datExpr),rownames(datTraits))
datExpr[1:4,1:4]
datTraits[1:4,]

#分组
moduleTraitCor = cor(useMEs, datTraits, use = "p") # use=p代表去掉缺失计算
moduleTraitPvalue = corPvalueStudent(moduleTraitCor, length(SampleName))#
#整理要显示在图中的数字,第一行为相关系数，第二行为p值
textMatrix =  paste(signif(moduleTraitCor, 2), "\n(",
                    signif(moduleTraitPvalue, 1), ")", sep = "");
dim(textMatrix) = dim(moduleTraitCor)

#绘制关联热图
mp<-myplot({
par(mar = c(6,12,3,3),family='serif')  ##下左上右   ##par(pin = c(4,4), mar = c(6,6,6,1),family='serif')
  #par(mar = c(14, 12, 3, 1.5),family='serif')  ##下左上右   ##par(pin = c(4,4), mar = c(6,6,6,1),family='serif')
  labeledHeatmap(Matrix = moduleTraitCor,   #相关系数
                 xLabels = colnames(datTraits), #x轴为表型
                 yLabels = names(useMEs),#y轴为模块
                 ySymbols = names(useMEs),
                 colorLabels = FALSE,
                 colors =  blueWhiteRed(50),
                 textMatrix = textMatrix, #每个单元格的内容
                 setStdMargins = FALSE,
                 xLabelsAngle = 0,
                 xLabelsAdj = 0.5,
                 cex.text =1.1,cex.lab.y = 1.5,cex.legendLabel =1.5,cex.lab.x=1.5,
                 zlim = c(-1,1),
                 main = "Module-trait relationships",
                 cex.lab = 1.2,
                 font.lab.x = 2, font.lab.y = 2 )
})
plotsave(mp)
plotsave(mp,"04.wgcna.Module-trait.heatmap.png", width = 10, height =10,unit='in',dpi=600,bg='white')
plotsave(mp,"04.wgcna.Module-trait.heatmap.pdf", width = 10, height =10,unit='in')
#Modgene# MEblue ->blue
module=moduleTraitCor %>% as.data.frame() %>% arrange(desc(VDRGs_score)) %>% rownames() %>% head(n=1) %>%gsub("ME","",.)
module
# "brown"
module1=moduleTraitCor %>% as.data.frame() %>% arrange(VDRGs_score) %>% rownames() %>% head(n=1) %>%gsub("ME","",.)
module1
#[1] "turquoise"

probes=colnames(datExpr)
inModule=(moduleColors %in% c(module1,module))
modProbes=probes[inModule]
modGenes<-as.data.frame(modProbes)
colnames(modGenes)<-'modgene'
nrow(modGenes)
## modGenes：6759
sum((moduleColors %in% c(module)))
#2165
sum((moduleColors %in% c(module1)))
#4594
#green 4594
# 
# ## ME pink
# module2='pink'
# probes=colnames(dataExpr)
# inModule2=(moduleColors==module2)
# modProbes2=probes[inModule2]
# modGenes2<-as.data.frame(modProbes2)
# colnames(modGenes2)<-'modgene'
#148
#modGenes<-rbind(modGenes,modGenes2)
#
write.table(modGenes,file = 'modGene.xls',sep = '\t',quote = F,row.names = F,col.names = F)
#129
# ### 模块与基因相关性
# if (corType=="pearson") {
#   geneModuleMembership = as.data.frame(cor(datExpr, MEs, use = "p"))
#   MMPvalue = as.data.frame(corPvalueStudent(
#     as.matrix(geneModuleMembership), nSamples))
# } else {
#   geneModuleMembershipA = bicorAndPvalue(dataExpr, MEs_col, robustY=robustY)
#   geneModuleMembership = geneModuleMembershipA$bicor
#   MMPvalue   = geneModuleMembershipA$p
# }
# # 计算性状与基因的相关性矩阵
# 
# ## 只有连续型性状才能进行计算，如果是离散变量，在构建样品表时就转为0-1矩阵。
# 
# if (corType=="pearson") {
#   geneTraitCor = as.data.frame(cor(datExpr, design_traits, use = "p"))
#   geneTraitP = as.data.frame(corPvalueStudent(
#     as.matrix(geneTraitCor), nSamples))
# } else {
#   geneTraitCorA = bicorAndPvalue(datExpr, design_traits, robustY=T)
#   geneTraitCor = as.data.frame(geneTraitCorA$bicor)
#   geneTraitP   = as.data.frame(geneTraitCorA$p)
# }
# ### blue---------
# #module = "blue"
# pheno = "DR"
# modNames = substring(colnames(MEs), 3)
# # 获取关注的列
# module_column = match(module, modNames)
# pheno_column = match(pheno,colnames(design_traits))
# # 获取模块内的基因
# moduleGenes = moduleColors == module
# 
# # MM<-abs(geneModuleMembership[moduleGenes,module_column])
# # GS<-abs(geneTraitCor[moduleGenes, 1])
# # c<-as.data.frame(cbind(MM,GS))
# # rownames(c)=modGenes$modgene
# # blue_hub <- subset(c,c$MM > 0.5 & c$GS > 0.2)
# 
# sizeGrWindow(7, 7)
# par(mfrow = c(1,1),
#     mai = c(1,1,1,0.5))
# pdf('06.blue_gene_cor.pdf',w=6,h=6)
# verboseScatterplot(abs(geneModuleMembership[moduleGenes, module_column]),
#                    abs(geneTraitCor[moduleGenes, pheno_column]),
#                    xlab = paste("Module Membership in", module, "module"),
#                    ylab = paste("Gene significance for", pheno),
#                    main = paste("Module membership vs. gene significance\n"),
#                    cex.main = 1.2, cex.lab = 1.2, cex.axis = 1.2, col = module)
# # abline(h=0.2,v=0.5,col="red",lwd=1.5)
# dev.off()
# png('06.blue_gene_cor.png',w=600,h=600)
# verboseScatterplot(abs(geneModuleMembership[moduleGenes, module_column]),
#                    abs(geneTraitCor[moduleGenes, pheno_column]),
#                    xlab = paste("Module Membership in", module, "module"),
#                    ylab = paste("Gene significance for", pheno),
#                    main = paste("Module membership vs. gene significance\n"),
#                    cex.main = 1.2, cex.lab = 1.2, cex.axis = 1.2, col = module)
# # abline(h=0.2,v=0.5,col="red",lwd=1.5)
# dev.off()
save.image("image.rda")
#包列表----
pkgs<-lapply(sessionInfo()$otherPkgs,function(x){x$Version}) %>% as.data.frame() %>%t()
write.table(pkgs,'pkgs.tsv',quote = F,sep = '\t',col.names=F)
