rm(list = ls())
setwd("./")
numdir <- "12_Drug"
if (! dir.exists(numdir)){
  dir.create(numdir)
}
setwd(numdir)
library(enrichR)

# BiocManager::install('enrichR')

dbs <- listEnrichrDbs()
dbs <- c("DSigDB")
hubgene <- read.csv("../06_expression/03.hubgene.csv", check.names = F,row.names = 1)
symbol <- hubgene$x
enrichr <- enrichr(symbol,dbs)
result <- data.frame(enrichr$DSigDB)
result <- result[which(result$P.value < 0.05),]
write.table(result,"01.Drugs_result.tsv",quote = F,sep = '\t')

#包列表----
pkgs<-lapply(sessionInfo()$otherPkgs,function(x){x$Version}) %>% as.data.frame() %>%t()
write.table(pkgs,'pkgs.tsv',quote = F,sep = '\t',col.names=F)
