rm(list = ls())
setwd("./")
if (! dir.exists('./05_lasso_svmrfe_boruta')){
  dir.create('./05_lasso_svmrfe_boruta')
}
setwd('./05_lasso_svmrfe_boruta')
suppressPackageStartupMessages({
  library(magrittr)
  library(ggplot2)
  library(lance)
  library(glmnet)
  library(magrittr)
  library(tibble)
  library(mlbench)
  library(caret)
  library("Boruta")
  library(YSX)
  library(ImageGP)
  library(dplyr)
  library('xgboost')
  library("Matrix")
  library('PRROC')
  library('ggplot2')
  library('dplyr')
  library(ggvenn)
  library(tidyverse)
  library(leaps)
  library(tidyverse)
  library(caret)
  library(DALEX)
})  
source('/nas1/wangdengdong/pub/notice.r')
intersect <- read.csv('../04_4.1.ppi/interaction_genes.csv',header = F) %>% as.data.frame()
colnames(intersect)<-'GeneSymbol'
intersect <- data.frame(x=intersect$GeneSymbol)
dat_expr<-read.csv('../00_rawdata/01.fpkm.log_GSE221521.csv',row.names = 1,check.names = F) %>% lc.tableToNum
group <- read.csv('../00_rawdata/01.group_GSE221521.csv')

dat<-dat_expr[intersect$x,group$sample]%>%t%>%as.data.frame()
dat<-merge(dat,group,by.x='row.names',by.y='sample')%>%tibble::column_to_rownames(var = 'Row.names')
table(group$type)
# control      DR 
# 50      69 
dat$type<-factor(dat$type,levels = c('DR','control'))  
  
#LASSO----------
if(F){#表达验证基因不够，去掉这个方法
result <- data.frame()
for (j in c(1:2000)) {
  set.seed(j)
  res.lasso <- cv.glmnet(as.matrix(dat[-ncol(dat)]), dat$type, family = "binomial",
                         type.measure = "deviance")
  l.coef<-coef(res.lasso$glmnet.fit,s=res.lasso$lambda.min,exact= F)
  l.coef
  coef.min = coef(res.lasso, s = "lambda.min")  ## lambda.min & lambda.1se 取一个
  res.lasso$lambda.min
  active.min = which(coef.min@i != 0)
  lasso_geneids <- coef.min@Dimnames[[1]][coef.min@i+1] %>% as.data.frame()
  print(j)
  ifelse (nrow(lasso_geneids) == 0,
          result[1,j] <- NA,
          result[c(1:nrow(lasso_geneids)),j] <- lasso_geneids)
  colnames(result)[j] <- paste('seed', j)
}
notify('LASSO')
re <- unique(t(result)) %>% as.data.frame()
write.csv(re,file = 'lasso2000.csv',quote = F,row.names = T)
re <- read.csv('./lasso2000.csv',row.names = 1)


set.seed(5705)
##
#library(glmnet)
res.lasso <- cv.glmnet(as.matrix(dat[-ncol(dat)]), dat$type, family = "binomial",
                       type.measure = "deviance")

plot(res.lasso,las=1)
plot(res.lasso$glmnet.fit, xvar = 'lambda',las=1,label = TRUE,)

pdf('01.lasso.CV.pdf', w=6,h=5,family='Times')
plot(res.lasso,las=1)
dev.off()
png('01.lasso.CV.png', w=6,h=5,family='Times',units='in',res=600)
plot(res.lasso,las=1)
dev.off()

pdf('01.lasso.Coef.pdf', w=6,h=5,family='Times')
plot(res.lasso$glmnet.fit, xvar = 'lambda',las=1)
dev.off()
png('01.lasso.Coef.png', w=6,h=5,family='Times',units='in',res=600)
plot(res.lasso$glmnet.fit, xvar = 'lambda',las=1)
dev.off()


l.coef<-coef(res.lasso$glmnet.fit,s=res.lasso$lambda.min,exact= F)
l.coef
coef.min = coef(res.lasso, s = "lambda.min")  ## lambda.min & lambda.1se 取一个
res.lasso$lambda.min
#[1] 0.07881259
# 找出那些回归系数没有被惩罚为0的

pdf('01.lasso.Coef.pdf', w=6,h=5,family='Times')
plot(res.lasso$glmnet.fit, xvar = 'lambda',las=1)
abline(v = log(res.lasso$lambda.min), lty = 3,lwd = 1,col = "black")
dev.off()
png('01.lasso.Coef.png', w=6,h=5,family='Times',units='in',res=600)
plot(res.lasso$glmnet.fit, xvar = 'lambda',las=1)
abline(v = log(res.lasso$lambda.min), lty = 3,lwd = 1,col = "black")
dev.off()

# 提取基因名称
lasso_geneids <- coef.min@Dimnames[[1]][coef.min@i+1]
lasso_geneids <- lasso_geneids[-1]
lasso_geneids
#12 [1] "PRPH2"    "SLIT1"    "DRAXIN"   "CEP295NL" "UNC5A"    "MYBPH"    "SHOC1"    "ZNF134"   "IHO1"     "RAB23"    "RSL1D1"   "CCDC200"  
write.csv(lasso_geneids,file = '01.lasso.gene.csv',row.names = F,quote = F)
}
#svm-rfe----------
rm(list = ls())
setwd("./")
if (! dir.exists('./05_lasso_svmrfe_boruta')){
  dir.create('./05_lasso_svmrfe_boruta')
}
setwd('./05_lasso_svmrfe_boruta')

library(magrittr)
library(tibble)
# 加载库和包
library(mlbench)
library(caret)

intersect <- read.csv('../04_4.1.ppi/interaction_genes.csv',header = F) %>% as.data.frame()
colnames(intersect)<-'GeneSymbol'

dat_expr <- read.csv('../00_rawdata/01.fpkm.log_GSE221521.csv',row.names = 1,check.names = F) %>% lance::lc.tableToNum()
dat_group <- read.csv('../00_rawdata/01.group_GSE221521.csv')


dat<-dat_expr[intersect$GeneSymbol, dat_group$sample] %>% t %>% as.data.frame()
dat<-merge(dat,dat_group,by.x='row.names',by.y='sample')#%>%tibble::column_to_rownames(var = 'Row.names')
dat<-dat[,-1]
dat$type<-factor(dat$type) 

num <- ncol(dat)-1
result <- data.frame()
save.image('image.RData')

load('image.RData')
if(F){
for (i in c(1:2)) {
  set.seed(i)
  #set.seed(1)
  control <- rfeControl(functions = caretFuncs,method = "cv", number = 5)
  # 执行SVM-RFE算法
  results <- rfe(dat[,1:num],            #数据框格式
                 as.factor(dat[,num+1]),   #因子格式
                 sizes = c(1:num),
                 rfeControl = control,
                 method = "svmRadial"
  )
  svmrfe_result <- predictors(results)
  print(i)
  result[c(1:length(table(svmrfe_result))),i] <- svmrfe_result
  colnames(result)[i] <- paste('seedd', i)
  #print(svmrfe_result)
  #if (length(table(svmrfe_result))>3) {break}
}
re <- unique(t(result)) %>% as.data.frame()
write.csv(re,file = 'svm50.csv',quote = F,row.names = T)
re <- read.csv('../svm12/svm12.csv')
#result <- read.csv('/data/nas1/liky/project/02_YQSY-064-6/01_svm1.8.csv')
save.image('image1.RData')
#q()
}
set.seed(1)
num <- ncol(dat)-1
control <- rfeControl(functions = caretFuncs,method = "cv", number = 5)

# 执行SVM-RFE算法
results <- rfe(dat[,1:num],
               dat$type, 
               sizes = c(1:num), 
               rfeControl = control,
               method = "svmRadial"
)
notify('SVM-RFE')

# # 结果分析
print(results)
#The top 5 variables (out of 133):
#  CCDC200, POLR2A, RSL1D1, IHO1, SHOC1
svmrfe_result <- predictors(results)
svmrfe_result

length(svmrfe_result)
#75
results$results$Accuracy[75]
#0.815942
write.csv(results$results,"02.svmrfe_results.csv",row.names = F)
write.csv(svmrfe_result,"02.svmrfe_gene.csv",row.names = F,quote = F)
# saveRDS(svmrfe_result,"../00_rawdat/00_temp/svmrfe_GSE1result.rds")
# 绘制结果
# save.image(file = '02.svmrfe.RData')
# load(file = './02.svmrfe.RData')
save.image('image2.RData')
x<-results$bestSubset
#75基因数为75时，准确性最高
y<-results$results$Accuracy[x]
y #[1] 0.815942
pdf(file = paste0("02.SVM_RFE_Accuracy.pdf"),width = 5,height = 4,family='Times')
a <- dev.cur()   #记录pdf设备
png(file = paste0("02.SVM_RFE_Accuracy.png"),width = 5, height=4, units="in", res=600,family='Times') 
dev.control("enable")
par(mar = c(2,2,2,2));#下、左、上、右
plot(results, type=c("o"),
     xgap.axis = 1
)
dev.copy(which = a)  #复制来自png设备的图片到pdf
dev.off()
dev.off()





# # Boruta ------------------------------------------------------------------
rm(list = ls())
setwd("./")
if (! dir.exists('./05_lasso_svmrfe_boruta')){
  dir.create('./05_lasso_svmrfe_boruta')
}
setwd('./05_lasso_svmrfe_boruta')


intersect <- read.csv('../04_4.1.ppi/interaction_genes.csv',header = F) %>% as.data.frame()
colnames(intersect)<-'GeneSymbol'

dat_expr <- read.csv('../00_rawdata/01.fpkm.log_GSE221521.csv',row.names = 1,check.names = F) %>% lc.tableToNum
dat_group <- read.csv('../00_rawdata/01.group_GSE221521.csv')


dat<-dat_expr[intersect$GeneSymbol, dat_group$sample]%>%t%>%as.data.frame()
dat<-merge(dat,dat_group,by.x='row.names',by.y='sample')#%>%tibble::column_to_rownames(var = 'Row.names')
rownames(dat) <- dat$Row.names
dat<-dat[,-1]

df.exp <- dat
df.exp$type<-factor(df.exp$type)
set.seed(44242424)
res.Boruta<-Boruta(x=df.exp[,1: ncol(df.exp)-1], y=as.factor(df.exp[,ncol(df.exp)]), pValue=0.01, mcAdj=T,
                   maxRuns=300)
Boruta<-attStats(res.Boruta) #给出Boruta算法的结果
table(res.Boruta$finalDecision)
# Tentative Confirmed  Rejected 
#   6        20        86 
boruta_geneids<-Boruta[Boruta$decision=='Confirmed',]%>%rownames(.)
boruta_geneids
#20 [1] "CCDC200"  "POLR2A"   "RSL1D1"   "TAS1R1"   "ZNF134"   "IHO1"     "CEP295NL" "PRPH2"    "SHOC1"    "SLC36A1"  "SRCAP"    "FLCN"    
# [13] "SLIT1"    "MAST3"    "NBEAL2"   "OSMR"     "FAT2"     "TCEA3"    "RAB23"    "UNC5A"
write.csv(boruta_geneids,"03.boruta_gene.csv",row.names = F,quote = F)

##定义一个函数提取每个变量对应的重要性值。

boruta.imp <- function(x){
  imp <- reshape2::melt(x$ImpHistory, na.rm=T)[,-1]
  colnames(imp) <- c("Variable","Importance")
  imp <- imp[is.finite(imp$Importance),]
  
  variableGrp <- data.frame(Variable=names(x$finalDecision),
                            finalDecision=x$finalDecision)
  
  showGrp <- data.frame(Variable=c("shadowMax", "shadowMean", "shadowMin"),
                        finalDecision=c("shadowMax", "shadowMean", "shadowMin"))
  
  variableGrp <- rbind(variableGrp, showGrp)
  
  boruta.variable.imp <- merge(imp, variableGrp, all.x=T)
  
  sortedVariable <- boruta.variable.imp %>% group_by(Variable) %>%
    summarise(median=median(Importance)) %>% arrange(median)
  sortedVariable <- as.vector(sortedVariable$Variable)
  
  
  boruta.variable.imp$Variable <- factor(boruta.variable.imp$Variable, levels=sortedVariable)
  
  invisible(boruta.variable.imp)
}

boruta.variable.imp <- boruta.imp(res.Boruta)

head(boruta.variable.imp)
#devtools::install_github("Tong-Chen/YSX")

sp_boxplot(boruta.variable.imp, melted=T, xvariable = "Variable", yvariable = "Importance",
           legend_variable = "finalDecision", legend_variable_order = c("Tentative", "Confirmed", "Rejected", "shadowMax", "shadowMean", "shadowMin"),
           xtics_angle = 90)

pdf("03.Boruta.pdf",w = 22, h = 6,family='Times')
sp_boxplot(boruta.variable.imp, melted=T, xvariable = "Variable", yvariable = "Importance",
           legend_variable = "finalDecision", legend_variable_order = c("Confirmed", "Rejected"),
           xtics_angle = 90,manual_color_vector=c('skyblue','red3'))
dev.off()

png("03.Boruta.png",w = 22, h = 6,family='Times',units='in',res=600)
sp_boxplot(boruta.variable.imp, melted=T, xvariable = "Variable", yvariable = "Importance",
           legend_variable = "finalDecision", legend_variable_order = c("Confirmed", "Rejected"),
           xtics_angle = 90,manual_color_vector=c('skyblue','red3'))
dev.off()
#基因太多。图太长，只画Confirmed，取这部分基因，并根据重要性分值的中位数排序
bimp<-boruta.variable.imp %>% dplyr::filter(finalDecision =='Confirmed')%>% mutate(median=median(Importance),.by = Variable) %>% dplyr::select(Variable,median)%>% unique()
xcut<-as.vector(bimp[order(bimp$median),1])
#用xvariable_order=xcut控制只显示部分，也可以把legend_variable_order取想要的列，
#但不能少于两个，可以把名字改成错的，只有想要的那一列是正确的来只显示一个
pdf("03.Boruta_Confirmed.pdf",w = 8, h = 6,family='Times')
sp_boxplot(boruta.variable.imp, melted=T, xvariable = "Variable", yvariable = "Importance",
               legend_variable = "finalDecision", legend_variable_order = c("Confirmed", "Rejected"),xvariable_order=xcut,
               xtics_angle = 90,manual_color_vector=c('skyblue','red3'))
dev.off()

png("03.Boruta_Confirmed.png",w = 8, h = 6,family='Times',units='in',res=600)
sp_boxplot(boruta.variable.imp, melted=T, xvariable = "Variable", yvariable = "Importance",
           legend_variable = "finalDecision", legend_variable_order = c("Confirmed", "Rejected"),xvariable_order=xcut,
           xtics_angle = 90,manual_color_vector=c('skyblue','red3'))
dev.off()

#venn -----
#lasso<-read.csv('01.lasso.gene.csv') 
svm<-read.csv('02.svmrfe_gene.csv')
bor<-read.csv('03.boruta_gene.csv')
cand<-Reduce(intersect,list(svm$x,bor$x))#lasso$x,
length(cand)
#20
write.table(cand,"05.candidate_genes.csv",quote = F,row.names = F, col.names =F)
#GSE189005存在的基因，表达量验证用
dat<-read.csv('../00_rawdata/02.expr_GSE189005.csv',row.names = 1,check.names = F)
group <- read.csv('../00_rawdata/02.group_GSE189005.csv')
colnames(group) <- c('sample', 'group')
hub_exp<-dat[cand,group$sample] %>% na.omit()
write.table(rownames(hub_exp),"05.candidate_genes4expression.csv",quote = F,row.names = F, col.names =F)
p<-ggvenn(list('SVM-RFE'=svm$x,'Boruta'=bor$x),#'Lasso'=lasso$x,
          c('SVM-RFE','Boruta'),#'Lasso',
          fill_color = c("#ffb2b2","#8070CC"),#"#87CEEB",
          show_percentage = T,
          stroke_alpha = 0.5,
          stroke_size = 1,
          text_size = 4,
          stroke_color="white",
          stroke_linetype="solid",
          set_name_color=c("#ffb2b2","#8070CC"),#"#87CEEB",
          text_color = 'black')
p
ggsave("04-1.venn.png",p,width = 8, height = 6)
ggsave("04-1.venn.pdf",p,width = 8, height = 6)  


  
  

  #包列表----
  pkgs<-lapply(sessionInfo()$otherPkgs,function(x){x$Version}) %>% as.data.frame() %>%t()
  write.table(pkgs,'pkgs.tsv',quote = F,sep = '\t',col.names=F)
