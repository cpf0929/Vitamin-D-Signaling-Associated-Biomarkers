rm(list = ls())
setwd('./')
if (! dir.exists('./01_DEG')){
  dir.create('./01_DEG')
}
setwd('./01_DEG')
library(tidyverse)
library(lance)
library(DESeq2)

#对照和DR----------------
count <- read.csv('../00_rawdata/01.count_GSE221521.csv', row.names = 1, check.names = F) %>% lc.tableToNum()
count <- round(count, digits = 0) 
group <- read.csv('../00_rawdata/01.group_GSE221521.csv', row.names = 1, check.names = F)
identical(colnames(count), rownames(group))
table(group$type)
# control      DR 
# 50      69 
group$type <- factor(group$type, levels = c('control', 'DR'))

dds <- DESeqDataSetFromMatrix(countData = count, colData = group, design = ~type)
dds <- dds[rownames(counts(dds)) > 1,]
dds <- estimateSizeFactors(dds)
dds <- DESeq(dds)

res <- results(dds, contrast = c('type', 'DR', 'control'))
res <- res[order(res$padj),]
head(res)
summary(res)
# out of 18810 with nonzero total read count
# adjusted p-value < 0.1
# LFC > 0 (up)       : 3088, 16%
# LFC < 0 (down)     : 2633, 14%
# outliers [1]       : 0, 0%
# low counts [2]     : 2565, 14%
# (mean count < 0)
table(res$padj < 0.05)
# FALSE  TRUE 
# 11677  4584 
save.image(file = 'DEGresult.RData')
load('DEGresult.RData')

#差异基因
DEG <- as.data.frame(res)
DEG <- na.omit(DEG)
dim(DEG)
#[1] 16261     6
head(DEG)

logFC_cutoff <- 0.5
DEG$change <- as.factor(
  ifelse(DEG$pvalue < 0.05 & abs(DEG$log2FoldChange) > logFC_cutoff,
         ifelse(DEG$log2FoldChange > logFC_cutoff, 'UP', 'DOWN'), 'NOT'))
table(DEG$change)
# DOWN   NOT    UP 
# 366 15241   654
DEG_sig <- subset(DEG, DEG$pvalue < 0.05 & abs(DEG$log2FoldChange) >= logFC_cutoff)
dim(DEG_sig)
# 1020    7

DEG_write <- cbind(GeneSymbol = rownames(DEG), DEG)
write.csv(DEG_write, file = '01.DEG_all.csv', quote = F, row.names = F)

DEG_sig_write <- cbind(GeneSymbol = rownames(DEG_sig), DEG_sig)
write.csv(DEG_sig_write, file = '01.DEG_sig_plogfc0.5.csv', quote = F, row.names = F)

#火山图---------
#devtools::install_github("kongdd/Ipaper")
library(ggplot2)
library(ggthemes)
library(RColorBrewer)
library(Ipaper)
library(scales)
library(ggrepel)

dat_rep <- rbind(head(DEG_sig[order(DEG_sig$log2FoldChange,decreasing = T),],10),
                 head(DEG_sig[order(DEG_sig$log2FoldChange,decreasing = F),],10))

volcano_plot <- ggplot(data = DEG,
                       aes(x = log2FoldChange, #aes告诉ggplot()谁是x谁是y，啥颜色等等
                           y = -log10(pvalue),
                           color = change)) +
  scale_color_manual(values = c("#569dcb", "darkgray","#f49c4d")) +
  scale_x_continuous(breaks = c(-2,-1,0,1,2)) +
  scale_y_continuous(trans = "log1p", #y轴变换函数
                     breaks = c(0,1,5,10,20,50, 100,200)) +
  geom_point(size = 1.5, alpha = 0.8, na.rm=T) + #散点图
  theme_bw(base_size = 12, base_family = "Times") + #默认背景，经典的暗光情节主题。
  geom_vline(xintercept = c(-0.5,0.5), #参考线
             lty = 4,
             col = "darkgray",
             lwd = 0.6)+
  geom_hline(yintercept = -log10(0.05),
             lty = 4,
             col = "darkgray",
             lwd = 0.6)+
  theme(legend.position = "right", #图例位置
        panel.grid = element_blank(),
        legend.title = element_text(face = "bold",
                                    color = "black",
                                    size = 15),
        legend.text = element_text(face="bold",
                                   color="black",
                                   family = "Times",
                                   size=13),
        plot.title = element_text(hjust = 0.5),
        axis.text.x = element_text(face = "bold",
                                   color = "black",
                                   size = 15),
        axis.text.y = element_text(face = "bold",
                                   color = "black",
                                   size = 15),
        axis.title.x = element_text(face = "bold",
                                    color = "black",
                                    size = 15),
        axis.title.y = element_text(face = "bold",
                                    color = "black",
                                    size = 15),
        text = element_text(family = "Times")) +
  geom_label_repel(
    data = dat_rep,
    aes(label = rownames(dat_rep)),
    max.overlaps = 20,
    size = 4,
    box.padding = unit(0.5, "lines"),
    min.segment.length = 0,
    point.padding = unit(0.8, "lines"), segment.color = "black", show.legend = FALSE,family = "Times" )+
  labs(x = "log2 (Fold Change)",
       y = "-log10 (p value)")
volcano_plot
pdf('01.volcano.pdf',  w=8,h=6,family='Times')
volcano_plot
dev.off()
png('01.volcano.png',  w=8,h=6,family='Times', units='in',res=600)
volcano_plot
dev.off()

# ### 箱线图-一起------------
# expr <- read.csv('../00_rawdata/01.fpkm_log2.csv',check.names = F, row.names = 1)
# top.exp <- expr[rownames(dat_rep),]
# hub_exp2 <- top.exp
# hub_exp2$Symbol<-rownames(hub_exp2)
# hub_exp2<-gather(hub_exp2,
#                  key = sample,
#                  value = expr,
#                  -c("Symbol"))
# group$sample <- rownames(group)
# control.sample <- group$sample[which(group$Type=='Normal')]
# ## 样本分组
# hub_exp2$Group<-ifelse(hub_exp2$sample%in%control.sample,'control','tumor')
# ##分面图形
# library(ggplot2)
# library(tidyverse)
# library(ggpubr)
# library(ggsci)
# library(rstatix)
# stat.test<-hub_exp2%>%
#   group_by(Symbol)%>%
#   wilcox_test(expr ~ Group)%>%
#   adjust_pvalue(method = 'fdr')
# 
# df <- DEG_sig[stat.test$Symbol,]
# stat.test$pDEG <- df$pvalue %>% as.numeric()
# 
# stat.test$pDEG1[stat.test$pDEG>0.05] <- "ns"
# stat.test$pDEG1[stat.test$pDEG<0.05&stat.test$pDEG>0.01] <- "*"
# stat.test$pDEG1[stat.test$pDEG<0.01&stat.test$pDEG>0.001] <- "**"
# stat.test$pDEG1[stat.test$pDEG<0.001&stat.test$pDEG>0.0001] <- "***"
# stat.test$pDEG1[stat.test$pDEG<0.0001] <- "****"
# 
# stat.test$change <- df$change
# stat.test <- stat.test[order(stat.test$change,decreasing = T),]
# # diff <- read.csv('../01_DEGs_GSE77287/DEG_sig.GSE77287.csv',row.names = 1)
# # df<-diff[stat.test$Symbol,]
# # stat.test$p<-df$P.Value%>%as.numeric()%>%round(digits = 3)
# # stat.test$p<-ifelse(stat.test$p<0.001,"***",
# #                     ifelse(stat.test$p<0.05,"**",
# #                            ifelse(stat.test$p<0.05,"*",'ns')))
# 
# plotdat.expr <- hub_exp2
# plotdat.p <- stat.test
# level <- plotdat.p$Symbol
# 
# plotdat.expr$Symbol <- factor(plotdat.expr$Symbol, levels = level)
# library(ggpubr)
# p <- ggboxplot(plotdat.expr , x = "Symbol", y = "expr", 
#                fill= "Group",
#                palette = c( "#a8ddeb","#f5a49d"),  
#                outlier.shape = NA,
#                bxp.errorbar = T,
#                width = 0.5
#                #add = "mean_se"
#                
# ) +ylim(0,15)+
#   stat_pvalue_manual(plotdat.p ,
#                      x = "Symbol",
#                      y.position = 15,
#                      size =4.5,
#                      color = "black",
#                      family = "Times",
#                      # label = paste0("~italic(p)=={p.adj2}"),
#                      label = "pDEG1"
#                      #parse = T
#   ) +
#   theme_bw()+
#   labs(x = "", y = "expr", color = "") +
#   theme(axis.title.x = element_text(size = 20, face = "bold", family = "Times"),
#         axis.title.y = element_text(size = 20, face = "bold", family = "Times"),
#         axis.text.x = element_text(size = 13, color='black',face = "bold", family = "Times", angle = 45, vjust = 1, hjust = 1),
#         axis.text.y = element_text(size = 15, face = "bold", family = "Times"),
#         legend.text = element_text(size = 15, family = "Times",face = "bold"),
#         legend.title = element_text(size = 18, family = "Times",face = "bold"),
#         #plot.margin = ggplot2::margin(t=.3,b=0,l=2,r=.5, unit = "cm"),
#         text = element_text(family = "Times"),
#         panel.grid.major=element_blank(),panel.grid.minor=element_blank())+
#   theme(legend.position = "top")
# p
# ggsave(filename = "02.box.pdf", width = 12, height = 7)
# ggsave(filename = "02.box.png", width = 12, height = 7)



### 密度热图--------
library(ComplexHeatmap)
library(circlize)
group1 <- data.frame(sample=rownames(group),Type=group$type)
group1 <- group1[order(group1$Type,decreasing = F),]

gene.expr <- count[rownames(dat_rep),group1$sample]
mat <- gene.expr
mat <- t(scale(t(gene.expr)))  # 归一化,让数据分布更加均匀
#df1 <- as.data.frame(mat)
# 给极大值和极小值赋值，让图片更好看
mat[mat < (-2)] <- -2
mat[mat > 2] <- 2

# 热图的注释信息
annotation_col <- data.frame(row.names=group1$sample, Group=group1$Type)
annotation_row <- data.frame(row.names=rownames(dat_rep),sig=dat_rep$log2FoldChange)
annotation_row <- annotation_row[order(annotation_row$sig, decreasing = F),,drop=F] #drop保留之前的数据类型
mat <- mat[rownames(annotation_row),]
identical(colnames(mat), rownames(annotation_col))
library(myplot)

col_fun<-colorRamp2(c(-2,0,2),c("#569dcb", "white","#f49c4d"))
mp<-densityHeatmap(mat ,title = "Distribution as heatmap", ylab = " ",height = unit(6, "cm")) %v%
  HeatmapAnnotation(Group = annotation_col$Group, col = list(Group = c("DR" = "#f49c4d", "control" = "#569dcb"))) %v%
  Heatmap(mat, row_names_gp = gpar(fontsize = 9),
          show_column_names = F,name = "expression",
          height = unit(6, "cm"),
          cluster_columns = FALSE,
          cluster_rows = FALSE,
          col = col_fun)
mp
pdf('01.heatmap.pdf', w=6,h=6,family='Times')
print(mp)
dev.off()
png('01.heatmap.png',w=6,h=6,units='in',res=600,family='Times')
print(mp)
dev.off()



# # #3.交集1---------------
# rm(list = ls())
# setwd('./')
# if (! dir.exists('./01_DEG')){
#   dir.create('./01_DEG')
# }
# setwd('./01_DEG')
# 
# gene1 <- read.csv(file = './01.DEG_sig_plogfc0.5.csv',check.names = F)
# gene2 <- read.csv(file = '../00_rawdata/00.NAD-RGs.csv',check.names = F)
# 
# intersect <- data.frame(symbol = intersect(gene1$GeneSymbol, gene2$symbol))
# write.csv(intersect,file = "03.intersectGenes.csv",quote = F,row.names = F)
# 
# # 
# # #venn画图
# # library(ggvenn)
# # mydata<-list('Tumour vs Control' = gene2$GeneSymbol,'Cluster3 vs Cluster1' = gene1$GeneSymbol)
# # pdf('03.venn.pdf',w=5,h=3,family='Times')
# # ggvenn(mydata,c('Tumour vs Control', 'Cluster3 vs Cluster1'),
# #        fill_color = c("#CD2990", "#87CEFA"),
# #        show_percentage = T,
# #        stroke_alpha = 0.5,
# #        stroke_size = 0.5,
# #        text_size = 3,
# #        stroke_color="#AE6378",
# #        stroke_linetype="dashed",
# #        set_name_color=c("#CD2990","#87CEFA"),
# #        text_color = 'black')
# # dev.off()
# # png('03.venn.png',w=5,h=3,units = 'in',res = 600,family='Times')
# # ggvenn(mydata,c('Tumour vs Control', 'Cluster3 vs Cluster1'),
# #        fill_color = c("#CD2990","#87CEFA"),
# #        show_percentage = T,
# #        stroke_alpha = 0.5,
# #        stroke_size = 0.5,
# #        text_size = 3,
# #        stroke_color="#AE6378",
# #        stroke_linetype="dashed",
# #        set_name_color=c("#CD2990","#87CEFA"),
# #        text_color = 'black')
# # dev.off()
#包列表----
pkgs<-lapply(sessionInfo()$otherPkgs,function(x){x$Version}) %>% as.data.frame() %>%t()
write.table(pkgs,'pkgs.tsv',quote = F,sep = '\t',col.names=F)
