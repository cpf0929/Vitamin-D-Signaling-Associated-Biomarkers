#119个样本
#239个特征
#机器学习的基因有点多，模型容易过拟合
#把输入的特征数，降到少于样本数
#因为他会排列组合，所以这么多量会跑的巨慢无比，计算量太大
#你看看前面差异之类的地方调整一下，让输入基因少一些
#也可以加ppi筛选
#
rm(list = ls())
setwd('./')
if (! dir.exists('./04_candi_gene')){
  dir.create('./04_candi_gene')
}
setwd('./04_candi_gene')
suppressPackageStartupMessages({
  library(ggvenn)
  library(dplyr)
  library(clusterProfiler)
library(org.Hs.eg.db)
library(enrichplot)
library(ggplot2)
library(GOplot)
library(cowplot)
library(patchwork)
  library(treemap)
})

# 04-1 venn----
deg<-read.csv('../01_DEG/01.DEG_all.csv') %>% filter(change != 'NOT')
hubg<-read.csv('../03_WGCNA/modGene.xls',header = F)
colnames(hubg)<-'symbol'
cand<-intersect(deg$GeneSymbol,hubg$symbol)
length(cand)
#239
write.table(cand,"candidate_genes.csv",quote = F,row.names = F, col.names =F)
p<-ggvenn(list('DEGs'=deg[,1],'ModGenes'=hubg[,1]),
          c('DEGs','ModGenes'),
          fill_color = c("#ffb2b2","#8070CC"),#"#87CEEB",
          show_percentage = T,
          stroke_alpha = 0.5,
          stroke_size = 1,
          text_size = 4,
          stroke_color="white",
          stroke_linetype="solid",
          set_name_color=c("#ffb2b2","#8070CC"),#"#87CEEB",
          text_color = 'black')
p
ggsave("04-1.venn.png",p,width = 8, height = 6)
ggsave("04-1.venn.pdf",p,width = 8, height = 6)
#04-2 enrich go----
pFilter<-0.05
adjPfilter<-0.05
cand<-read.delim2("./candidate_genes.csv",header =F )
cand<-inner_join(cand,deg,by=join_by(V1==GeneSymbol))
genes<-cand$V1
entrezIDs<-mget(genes, org.Hs.egSYMBOL2EG, ifnotfound=NA)        #找出基因对应的id
entrezIDs<-as.character(entrezIDs)
cand<-cbind(cand,entrezID=entrezIDs)
cand<-cand[is.na(cand[,"entrezID"])==F,]  
names(cand)[1]<-'gene'
#删掉没有基因ID的
gene<-cand$entrezID
ego<-enrichGO(gene = gene,
              OrgDb = org.Hs.eg.db, 
              pvalueCutoff =pFilter, 
              pAdjustMethod='none',
              qvalueCutoff = 1,
              ont="all",
              readable =T)
#富集结果为空
nrow(ego)

#padjustmethod改成none，不矫正pvalue
write.csv(ego,"GO.csv",quote=T,row.names = F)
# 展示富集最显著的 GO term
go_bar<-dotplot(ego, showCategory=5, split="ONTOLOGY",label_format = 70) +
  facet_grid(ONTOLOGY ~ ., scales = "free",space = 'free')
go_bar
ggsave('04.GO_dot.png',go_bar,width =10,height = 8)
ggsave('04.GO_dot.pdf',go_bar,width =10,height = 8)
#和弦图
# 整理go信息
GO=as.data.frame(ego)
go=data.frame(Category = GO$ONTOLOGY,ID = GO$ID,Term = GO$Description, Genes = gsub("/", ", ", GO$geneID), adj_pval = GO$p.adjust)
# 得到logFC
genelist=data.frame(ID = cand$gene, logFC = cand$log2FoldChange)
row.names(genelist)=genelist[,1]

# 得到最终绘制图片所需数据集
circ <- circle_dat(go, genelist)
#弦表图
pgo<-GOCircle(circ)
pgo
ggsave('04.GO_circle.png',pgo,width =13,height = 8)
ggsave('04.GO_circle.pdf',pgo,width =13,height = 8)
#方案要求画circle图
#弦图报错
if(F){
termNum = 10                                     #限定GO数目（仅展示前5）
termNum=ifelse(nrow(go)<termNum,nrow(go),termNum)
geneNum =20    #连接太少GOChord会报错，不既定geneNum，直接改成nrow(go)
geneNum =ifelse(nrow(genelist)  <termNum,nrow(genelist)  ,geneNum)                       #限定基因数目
chord <- chord_dat(circ, genes=genelist[1:geneNum,], process=go$Term[1:termNum])
head(chord)
plotgo<-GOChord(chord, 
                space = 0.001,           #基因之间的间距
                gene.order = 'logFC',    #排序基因
                gene.space = 0.25,       #基因离圆圈距离
                gene.size = 3,           #
                border.size = 0.1,     
                process.label = 7,       #GO名称大小
                lfc.col=c('firebrick3', 'white','royalblue3'),##上调下调颜色设置
                ribbon.col=brewer.pal(length(go$Term[1:termNum]), 'Set3'),#GO term 颜色设置
)
#去掉lfc渐变条
cols<-rep(brewer.pal(length(go$Term[1:termNum]), 'Set3'), each = 4 + 2 * 50)
p2<-plotgo+
  scale_fill_gradient2(guide = F)+
  guides(size = guide_legend("GO Terms", 
                             ncol = 3, 
                             byrow = T, 
                             override.aes = list(shape = 22,fill = unique(cols), size = 8) ) ) + 
  theme(legend.text = element_text(size = 5))
leg<-get_legend(p2)
#Go terms由4栏改成3栏
#p3<-p2+
p4<-plotgo+guides(size=FALSE)+theme(legend.position = "right", 
                                    legend.background = element_rect(fill = "transparent"), 
                                    legend.box = "vertical", legend.direction = "vertical",
                                    legend.key.height = unit(1, "inch") #ggsave高度8inch，lfc[-2-3]总共5inch
)
p5<-plot_grid(p4,leg,ncol = 1,align = 'hv',axis='t',rel_heights = c(1,0.3))

ggsave('06.GO_chrod.png',p5,width =8,height = 8)
ggsave('06.GO_chrod.pdf',p5,width =8,height = 8)
}
#04-3 enrich kegg----
## KEGG富集分析（气泡图）
kk <- enrichKEGG(gene = gene,
                 keyType = "kegg",
                 organism = "hsa",
                 pAdjustMethod = "none",
                 pvalueCutoff = 0.05,
                 qvalueCutoff = 1)
kk <- setReadable(kk, OrgDb = org.Hs.eg.db, keyType="ENTREZID")
write.table(kk@result,file = "KEGG.xls",sep = "\t",quote = F,row.names = F)
kk_dot <- dotplot(kk, showCategory=15,label_format = 50)
kk_dot
ggsave('04.KEGG_dot.png',kk_dot,width =5,height = 4)
ggsave('04.KEGG_dot.pdf',kk_dot,width =5,height = 4)
eko<-kk@result
termNum = 10                                     #限定kegg数目（仅展示前5）
termNum=ifelse(nrow(kegg)<termNum,nrow(kegg),termNum)
kegg<-data.frame(Category = eko$Description,ID = eko$ID,Term = eko$Description, Genes = gsub("/", ", ", eko$geneID), adj_pval = eko$p.adjust)
circ <- circle_dat(kegg, genelist)
geneNum =ifelse(nrow(genelist)  <termNum,nrow(genelist)  ,geneNum)
chord <- chord_dat(circ, genes=genelist[1:geneNum,], process=kegg$Term[1:termNum])
plotk<-GOChord(chord, 
               space = 0.001,           #基因之间的间距
               gene.order = 'logFC',    #排序基因
               gene.space = 0.25,       #基因离圆圈距离
               gene.size = 3,           #
               border.size = 0.1, 
               #limit = c(3, 1),## 仅显示分配给至少三个通路的基因
               process.label = 7,       #GO名称大小
               lfc.col=c('firebrick3', 'white','royalblue3'),##上调下调颜色设置
               ribbon.col=brewer.pal(length(kegg$Term[1:termNum]), 'Set3'),#GO term 颜色设置
)
cols<-rep(brewer.pal(length(kegg$Term[1:termNum]), 'Set3'), each = 4 + 2 * 50)
p2<-plotk+
  scale_fill_gradient2(guide = F)+
  guides(size = guide_legend("", 
                             ncol = 5, 
                             byrow = T, 
                             override.aes = list(shape = 22, fill = unique(cols), 
                                                 size = 8))) + 
  theme(legend.text = element_text(size = 5)
  )
p4<-plotk+guides(size=FALSE)+theme(legend.position = "right", 
                                   legend.background = element_rect(fill = "transparent"), 
                                   legend.box = "vertical", legend.direction = "vertical",
                                   legend.key.height = unit(1, "inch") #ggsave高度8inch，lfc[-2-3]总共5inch
)
leg<-get_legend(p2)
p5<-plot_grid(p4,leg,ncol = 1,align = 'hv',axis='t',rel_heights = c(1,0.3))
p5
ggsave('04.kegg_chrod.png',p5,width =8,height = 8)
ggsave('04.kegg_chrod.pdf',p5,width =8,height = 8)
###矩形树图-----
result <- eko[order(eko$p.adjust,decreasing = F),] %>% filter(p.adjust <0.05)
plot_dat <- result#[1:5,]
plot_dat$Description <- paste0(plot_dat$Description,"\n(",plot_dat$Count,")")
go_plot <- function(){
  treemap(
  plot_dat,
  index = "Description",
  vSize = "Count",
  vColor = "p.adjust",
  type = "value",
  title = "KEGG Enrichment",
  palette = 'Set2' #blueWhiteRed(3)
)
}
go_plot()
png('04.kegg_treemap.png',width=10,height=10,units = 'in',res=300,family='Times')
go_plot()
dev.off()
pdf('04.kegg_treemap.pdf',width=10,height=10,family='Times')
go_plot()
dev.off()
# pdf("01.GSEA.pdf",width = width,height = height,family = "Times")
# go_plot()
# dev.off()
# png("01.GSEA.png",width = width,height = height,family="Times",units = "in",res = 300)