rm(list=ls())
source('../../..//notice.r')
setwd('./')
if (! dir.exists("./14.scRNA")){
  dir.create("./14.scRNA")
}
setwd("./14.scRNA")
# 06.singleR ------
if (! dir.exists("./06_cell_annot")){
  dir.create("./06_cell_annot")
}
setwd("./06_cell_annot")
UMAP<-readRDS('UMAP.celltype.rds')
options(stringsAsFactors = F)
library(Seurat)
library(ggplot2)
library(clustree)
library(cowplot)
library(dplyr)
library(stringr)  
library(harmony)
library(tidyverse)
library(patchwork)
library(data.table)
## 6.1 识别各celltype中的marker基因 ----
#利用FindAllMarkers寻找每一种细胞类型的topMarker基因
# check the current active plan
library(future)
plan()
plan("multicore", workers = 24)
plan()
print('start at:')
Sys.time()
all.markers <- FindAllMarkers(UMAP,only.pos = TRUE,min.pct = 0.25,
                              logfc.threshold = 1.2,test.use = 'wilcox',return.thresh = 0.05)
write.csv(all.markers,file = '06.2.AllMarkers_celltype.csv',quote = F)
saveRDS(all.markers,'all.markers_celltype.rds')

print('FindAllMarkers:');Sys.time()
# all.markers <- readRDS('all.markers_celltype.rds')
