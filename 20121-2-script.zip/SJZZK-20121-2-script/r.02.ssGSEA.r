#表达---------------
rm(list = ls())
setwd("./")
if (! dir.exists("./02_ssGSEA/")){
  dir.create("./02_ssGSEA")
}
setwd("./02_ssGSEA")

library(tidyverse)
#gene <- read.csv('../00_rawdata/02.exprlog_GSE12050.csv') %>% as.data.frame()
gene.all <- read.csv('../00_rawdata/00.VD_RGs.tsv') %>% as.data.frame()
#gene.all <- gene.all[gene.all$X %in% gene$X, ]
dat<-read.csv('../00_rawdata/01.fpkm.log_GSE221521.csv',row.names = 1)

# dat <- gene.all
# rownames(dat) <- dat$X
# dat <- dat[,-1]


group <- read.csv('../00_rawdata/01.group_GSE221521.csv')
#group$type <- ifelse(group$type == 'case', 'case', 'control') 
colnames(group) <- c('sample', 'group')

table(group$group)

hub_exp<-dat[rownames(dat)%in%gene.all$symbol, group$sample]
hub_exp <- hub_exp[which(rowSums(hub_exp) > 0),]
hub_exp2<-hub_exp
hub_exp2$Symbol<-rownames(hub_exp2)
hub_exp2<-gather(hub_exp2,
                 key = sample,
                 value = expr,
                 -c("Symbol"))
#stat.test0.05 <- stat.test[stat.test$p<0.05,]
control.sample <- group$sample[which(group$group=='control')]
## 样本分组
hub_exp2$Group<-ifelse(hub_exp2$sample%in%control.sample,'control','DR')
##分面图形
library(ggplot2)
library(tidyverse)
library(ggpubr)
library(ggsci)
library(rstatix)
stat.test<-hub_exp2%>%
  group_by(Symbol)%>%
  wilcox_test(expr ~ Group)%>%
  adjust_pvalue(method = 'fdr')
# stat.test0.05 <- stat.test[stat.test$p<0.05,]
# write.csv(stat.test0.05,'./stat.test0.05.61.GSE221521.csv')

stat.test1 <- stat.test
a <- dat
a <- a[stat.test1$Symbol,]
identical(stat.test1$Symbol,rownames(a))
stat.test1$direction <- NA
for (i in 1:nrow(stat.test1)) {
  stat.test1$direction[i]<-ifelse(stat.test1$p[i] > 0.05,'NO',
                                  ifelse(median(as.numeric(a[,group$group=='DR'][i,]))>median(as.numeric(a[,group$group=='control'][i,])),'UP','DOWN'))
}
stat.test.0.5 <- stat.test1[stat.test1$p<0.05,]
write.csv(stat.test.0.5,'./01.stat.test.0.05_VD.csv')
#单基因表达量只有一个基因可以通过wilcoson
### 箱线图-一起------------

stat.test$p[stat.test$p>0.05] <- "ns"
stat.test$p[stat.test$p<0.05&stat.test$p>0.01] <- "*"
stat.test$p[stat.test$p<0.01&stat.test$p>0.001] <- "**"
stat.test$p[stat.test$p<0.001&stat.test$p>0.0001] <- "***"
stat.test$p[stat.test$p<0.0001] <- "****"

plotdat.expr <- hub_exp2[hub_exp2$Symbol %in% stat.test.0.5$Symbol,]
plotdat.p <- stat.test[stat.test$Symbol %in% stat.test.0.5$Symbol,]
level <- plotdat.p$Symbol
plotdat.expr$Symbol <- factor(plotdat.expr$Symbol, levels = level)
library(ggpubr)
p <- ggboxplot(plotdat.expr , x = "Symbol", y = "expr",
               fill= "Group",
               palette = c( "#569dcb","#f49c4d"),
               outlier.shape = NA,
               bxp.errorbar = T,
               width = 0.5
               #add = "mean_se"
               
) +ylim(0,7)+
  stat_pvalue_manual(plotdat.p ,
                     x = "Symbol",
                     y.position = 7,
                     size =4.5,
                     color = "black",
                     family = "Times",
                     # label = paste0("~italic(p)=={p.adj2}"),
                     label = "p"
                     #parse = T
  ) +
  theme_bw()+
  labs(x = "", y = "expr", color = "") +
  theme(axis.title.x = element_text(size = 20, face = "bold", family = "Times"),
        axis.title.y = element_text(size = 20, face = "bold", family = "Times"),
        axis.text.x = element_text(size = 13, color='black',face = "bold", family = "Times", angle = 45, vjust = 1, hjust = 1),
        axis.text.y = element_text(size = 15, face = "bold", family = "Times"),
        legend.text = element_text(size = 15, family = "Times",face = "bold"),
        legend.title = element_text(size = 18, family = "Times",face = "bold"),
        #plot.margin = ggplot2::margin(t=.3,b=0,l=2,r=.5, unit = "cm"),
        text = element_text(family = "Times"),
        panel.grid.major=element_blank(),panel.grid.minor=element_blank())+
  theme(legend.position = "top")
p
ggsave(p,filename = "01.box.pdf", width = 12, height = 7)
ggsave(p,filename = "01.box.png", width = 12, height = 7)


# rm(list = ls())
# setwd('./')
# if (! dir.exists('./02_ssGSEA')){
#   dir.create('./02_ssGSEA')
# }
# setwd('./02_ssGSEA')
# 
# #方向直接取交集------
# gene1 <- read.csv(file = '../01_DEG.limma/01.DEG_sig_plogfc0.5.GSE150408.csv',check.names = F, row.names = 1)
# #gene1 <- read.csv(file = './01.DEG_sig_cluster3vs1_adjp0.05logfc1.csv',check.names = F)
# gene2 <- read.csv(file = '../00_rawdata/00.NAD-RGs.csv',check.names = F)
# 
# intersect <- data.frame(symbol = intersect(rownames(gene1), gene2$symbol))
# write.csv(intersect,file = "01.DEPMRGs.csv",quote = F,row.names = F)
# # 
# # 
# #venn画图
# library(ggvenn)
# mydata<-list('DEGs' = gene1$GeneSymbol,'PMRGs' = gene2$symbol)
# pdf('01.venn.pdf',w=5,h=3,family='Times')
# ggvenn(mydata,c('DEGs', 'PMRGs'),
#        fill_color = c("#99bce2", "#fca2aa"),
#        show_percentage = T,
#        stroke_alpha = 0.5,
#        stroke_size = 1,
#        text_size = 3,
#        stroke_color="white",
#        stroke_linetype="dashed",
#        set_name_color=c("#6a84a0","#a6666b"),
#        text_color = 'black')
# dev.off()
# png('01.venn.png',w=5,h=3,units = 'in',res = 600,family='Times')
# ggvenn(mydata,c('DEGs', 'PMRGs'),
#        fill_color = c("#99bce2", "#fca2aa"),
#        show_percentage = T,
#        stroke_alpha = 0.5,
#        stroke_size = 1,
#        text_size = 3,
#        stroke_color="white",
#        stroke_linetype="dashed",
#        set_name_color=c("#6a84a0","#a6666b"),
#        text_color = 'black')
# dev.off()

#ssGSEA--------
# rm(list = ls())
# setwd('./')
# if (! dir.exists('./02_ssGSEA')){
#   dir.create('./02_ssGSEA')
# }
# setwd('./02_ssGSEA')

library(GSVA)
#gene_set <- read.csv('../02_ssGSEA/01.stat.test.0.05_NAD.csv')
gene_set<-read.csv('../00_rawdata/00.VD_RGs.tsv') %>% as.data.frame() 
#gene_set$symbol <- ifelse(gene_set$symbol=='PYCR3', 'PYCRL', gene_set$symbol) #基因找不到，使用别名
gene_set <- data.frame(symbols = gene_set$symbol, pathway =rep('VDscore',length(gene_set$symbol)))
# DEG <- read.csv('../01_DEG/01.DEG_sig_TvsN.csv')
# gene_set <- gene_set[gene_set$symbols %in% DEG$GeneSymbol,]

fpkm_log2 <- read.csv('../00_rawdata/01.fpkm.log_GSE221521.csv',row.names = 1,check.names = F)

dat.final2 <- as.matrix(fpkm_log2)
gene_list <- split(as.matrix(gene_set)[,1],
                   gene_set[,2])

ssgsea_score = gsva(dat.final2, gene_list, 
                    method = "ssgsea", 
                    ssgsea.norm = TRUE, 
                    verbose = TRUE)
write.csv(ssgsea_score,
          file = "02.ssgsea_result.csv",
          quote = F)

save.image('ssgsea.RData')
load('./ssgsea.RData')
# ## 富集分数画热图------------
# group<-group[order(group$group),]
# ssgsea_score<-ssgsea_score[,group$sample]
# annotation_col<-as.data.frame(group$group)
# colnames(annotation_col)='Group'
# rownames(annotation_col)=colnames(ssgsea_score)
# 
# color.key<-c("#3300CC", "#3399FF", "white", "#FF3333", "#CC0000")
# ann_colors<-list(
#   Group = c('Low risk'="#00FFFF",'High risk'="#FFAEB9"))
# pheatmap(
#   ssgsea_score,
#   color = colorRampPalette(color.key)(50),
#   border_color = 'darkgrey',
#   annotation_col = annotation_col,
#   annotation_colors = ann_colors,
#   labels_row = NULL,
#   clustering_method = 'ward.D2',
#   show_rownames = T,
#   show_colnames = F,
#   fontsize_col = 5,
#   cluster_cols = F,
#   cluster_rows = T)

##差异分析-------
rm(list = ls())
setwd('./')
if (! dir.exists('./02_ssGSEA')){
  dir.create('./02_ssGSEA')
}
setwd('./02_ssGSEA')

load('./ssgsea.RData')

group <- read.csv('../00_rawdata/01.group_GSE221521.csv')
colnames(group) <- c('sample', 'Group')
ssgsea_result <- ssgsea_score
ssgsea_result <- data.frame(t(ssgsea_result))
ssgsea_result$sample <- rownames(ssgsea_result)
ssgsea_result <- merge(ssgsea_result, group, by.x = 'sample', by.y = 'sample')

library(tidyr)
ssgsea_result<-gather(ssgsea_result,
                      key = pathway,
                      value = score,
                      -c("sample",'Group'))
plot.dat <- ssgsea_result

library(ggpubr)
library(ggplot2)
plot.dat$Group <- factor(plot.dat$Group, levels = c('control','DR'))
exp_plot <- ggplot(plot.dat,aes(x = Group, y = score, color = Group)) +
  geom_violin(trim=F,color='black',aes(fill=Group)) + #绘制小提琴图, “color=”设置小提琴图的轮廓线的颜色(#不要轮廓可以设为white以下设为背景为白色，其实表示不要轮廓线)
  #"trim"如果为TRUE(默认值),则将小提琴的尾部修剪到数据范围。如果为FALSE,不修剪尾部。
  stat_boxplot(geom="errorbar", 
               width=0.1,
               position = position_dodge(0.9)) +
  geom_boxplot(width=0.4,
               position=position_dodge(0.9),
               outlier.shape = NA)+ #绘制箱线图，此处width=0.1控制小提琴图中箱线图的宽窄
  scale_fill_manual(values= c("#326e89","#ff8340"), name = "Group")+
  labs(title="VD score", x="", y = "",size=20) +
  scale_colour_manual(values = c("#ff9a9b","#d2e099"))+
  # scale_color_brewer(palette = 'Set2')+
  stat_compare_means(comparisons = list(c('control','DR')),
                     method = "wilcox.test",
                     label = 'p.signif',
                     label.x = 1.4,
                     label.y = 0.7)+
  theme_bw()+
  theme(plot.title = element_text(hjust =0.5,colour="black",face="bold",size=15),
        axis.text.x=element_text(angle=0,hjust=0.5,colour="black",face="bold",size=12), 
        axis.text.y=element_text(hjust=0.5,colour="black",face="bold",size=12), 
        axis.title.x=element_text(size=16,face="bold"),
        axis.title.y=element_text(size=16,face="bold"),
        legend.text=element_text(face = "bold", hjust = 0.5,colour="black", size=12),
        legend.title = element_text(face = "bold", size = 12),
        legend.position = "top",
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        text=element_text(family='Times'))#+
#facet_wrap(~Symbol,scales = "free",nrow = 2) 
exp_plot
ggsave(filename = '02.score_wilcox.pdf',exp_plot,w=8,h=6)
ggsave(filename = '02.score_wilcox.png',exp_plot,w=8,h=6,dpi = 600)



# #KM---------
# rm(list = ls())
# setwd('./')
# if (! dir.exists('./02_ssGSEA')){
#   dir.create('./02_ssGSEA')
# }
# setwd('./02_ssGSEA')
# load('./ssgsea.RData')
# 
# group <- read.csv('../00_rawdata/01.group_NSCLC.csv')
# colnames(group) <- c('sample', 'Group')
# tumour.sample <- group$sample[which(group$Group=='Tumor')]
# 
# library(readr)
# dat_OS <- read.csv(file = '../00_rawdata/01.survival_NSCLC.csv', row.names = 1)
# os <- dat_OS
# os <- os[os$sample %in% tumour.sample,]
# 
# ssgsea_result <- ssgsea_score
# ssgsea_result <- data.frame(t(ssgsea_result))
# ssgsea_result$sample <- rownames(ssgsea_result)
# ssgsea_result <- merge(ssgsea_result, group, by.x = 'sample', by.y = 'sample')
# 
# plot.dat <- merge(os, ssgsea_result, by.x = 'sample', by.y = 'sample')
# 
# # # #中位数
# plot.dat$Group <- ifelse(plot.dat$PMRGscore>median(plot.dat$PMRGscore),'High score','Low score')
# 
# #最佳截断值
# library(survminer)
# dat_score <- plot.dat[,c(2,3,4)]
# res.cut <- surv_cutpoint(dat_score,time = 'OS.time',event = 'OS',variables = 'PMRGscore')
# res.cut
# cutpoint <- res.cut$cutpoint[1]
# #0.4429761
# plot.dat$Group <- ifelse(plot.dat$PMRGscore>cutpoint$cutpoint,'High score','Low score')
# 
# library(survival)
# library(survminer)
# plot.dat$Group <- factor(plot.dat$Group, levels = c('High score','Low score'))
# kmfit <- survfit(Surv(OS.time,OS) ~ Group, data = plot.dat)
# KM <- ggsurvplot(kmfit,
#                  pval = TRUE, 
#                  conf.int = F, #置信区间
#                  legend.labs = c("High score","Low score" ), #图例标签
#                  legend.title = "Group", #图例标题
#                  title = 'Proline metabolism score_OS', #总标题
#                  font.main = c(15,"bold"), 
#                  risk.table = TRUE,  #风险表格
#                  risk.table.col = "strata",  #风险表格文本颜色
#                  linetype = "strata", 
#                  #surv.median.line = "hv", 
#                  ggtheme = theme_bw(), 
#                  palette = c("#ff8340", "#326e89"))
# 
# print(KM)
# print(KM$plot)
# 
# pdf('02.score_KM.pdf',w=6,h=6,family='Times')
# print(KM)
# dev.off()
# png('02.score_KM.png',w=6,h=6,units='in',res=600,family='Times')
# print(KM)
# dev.off()
# 
# 
# 
# #差异基因 高低分数----------
# 
# rm(list = ls())
# setwd('./')
# if (! dir.exists('./02_ssGSEA')){
#   dir.create('./02_ssGSEA')
# }
# setwd('./02_ssGSEA')
# load('./ssgsea.RData')
# 
# group <- read.csv('../00_rawdata/01.group_GSE221521.csv')
# colnames(group) <- c('sample', 'Group')
# tumour.sample <- group$sample[which(group$Group=='DR')]
# 
# dat_expr <- read.csv(file = '../00_rawdata/01.count_GSE221521.csv', check.names = F, row.names = 1)
# count <- dat_expr[,tumour.sample]
# count <- round(count, digits = 0) #保留整数，再次确认，DESeq2要求是整数
# 
# ssgsea_result <- ssgsea_score
# ssgsea_result <- data.frame(t(ssgsea_result))
# ssgsea_result$sample <- rownames(ssgsea_result)
# ssgsea_result <- ssgsea_result[tumour.sample,]
# 
# # #中位数
# ssgsea_result$Group <- ifelse(ssgsea_result$NADscore>median(ssgsea_result$NADscore),'HighScore','LowScore')
# 
# # #最佳截断值
# # cutpoint <- 0.4429761
# # ssgsea_result$Group <- ifelse(ssgsea_result$PMRGscore>cutpoint,'HighScore','LowScore')
# 
# group <- data.frame(sample = rownames(ssgsea_result), Type = ssgsea_result$Group)
# table(group$Type)
# # HighScore  LowScore
# # 34         35 
# identical(colnames(count), group$sample)
# library(tidyverse)
# library(lance)
# library(DESeq2)
# group$Type <- factor(group$Type, levels = c('LowScore', 'HighScore')) #创建因子进行分组
# dds <- DESeqDataSetFromMatrix(countData = count, colData = group, design = ~Type) ##创建一个DESeqDataSet对象，将用户参数传递给DESeq2
# dds <- dds[rownames(counts(dds)) > 1,] #筛选表达大于1的，也可以不筛选
# dds <- estimateSizeFactors(dds) #使数据具有可比性
# 
# #差异分析
# 
# dds <- DESeq(dds) #根据设计矩阵拟合差异表达分析模型，结果出的较慢
# ## results提取差异结果
# res <- results(dds, contrast = c('Type', 'HighScore', 'LowScore')) ##进行差异表达分析：使用results函数获取差异表达分析结果，后面的是对照
# res <- res[order(res$padj),] #进行排序
# head(res) ##看一下， Tumor vs Normal
# summary(res) ##summary看一下结果的概要信息
# table(res$padj < 0.05) ##也是看一下
# 
# save.image(file = 'DEGresult_score.RData')
# load('DEGresult_score.RData')
# 
# 
# 
# 
# #差异基因
# DEG <- as.data.frame(res)
# DEG <- na.omit(DEG)
# dim(DEG)
# head(DEG)
# ## 添加change列
# logFC_cutoff <- 0.5
# DEG$change <- as.factor(
#   ifelse(DEG$pvalue < 0.05 & abs(DEG$log2FoldChange) > logFC_cutoff,
#          ifelse(DEG$log2FoldChange > logFC_cutoff, 'UP', 'DOWN'), 'NOT'))
# table(DEG$change)
# #DOWN   NOT    UP
# #40 6711  107 
# DEG_sig <- subset(DEG, DEG$pvalue < 0.05 & abs(DEG$log2FoldChange) >= logFC_cutoff)
# dim(DEG_sig)
# # 147   7
# 
# #保存结果
# DEG_write <- cbind(GeneSymbol = rownames(DEG), DEG) #连接的方式添了一行rownames，避免保存得到的表格列名错行
# write.csv(DEG_write, file = '03.DEG_all_score.csv', quote = F, row.names = F) #不保存row.names
# 
# DEG_sig_write <- cbind(GeneSymbol = rownames(DEG_sig), DEG_sig)
# write.csv(DEG_sig_write, file = '03.DEG_sig_score_plogfc0.5.csv', quote = F, row.names = F)
# 
# #火山图---------
# #devtools::install_github("kongdd/Ipaper")
# library(ggplot2)
# library(ggthemes)
# library(RColorBrewer)
# library(Ipaper)
# library(scales)
# library(ggrepel)
# 
# dat_rep <- rbind(head(DEG_sig[order(DEG_sig$log2FoldChange,decreasing = T),],10),
#                  head(DEG_sig[order(DEG_sig$log2FoldChange,decreasing = F),],10))
# #dat_rep <- dat_rep[order(dat_rep$change, decreasing = F),]
# volcano_plot <- ggplot(data = DEG,
#                        aes(x = log2FoldChange, #aes告诉ggplot()谁是x谁是y，啥颜色等等
#                            y = -log10(padj),
#                            color = change)) +
#   scale_color_manual(values = c("#326e89", "darkgray","#ff8340")) +
#   scale_x_continuous(breaks = c(-7,-5,-1,0,1,7,12,13,16)) +
#   scale_y_continuous(trans = "log1p", #y轴变换函数
#                      breaks = c(0,1,5,10,20,50, 100,200)) +
#   geom_point(size = 1.5, alpha = 0.4, na.rm=T) + #散点图
#   theme_bw(base_size = 12, base_family = "Times") + #默认背景，经典的暗光情节主题。
#   geom_vline(xintercept = c(-1,1), #参考线
#              lty = 4,
#              col = "darkgray",
#              lwd = 0.6)+
#   geom_hline(yintercept = -log10(0.05),
#              lty = 4,
#              col = "darkgray",
#              lwd = 0.6)+
#   theme(legend.position = "right", #图例位置
#         panel.grid = element_blank(),
#         legend.title = element_text(face = "bold",
#                                     color = "black",
#                                     size = 15),
#         legend.text = element_text(face="bold",
#                                    color="black",
#                                    family = "Times",
#                                    size=13),
#         plot.title = element_text(hjust = 0.5),
#         axis.text.x = element_text(face = "bold",
#                                    color = "black",
#                                    size = 15),
#         axis.text.y = element_text(face = "bold",
#                                    color = "black",
#                                    size = 15),
#         axis.title.x = element_text(face = "bold",
#                                     color = "black",
#                                     size = 15),
#         axis.title.y = element_text(face = "bold",
#                                     color = "black",
#                                     size = 15),
#         text = element_text(family = "Times")) +
#   geom_label_repel(
#     data = dat_rep,
#     aes(label = rownames(dat_rep)),
#     max.overlaps = 20,
#     size = 2.5,
#     force= 8, #重叠标签间的排斥力
#     box.padding = unit(0.5, "lines"),
#     min.segment.length = 0,
#     point.padding = unit(0.8, "lines"), segment.color = "black", show.legend = FALSE,family = "Times" )+
#   labs(x = "log2 (Fold Change)",
#        y = "-log10 (adjusted p value)")
# volcano_plot
# ggsave('03.volcano_score.png', volcano_plot,width = 8, height = 6, units='in', dpi = 600)
# ggsave('03.volcano_score.pdf', volcano_plot,width = 8, height = 6)
# 
# 
# ### 热图--------
# library(ComplexHeatmap)
# group <- group %>% as.data.frame()
# group <- group[order(group$Type, decreasing = F),]
# gene.expr <- count[rownames(dat_rep),]
# mat <- gene.expr
# mat <- t(scale(t(gene.expr)))  # 归一化,让数据分布更加均匀
# #df1 <- as.data.frame(mat)
# # 给极大值和极小值赋值，让图片更好看
# mat[mat < (-2)] <- -2
# mat[mat > 2] <- 2
# # 热图的注释信息
# annotation_col <- data.frame(row.names=group$sample, Group=group$Type)
# annotation_row <- data.frame(row.names=rownames(dat_rep),sig=dat_rep$log2FoldChange)
# annotation_row <- annotation_row[order(annotation_row$sig, decreasing = F),,drop=F] #drop保留之前的数据类型
# mat <- mat[rownames(annotation_row),]
# #mat <- mat[rownames(dat_rep),]
# library(circlize)
# pdf('03.heatmap_score.pdf', w=6,h=6,family='Times')
# col_fun<-colorRamp2(c(-2,0,2),c("#3366CC", "white","#cf3734"))
# densityHeatmap(mat ,title = "Distribution as heatmap", ylab = " ",height = unit(6, "cm")) %v%
#   HeatmapAnnotation(Group = annotation_col$Group, col = list(Group = c("HighScore" = "#cf3734", "LowScore" = "#0405dc"))) %v%
#   Heatmap(mat, row_names_gp = gpar(fontsize = 9),
#           show_column_names = F,name = "expression",
#           height = unit(6, "cm"),
#           cluster_columns = FALSE,
#           cluster_rows = FALSE,
#           col = col_fun)
# dev.off()
# 
# png('03.heatmap_score.png',w=6,h=6,units='in',res=600,family='Times')
# col_fun<-colorRamp2(c(-2,0,2),c("#3366CC", "white","#cf3734"))
# densityHeatmap(mat ,title = "Distribution as heatmap", ylab = " ",height = unit(6, "cm")) %v%
#   HeatmapAnnotation(Group = annotation_col$Group, col = list(Group = c("HighScore" = "#cf3734", "LowScore" = "#0405dc"))) %v%
#   Heatmap(mat, row_names_gp = gpar(fontsize = 9),
#           show_column_names = F,name = "expression",
#           height = unit(6, "cm"),
#           cluster_columns = FALSE,
#           cluster_rows = FALSE,
#           col = col_fun)
# dev.off()


# #相关性-----------------------------------------------------------------
# rm(list = ls())
# setwd("./")
# if (! dir.exists("./02_ssGSEA/")){
#   dir.create("./02_ssGSEA")
# }
# setwd("./02_ssGSEA")
# 
# load('./ssgsea.RData')
# ssgsea_result <- ssgsea_score
# ssgsea_result <- data.frame(t(ssgsea_result))
# 
# gene<-read.csv('../01_DEG/01.DEG_sig_plogfc0.5.csv')
# expr<-read.csv('../00_rawdata/01.fpkm.log_GSE221521.csv',row.names = 1)
# gene.expr <- t(expr[gene$GeneSymbol,]) %>% as.data.frame()
# 
# identical(rownames(gene.expr),rownames(ssgsea_result))
# 
# library(psych)
# y <-gene.expr
# x <-ssgsea_result
# identical(rownames(x),rownames(y))
# 
# library(psych)
# d <- corr.test(x,y,use="complete",method = 'spearman')
# r <- t(data.frame(d$r))
# #rownames(r)<-colnames(y)
# #rownames(r)<-colnames(res2 )
# p <- t(data.frame(d$p))
# #rownames(p)<-colnames(y)
# #rownames(p)<-colnames(res2 )
# identical(rownames(r),rownames(p))
# # corrp <- cbind(r,p)
# # colnames(corrp) <- c('r','p')
# # write.csv(corrp,file="01.risk_IC50_cor.csv",quote=F)
# #write.csv(r,file="01.risk_IC50_cor_r.csv",quote=F)
# ##https:/www.jianshu.com/p/383c11d64267
# 
# dat.r <- data.frame(r)
# dat.r$gene <- rownames(dat.r)
# dat.r <- gather(dat.r,'NADscore','r',-c(gene))
# 
# dat.p <- data.frame(p)
# dat.p$gene <- rownames(dat.p)
# dat.p <- gather(dat.p,'NADscore','p',-c(gene))
# corrp <- (cbind(dat.r, dat.p))[,c("gene","NADscore",'r',"p")]
# corrp$change <- as.factor(ifelse(corrp$p < 0.05 & abs(corrp$r) > 0.4,
#                                  ifelse(corrp$r > 0.4, 'Positive correlation', 'Negative correlation'), 'NOT'))
# #write.csv(corrp,file="01.risk_IC50_cor.csv",quote=F)
# 
# corrp.0.05.0.3 <- corrp %>% as.data.frame()
# corrp.0.05.0.3 <- corrp.0.05.0.3[corrp.0.05.0.3$p<0.05,]
# corrp.0.05.0.3 <- corrp.0.05.0.3[abs(corrp.0.05.0.3$r)>0.4,]
# table(corrp.0.05.0.3$change)
# dim(corrp.0.05.0.3)
# #77  5
# write.csv(corrp.0.05.0.3,file="03.cor_0.4.csv",quote=F)
# 
# # top <- rbind(head(corrp.0.05.0.3[order(corrp.0.05.0.3$r,decreasing = T),],10),
# #              head(corrp.0.05.0.3[order(corrp.0.05.0.3$r,decreasing = F),],10)
# # )
# # top <- corrp.0.05.0.3
#包列表----
pkgs<-lapply(sessionInfo()$otherPkgs,function(x){x$Version}) %>% as.data.frame() %>%t()
write.table(pkgs,'pkgs.tsv',quote = F,sep = '\t',col.names=F)
