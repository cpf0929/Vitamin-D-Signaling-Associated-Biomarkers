##GSE221521表达---------------
rm(list = ls())
setwd('./')
if (! dir.exists("./06_expression")){
  dir.create("./06_expression")
}
setwd("./06_expression")

library(tidyverse)
gene.all <- read.csv('../05_lasso_svmrfe_boruta/05.candidate_genes4expression.csv',header = F) %>% as.data.frame()
dat<-read.csv('../00_rawdata/01.fpkm.log_GSE221521.csv',row.names = 1,check.names = F)
group <- read.csv('../00_rawdata/01.group_GSE221521.csv')
#group$Type <- ifelse(group$type == 'SKCM', 'SKCM', 'control') 
colnames(group) <- c('sample', 'group')

table(group$group)
#50      69
hub_exp<-dat[gene.all$V1,group$sample]
hub_exp2<-hub_exp
#identical(stat.test$drug,colnames(hub_exp2))
hub_exp2$Symbol<-rownames(hub_exp2)
hub_exp2<-gather(hub_exp2,
                 key = sample,
                 value = expr,
                 -c("Symbol"))

control.sample <- group$sample[which(group$group=='control')]
## 样本分组
hub_exp2$Group<-ifelse(hub_exp2$sample%in%control.sample,'control','DR')
##分面图形
library(ggplot2)
library(tidyverse)
library(ggpubr)
library(ggsci)
library(rstatix)
stat.test<-hub_exp2%>%
  group_by(Symbol)%>%
  wilcox_test(expr ~ Group)%>%
  adjust_pvalue(method = 'fdr')

diff <- read.csv('../01_DEG/01.DEG_sig_plogfc0.5.csv',row.names = 1)
df<-diff[stat.test$Symbol,]
stat.test$change<-df$change#%>%as.numeric()%>%round(digits = 3)
stat.test$p<-df$pvalue
stat.test$p1<-ifelse(stat.test$p<0.0001,"****",
                     ifelse(stat.test$p<0.001,"***",
                            ifelse(stat.test$p<0.01,"**",
                                   ifelse(stat.test$p<0.05,"*",'ns'))))
library(ggplot2)
library(ggpubr)
hub_exp2$Group <- factor(hub_exp2$Group,levels = c('control','DR'))
yposit<-hub_exp2  %>% mutate(top=max(expr),.by = Symbol) %>% dplyr::select(Symbol,top)%>% unique()
yposit$top<-yposit$top*1.1
rownames(stat.test)<-stat.test$Symbol
stat.test<-stat.test[yposit$Symbol,] #要按yposit中的symbol排序
exp_plot <- ggplot(hub_exp2,aes(x = Group, y = expr, color = Group)) +
  #geom_violin(trim=F,color='black',aes(fill=Group)) + #绘制小提琴图, “color=”设置小提琴图的轮廓线的颜色(#不要轮廓可以设为white以下设为背景为白色，其实表示不要轮廓线)
  #"trim"如果为TRUE(默认值),则将小提琴的尾部修剪到数据范围。如果为FALSE,不修剪尾部。
  stat_boxplot(geom="errorbar", 
               width=0.2,
               color="black",
               position = position_dodge(0.9)) +
  geom_boxplot(width=0.8,
               aes(fill=Group),
               color="black",
               position=position_dodge(0.9),
               outlier.shape = NA)+ #绘制箱线图，此处width=0.1控制小提琴图中箱线图的宽窄
  geom_point(#aes(fill = Group),
    size = 0.2,
    color="black",
    position = 'jitter'
    #position = position_dodge(0.1)
  )+
  scale_fill_manual(values= c("#569dcb","#f49c4d"), name = "Group")+
  labs(title="Expression in GSE221521", x="", y = "",size=20) +
  scale_colour_manual(values = c("#569dcb","#f49c4d"))+
  # scale_color_brewer(palette = 'Set2')+
  # stat_compare_means(aes(group = Group,label = "p.format"),
  #                    method = "wilcox.test",label = 'p.signif',label.x = 1.4)+
  stat_pvalue_manual(stat.test,
                     y.position = yposit$top,#c(2,2.2,7,7.3,7.3),
                     size = 3.2,
                     family = "Times",
                     label = "p1",  #选择差异分析中的结果或者w检验
                     #parse = T,
                     face = "bold")+
  theme_bw()+
  theme(plot.title = element_text(hjust =0.5,colour="black",face="bold",size=15),
        axis.text.x=element_text(angle=0,hjust=0.5,colour="black",face="bold",size=12), 
        axis.text.y=element_text(hjust=0.5,colour="black",face="bold",size=12), 
        axis.title.x=element_text(size=16,face="bold"),
        axis.title.y=element_text(size=16,face="bold"),
        legend.text=element_text(face = "bold", hjust = 0.5,colour="black", size=12),
        legend.title = element_text(face = "bold", size = 12),
        legend.position = "top",
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        text=element_text(family='Times'))+
  facet_wrap(~Symbol,scales = "free",nrow = 1,strip.position = "top") 
exp_plot
ggsave(filename = '01.expression_GSE221521.pdf',exp_plot,w=28,h=5)
ggsave(filename = '01.expression_GSE221521.png',exp_plot,w=28,h=5,dpi = 600)


#验证 GSE189005-----------

setwd("./")
if (! dir.exists("./06_expression")){
  dir.create("./06_expression")
}
setwd("./06_expression")

library(tidyverse)
gene.all <- read.csv('../05_lasso_svmrfe_boruta/05.candidate_genes.csv',header = F) %>% as.data.frame()
dat<-read.csv('../00_rawdata/02.expr_GSE189005.csv',row.names = 1,check.names = F)
group <- read.csv('../00_rawdata/02.group_GSE189005.csv')
colnames(group) <- c('sample', 'group')

table(group$group)
# 9      10 
hub_exp<-dat[gene.all$V1,group$sample] %>% na.omit()
hub_exp2<-hub_exp
#identical(stat.test$drug,colnames(hub_exp2))
hub_exp2$Symbol<-rownames(hub_exp2)
hub_exp2<-gather(hub_exp2,
                 key = sample,
                 value = expr,
                 -c("Symbol"))

control.sample <- group$sample[which(group$group=='control')]
## 样本分组
hub_exp2$Group<-ifelse(hub_exp2$sample%in%control.sample,'control','DR')
##分面图形
library(ggplot2)
library(tidyverse)
library(ggpubr)
library(ggsci)
library(rstatix)
stat.test<-hub_exp2%>%
  group_by(Symbol)%>%
  wilcox_test(expr ~ Group)%>%
  adjust_pvalue(method = 'fdr')

# diff <- read.csv('../04_DEG.limma/01.DEG_all.csv',row.names = 1)
# df<-diff[stat.test$Symbol,]
# stat.test$change<-df$change#%>%as.numeric()%>%round(digits = 3)
# stat.test$p<-df$P.Value
stat.test$p1<-ifelse(stat.test$p<0.0001,"****",
                     ifelse(stat.test$p<0.001,"***",
                            ifelse(stat.test$p<0.01,"**",
                                   ifelse(stat.test$p<0.05,"*",'ns'))))
library(ggplot2)
library(ggpubr)
hub_exp2$Group <- factor(hub_exp2$Group,levels = c('control','DR'))
yposit<-hub_exp2  %>% mutate(top=max(expr),.by = Symbol) %>% dplyr::select(Symbol,top)%>% unique()
yposit$top<-yposit$top*1.1
rownames(stat.test)<-stat.test$Symbol
stat.test<-stat.test[yposit$Symbol,] #要按yposit中的symbol排序
exp_plot1 <- ggplot(hub_exp2,aes(x = Group, y = expr, color = Group)) +
  #geom_violin(trim=F,color='black',aes(fill=Group)) + #绘制小提琴图, “color=”设置小提琴图的轮廓线的颜色(#不要轮廓可以设为white以下设为背景为白色，其实表示不要轮廓线)
  #"trim"如果为TRUE(默认值),则将小提琴的尾部修剪到数据范围。如果为FALSE,不修剪尾部。
  stat_boxplot(geom="errorbar", 
               width=0.2,
               color="black",
               position = position_dodge(0.9)) +
  geom_boxplot(width=0.8,
               aes(fill=Group),
               color="black",
               position=position_dodge(0.9),
               outlier.shape = NA)+ #绘制箱线图，此处width=0.1控制小提琴图中箱线图的宽窄
  geom_point(#aes(fill = Group),
    size = 0.2,
    color="black",
    position = 'jitter'
    #position = position_dodge(0.1)
  )+
  scale_fill_manual(values= c("#569dcb","#f49c4d"), name = "Group")+
  labs(title="Expression in GSE189005", x="", y = "",size=20) +
  scale_colour_manual(values = c("#569dcb","#f49c4d"))+
  # scale_color_brewer(palette = 'Set2')+
  # stat_compare_means(aes(group = Group,label = "p.format"),
  #                    method = "wilcox.test",label = 'p.signif',label.x = 1.4)+
  stat_pvalue_manual(stat.test,
                     y.position = yposit$top, #c(7.2,7,10.4,11),
                     size = 3.2,
                     family = "Times",
                     label = "p1",  #选择差异分析中的结果或者w检验
                     #parse = T,
                     face = "bold")+
  theme_bw()+
  theme(plot.title = element_text(hjust =0.5,colour="black",face="bold",size=15),
        axis.text.x=element_text(angle=0,hjust=0.5,colour="black",face="bold",size=12), 
        axis.text.y=element_text(hjust=0.5,colour="black",face="bold",size=12), 
        axis.title.x=element_text(size=16,face="bold"),
        axis.title.y=element_text(size=16,face="bold"),
        legend.text=element_text(face = "bold", hjust = 0.5,colour="black", size=12),
        legend.title = element_text(face = "bold", size = 12),
        legend.position = "top",
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        text=element_text(family='Times'))+
  facet_wrap(~Symbol,scales = "free",nrow = 1,strip.position = "top") 
exp_plot1
ggsave(filename = '02.expression_GSE189005.pdf',exp_plot1,w=28,h=5)
ggsave(filename = '02.expression_GSE189005.png',exp_plot1,w=28,h=5,dpi = 600)

#验证 GSE185011-----------

setwd('./')
if (! dir.exists("./06_expression")){
  dir.create("./06_expression")
}
setwd("./06_expression")

library(tidyverse)
gene.all <- gene.all <- read.csv('../05_lasso_svmrfe_boruta/05.candidate_genes.csv',header = F) %>% as.data.frame()
# dat<-read.csv('../00_rawdata/02.expr_GSE189005.csv',row.names = 1,check.names = F)
# group <- read.csv('../00_rawdata/02.group_GSE189005.csv')
dat<-read.csv('../00_rawdata/GSE185011/dat.GSE185011_fpkm.csv',row.names = 1,check.names = F)
group <- read.csv('../00_rawdata/GSE185011/group.GSE185011.csv')          
colnames(group) <- c('sample', 'group')

table(group$group)
#5 5
hub_exp<-dat[gene.all$V1,group$sample] %>% na.omit()
hub_exp2<-hub_exp
#identical(stat.test$drug,colnames(hub_exp2))
hub_exp2$Symbol<-rownames(hub_exp2)
hub_exp2<-gather(hub_exp2,
                 key = sample,
                 value = expr,
                 -c("Symbol"))

control.sample <- group$sample[which(group$group=='control')]
## 样本分组
hub_exp2$Group<-ifelse(hub_exp2$sample%in%control.sample,'control','DR')
##分面图形
library(ggplot2)
library(tidyverse)
library(ggpubr)
library(ggsci)
library(rstatix)
stat.test<-hub_exp2%>%
  group_by(Symbol)%>%
  wilcox_test(expr ~ Group)%>%
  adjust_pvalue(method = 'fdr')

# diff <- read.csv('../04_DEG.limma/01.DEG_all.csv',row.names = 1)
# df<-diff[stat.test$Symbol,]
# stat.test$change<-df$change#%>%as.numeric()%>%round(digits = 3)
# stat.test$p<-df$P.Value
stat.test$p1<-ifelse(stat.test$p<0.0001,"****",
                     ifelse(stat.test$p<0.001,"***",
                            ifelse(stat.test$p<0.01,"**",
                                   ifelse(stat.test$p<0.05,"*",'ns'))))
library(ggplot2)
library(ggpubr)
hub_exp2$Group <- factor(hub_exp2$Group,levels = c('control','DR'))
yposit<-hub_exp2  %>% mutate(top=max(expr),.by = Symbol) %>% dplyr::select(Symbol,top)%>% unique()
yposit$top<-yposit$top*1.1
rownames(stat.test)<-stat.test$Symbol
stat.test<-stat.test[yposit$Symbol,] #要按yposit中的symbol排序
exp_plot2 <- ggplot(hub_exp2,aes(x = Group, y = expr, color = Group)) +
  #geom_violin(trim=F,color='black',aes(fill=Group)) + #绘制小提琴图, “color=”设置小提琴图的轮廓线的颜色(#不要轮廓可以设为white以下设为背景为白色，其实表示不要轮廓线)
  #"trim"如果为TRUE(默认值),则将小提琴的尾部修剪到数据范围。如果为FALSE,不修剪尾部。
  stat_boxplot(geom="errorbar", 
               width=0.2,
               color="black",
               position = position_dodge(0.9)) +
  geom_boxplot(width=0.8,
               aes(fill=Group),
               color="black",
               position=position_dodge(0.9),
               outlier.shape = NA)+ #绘制箱线图，此处width=0.1控制小提琴图中箱线图的宽窄
  geom_point(#aes(fill = Group),
    size = 0.2,
    color="black",
    position = 'jitter'
    #position = position_dodge(0.1)
  )+
  scale_fill_manual(values= c("#569dcb","#f49c4d"), name = "Group")+
  scale_colour_manual(values = c("#569dcb","#f49c4d"))+
  # scale_color_brewer(palette = 'Set2')+
  # stat_compare_means(aes(group = Group,label = "p.format"),
  #                    method = "wilcox.test",label = 'p.signif',label.x = 1.4)+
  stat_pvalue_manual(stat.test,
                     y.position = yposit$top, #c(7.2,7,10.4,11),
                     size = 3.2,
                     family = "Times",
                     label = "p1",  #选择差异分析中的结果或者w检验
                     #parse = T,
                     face = "bold")+
  labs(title="Expression in GSE185011", x="", y = "",size=20) +
  theme_bw()+
  theme(plot.title = element_text(hjust =0.5,colour="black",face="bold",size=15),
        axis.text.x=element_text(angle=0,hjust=0.5,colour="black",face="bold",size=12), 
        axis.text.y=element_text(hjust=0.5,colour="black",face="bold",size=12), 
        axis.title.x=element_text(size=16,face="bold"),
        axis.title.y=element_text(size=16,face="bold"),
        legend.text=element_text(face = "bold", hjust = 0.5,colour="black", size=12),
        legend.title = element_text(face = "bold", size = 12),
        legend.position = "top",
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        text=element_text(family='Times'))+
  facet_wrap(~Symbol,scales = "free",nrow = 1,strip.position = "top") 
exp_plot2
ggsave(filename = '02.expression_GSE185011.pdf',exp_plot2,w=24,h=5)
ggsave(filename = '02.expression_GSE185011.png',exp_plot2,w=24,h=5,dpi = 600)
library(patchwork)
ggsave(filename = '02.exp_merge.png',exp_plot/exp_plot1,w=24,h=10,dpi = 600)
ggsave(filename = '02.exp_merge.pdf',exp_plot/exp_plot1,w=24,h=10)


#目标基因图--------
gene <- c('SLC36A1','RAB23')
write.csv(gene,'03.hubgene.csv')
gene.all<-as.data.frame(gene)
colnames(gene.all)<-'V1'
#目标基因图GSE221521--------

dat<-read.csv('../00_rawdata/01.fpkm_GSE221521.csv',row.names = 1,check.names = F)
group <- read.csv('../00_rawdata/01.group_GSE221521.csv')
#group$Type <- ifelse(group$type == 'SKCM', 'SKCM', 'control') 
colnames(group) <- c('sample', 'group')

table(group$group)
#50      69
hub_exp<-dat[gene.all$V1,group$sample]
hub_exp2<-hub_exp
#identical(stat.test$drug,colnames(hub_exp2))
hub_exp2$Symbol<-rownames(hub_exp2)
hub_exp2<-gather(hub_exp2,
                 key = sample,
                 value = expr,
                 -c("Symbol"))

control.sample <- group$sample[which(group$group=='control')]
## 样本分组
hub_exp2$Group<-ifelse(hub_exp2$sample%in%control.sample,'control','DR')
##分面图形
library(ggplot2)
library(tidyverse)
library(ggpubr)
library(ggsci)
library(rstatix)
stat.test<-hub_exp2%>%
  group_by(Symbol)%>%
  wilcox_test(expr ~ Group)%>%
  adjust_pvalue(method = 'fdr')

diff <- read.csv('../01_DEG/01.DEG_sig_plogfc0.5.csv',row.names = 1)
df<-diff[stat.test$Symbol,]
stat.test$change<-df$change#%>%as.numeric()%>%round(digits = 3)
stat.test$p<-df$pvalue
stat.test$p1<-ifelse(stat.test$p<0.0001,"****",
                     ifelse(stat.test$p<0.001,"***",
                            ifelse(stat.test$p<0.01,"**",
                                   ifelse(stat.test$p<0.05,"*",'ns'))))
library(ggplot2)
library(ggpubr)
hub_exp2$Group <- factor(hub_exp2$Group,levels = c('control','DR'))
yposit<-hub_exp2  %>% mutate(top=max(expr),.by = Symbol) %>% dplyr::select(Symbol,top)%>% unique()
yposit$top<-yposit$top*1.1
rownames(stat.test)<-stat.test$Symbol
stat.test<-stat.test[yposit$Symbol,] #要按yposit中的symbol排序
exp_plot <- ggplot(hub_exp2,aes(x = Group, y = expr, color = Group)) +
  #geom_violin(trim=F,color='black',aes(fill=Group)) + #绘制小提琴图, “color=”设置小提琴图的轮廓线的颜色(#不要轮廓可以设为white以下设为背景为白色，其实表示不要轮廓线)
  #"trim"如果为TRUE(默认值),则将小提琴的尾部修剪到数据范围。如果为FALSE,不修剪尾部。
  stat_boxplot(geom="errorbar", 
               width=0.2,
               color="black",
               position = position_dodge(0.9)) +
  geom_boxplot(width=0.8,
               aes(fill=Group),
               color="black",
               position=position_dodge(0.9),
               outlier.shape = NA)+ #绘制箱线图，此处width=0.1控制小提琴图中箱线图的宽窄
  geom_point(#aes(fill = Group),
    size = 0.2,
    color="black",
    position = 'jitter'
    #position = position_dodge(0.1)
  )+
  scale_fill_manual(values= c("#569dcb","#f49c4d"), name = "Group")+
  labs(title="Expression in GSE221521", x="", y = "",size=20) +
  scale_colour_manual(values = c("#569dcb","#f49c4d"))+
  # scale_color_brewer(palette = 'Set2')+
  # stat_compare_means(aes(group = Group,label = "p.format"),
  #                    method = "wilcox.test",label = 'p.signif',label.x = 1.4)+
  stat_pvalue_manual(stat.test,
                     y.position = yposit$top,#c(2,2.2,7,7.3,7.3),
                     size = 3.2,
                     family = "Times",
                     label = "p1",  #选择差异分析中的结果或者w检验
                     #parse = T,
                     face = "bold")+
  theme_bw()+
  theme(plot.title = element_text(hjust =0.5,colour="black",face="bold",size=15),
        axis.text.x=element_text(angle=0,hjust=0.5,colour="black",face="bold",size=12), 
        axis.text.y=element_text(hjust=0.5,colour="black",face="bold",size=12), 
        axis.title.x=element_text(size=16,face="bold"),
        axis.title.y=element_text(size=16,face="bold"),
        legend.text=element_text(face = "bold", hjust = 0.5,colour="black", size=12),
        legend.title = element_text(face = "bold", size = 12),
        legend.position = "top",
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        text=element_text(family='Times'))+
  facet_wrap(~Symbol,scales = "free",nrow = 1,strip.position = "top") 
#目标基因图GSE189005--------
dat<-read.csv('../00_rawdata/02.expr_GSE189005.csv',row.names = 1,check.names = F)
group <- read.csv('../00_rawdata/02.group_GSE189005.csv')
colnames(group) <- c('sample', 'group')

table(group$group)
# 9      10 
hub_exp<-dat[gene.all$V1,group$sample] %>% na.omit()
hub_exp2<-hub_exp
#identical(stat.test$drug,colnames(hub_exp2))
hub_exp2$Symbol<-rownames(hub_exp2)
hub_exp2<-gather(hub_exp2,
                 key = sample,
                 value = expr,
                 -c("Symbol"))

control.sample <- group$sample[which(group$group=='control')]
## 样本分组
hub_exp2$Group<-ifelse(hub_exp2$sample%in%control.sample,'control','DR')
##分面图形
library(ggplot2)
library(tidyverse)
library(ggpubr)
library(ggsci)
library(rstatix)
stat.test<-hub_exp2%>%
  group_by(Symbol)%>%
  wilcox_test(expr ~ Group)%>%
  adjust_pvalue(method = 'fdr')

# diff <- read.csv('../04_DEG.limma/01.DEG_all.csv',row.names = 1)
# df<-diff[stat.test$Symbol,]
# stat.test$change<-df$change#%>%as.numeric()%>%round(digits = 3)
# stat.test$p<-df$P.Value
stat.test$p1<-ifelse(stat.test$p<0.0001,"****",
                     ifelse(stat.test$p<0.001,"***",
                            ifelse(stat.test$p<0.01,"**",
                                   ifelse(stat.test$p<0.05,"*",'ns'))))
library(ggplot2)
library(ggpubr)
hub_exp2$Group <- factor(hub_exp2$Group,levels = c('control','DR'))
yposit<-hub_exp2  %>% mutate(top=max(expr),.by = Symbol) %>% dplyr::select(Symbol,top)%>% unique()
yposit$top<-yposit$top*1.1
rownames(stat.test)<-stat.test$Symbol
stat.test<-stat.test[yposit$Symbol,] #要按yposit中的symbol排序
exp_plot1 <- ggplot(hub_exp2,aes(x = Group, y = expr, color = Group)) +
  #geom_violin(trim=F,color='black',aes(fill=Group)) + #绘制小提琴图, “color=”设置小提琴图的轮廓线的颜色(#不要轮廓可以设为white以下设为背景为白色，其实表示不要轮廓线)
  #"trim"如果为TRUE(默认值),则将小提琴的尾部修剪到数据范围。如果为FALSE,不修剪尾部。
  stat_boxplot(geom="errorbar", 
               width=0.2,
               color="black",
               position = position_dodge(0.9)) +
  geom_boxplot(width=0.8,
               aes(fill=Group),
               color="black",
               position=position_dodge(0.9),
               outlier.shape = NA)+ #绘制箱线图，此处width=0.1控制小提琴图中箱线图的宽窄
  geom_point(#aes(fill = Group),
    size = 0.2,
    color="black",
    position = 'jitter'
    #position = position_dodge(0.1)
  )+
  scale_fill_manual(values= c("#569dcb","#f49c4d"), name = "Group")+
  labs(title="Expression in GSE189005", x="", y = "",size=20) +
  scale_colour_manual(values = c("#569dcb","#f49c4d"))+
  # scale_color_brewer(palette = 'Set2')+
  # stat_compare_means(aes(group = Group,label = "p.format"),
  #                    method = "wilcox.test",label = 'p.signif',label.x = 1.4)+
  stat_pvalue_manual(stat.test,
                     y.position = yposit$top, #c(7.2,7,10.4,11),
                     size = 3.2,
                     family = "Times",
                     label = "p1",  #选择差异分析中的结果或者w检验
                     #parse = T,
                     face = "bold")+
  theme_bw()+
  theme(plot.title = element_text(hjust =0.5,colour="black",face="bold",size=15),
        axis.text.x=element_text(angle=0,hjust=0.5,colour="black",face="bold",size=12), 
        axis.text.y=element_text(hjust=0.5,colour="black",face="bold",size=12), 
        axis.title.x=element_text(size=16,face="bold"),
        axis.title.y=element_text(size=16,face="bold"),
        legend.text=element_text(face = "bold", hjust = 0.5,colour="black", size=12),
        legend.title = element_text(face = "bold", size = 12),
        legend.position = "top",
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        text=element_text(family='Times'))+
  facet_wrap(~Symbol,scales = "free",nrow = 1,strip.position = "top")
ggsave(filename = '03.hubgene.png',exp_plot+exp_plot1,w=10,h=6,dpi = 600)
ggsave(filename = '03.hubgene.pdf',exp_plot+exp_plot1,w=10,h=6)
#包列表----
pkgs<-lapply(sessionInfo()$otherPkgs,function(x){x$Version}) %>% as.data.frame() %>%t()
write.table(pkgs,'pkgs.tsv',quote = F,sep = '\t',col.names=F)
