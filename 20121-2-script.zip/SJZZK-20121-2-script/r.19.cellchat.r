#08 cellchat----
rm(list = ls())
source('../../../notice.r')
setwd("./")
if (! dir.exists("./14.scRNA")){
  dir.create("./14.scRNA")
}
setwd("./14.scRNA")
if (! dir.exists("./08_cellchat")){
  dir.create("./08_cellchat")
}
setwd("./08_cellchat")

library(CellChat)
library(Seurat)
library(tidyverse)
library(harmony)
library(tidyverse)
library(patchwork)
library(ggplot2)
library(cowplot)
library(dplyr)
library(data.table)
library(Seurat)
library(ggsci)
scRNA<-readRDS('../06_cell_annot/UMAP.celltype.rds')

#scRNA <- JoinLayers(scRNA)
#data.input = as.data.frame(LayerData(scRNA, layer = "data", assay = "RNA"))
data.input<-scRNA@assays$RNA$data # normalized data matrix
meta = scRNA@meta.data # a dataframe with rownames containing cell mata data
meta%<>%filter(!celltype %in% c('other cells',"T&NK cells")) %>% droplevels()#去掉未注释的细胞

cell.use = rownames(meta)
data.input = data.input[, cell.use]
table(meta$celltype)
unique(meta$celltype)
##CellChat的输入需要的matrix和meta我们已经准备好，下面开始创建
cellchat <- createCellChat(object = data.input, meta = meta, group.by = "celltype",)
cellchat <- addMeta(cellchat, meta = meta)##增加其他meta信息9
cellchat <- setIdent(cellchat, ident.use = "celltype") # 将 "labels" 设为默认细胞标记类型，这个可以根据自己的数据自定义
levels(cellchat@idents)
unique(cellchat@idents)
cellchat@idents<-droplevels(cellchat@idents,exclude=setdiff(levels(cellchat@idents),unique(cellchat@idents)))

groupSize <- as.numeric(table(cellchat@idents)) # 每组细胞的数量
##基于配受体分析的数据库
CellChatDB <- CellChatDB.human # 包括人和老鼠的
showDatabaseCategory(CellChatDB)###作者提供了可视化的代码，可以看到该数据库中“Secreted Signaling”占比过半
library(tidyverse)
dplyr::glimpse(CellChatDB$interaction)  ###看一下CellChatDB的基本结构
CellChatDB_interaction <- CellChatDB$interaction
#CellChatDB.use <- subsetDB(CellChatDB, search = "Secreted Signaling") # 我们这里使用“Secreted Signaling”部分做后续的细胞通讯分析
cellchat@DB <- CellChatDB
cellchat <- subsetData(cellchat)
cellchat <- identifyOverExpressedGenes(cellchat)#鉴定过表达基因
cellchat <- identifyOverExpressedInteractions(cellchat)###然后识别过表达配受体之间过表达的相互作用
cellchat <- projectData(cellchat, PPI.human)#将基因表达数据映射PPT互作网络#多线程
##计算胞间通讯概率，预测通讯网络
cellchat <- computeCommunProb(cellchat)#单线程，时间长
#triMean is used for calculating the average gene expression per cell group. 
#[1] ">>> Run CellChat on sc/snRNA-seq data <<< [2024-05-30 21:01:58]"
notify('computeCommunProb')
cellchat <- filterCommunication(cellchat, min.cells = 1)#过滤掉低于min.cells的细胞类型
#cellchat <- computeCommunProbPathway(cellchat)#计算pathway水平的互作概率，通过总结所有的配受体对
##计算pathway水平的互作概率，通过总结所有的配受体对,信号通路的水平进一步推测胞间通讯，计算聚合网络
cellchat <- computeCommunProbPathway(cellchat)
cellchat <- aggregateNet(cellchat)#得到整体细胞互作网络
cellchat@netP$pathways#显示具体对应pathways
saveRDS(cellchat,file = 'cellchat.rds')
##胞间通讯网络的输出代码
df.net <- subsetCommunication(cellchat)
df.net$interaction_name_2%>%unique()%>%length()
#[1] 83 受体配体数量
##可视化细胞互作的结果
groupSize <- as.numeric(table(cellchat@idents))
## 相互作用数目
pdf('03.number_of_interactions.pdf',w=6,h=5,family='serif')
netVisual_heatmap(cellchat)
dev.off()
png('03.number_of_interactions.png',w=500,h=400,family='serif')
netVisual_heatmap(cellchat)
dev.off()

#### circle
pdf('01.net_number.pdf',w=7,h=9,family='serif')
netVisual_circle(cellchat@net$count, vertex.weight = groupSize, weight.scale = T, label.edge= F, title.name = "Number of interactions")
dev.off()

png('01.net_number.png',w=7,h=9,units='in',res=600,family='serif')
netVisual_circle(cellchat@net$count, vertex.weight = groupSize, weight.scale = T, label.edge= F, title.name = "Number of interactions")
dev.off()
#
pdf('02.net_weight.pdf',w=7,h=9,family='serif')
netVisual_circle(cellchat@net$weight, vertex.weight = groupSize, weight.scale = T, label.edge= F, title.name = "Interaction weight/strength")
dev.off()

png('02.net_weight.png',w=7,h=9,units='in',res=600,family='serif')
netVisual_circle(cellchat@net$weight, vertex.weight = groupSize, weight.scale = T, label.edge= F, title.name = "Interaction weight/strength")
dev.off()
levels(cellchat@idents)
# show all the significant interactions (L-R pairs)
#需要指定受体细胞和配体细胞
cellchat@data.signaling
pdf('03.buble.pdf',w=10,h=20)
netVisual_bubble(cellchat, remove.isolate = FALSE)
dev.off()
png('03.buble.png',w=9,h=20,units = 'in',res = 300)
netVisual_bubble(cellchat, remove.isolate = FALSE)
dev.off()
#对感兴趣的细胞类型，气泡图显示所有显著LR对
### 指定感兴趣的细胞类型，绘制气泡图，气泡图显示所有显著LR对
### sources.use 指定感兴趣的发送信号的细胞类型；targets.use 指定接受信号的细胞类型
### remove.isolate代表去除没有配受体的细胞互作
#关键细胞
keycells<-c('B cells','classical monocytes')
netVisual_bubble(cellchat, sources.use = keycells,  remove.isolate = FALSE)
ggsave(filename = '05.cellchat_LR_Bubble_keycells_as_lig.pdf',w=6,h=10)
ggsave(filename = '05.cellchat_LR_Bubble_keycells_as_lig.png',w=6,h=10)
netVisual_bubble(cellchat, targets.use = keycells,  remove.isolate = FALSE)
ggsave(filename = '05.cellchat_LR_Bubble_keycells_as_Rec.pdf',w=6,h=9)
ggsave(filename = '05.cellchat_LR_Bubble_keycells_as_Rec.png',w=6,h=9)
mat <- cellchat@net$count
pdf('04.single_circle.pdf',w=8,h=8)
par(mfrow=c(3,3),xpd=T)
#par(mar=c(1,1,1,1))
for (i in 1:nrow(mat)) {
  mat2 <- matrix(0,nrow = nrow(mat),ncol = ncol(mat),dimnames = dimnames(mat))
  mat2[i,] <- mat[i,]
  netVisual_circle(mat2,vertex.weight = groupSize,weight.scale = T,arrow.width = 0.2,
                   arrow.size = 0.1,edge.weight.max = max(mat),title.name = rownames(mat)[i])
}
dev.off()
#

png('04.single_circle.png',w=800,h=500)
par(mfrow=c(3,3),xpd=T)
#par(mar=c(1,1,1,1))
for (i in 1:nrow(mat)) {
  mat2 <- matrix(0,nrow = nrow(mat),ncol = ncol(mat),dimnames = dimnames(mat))
  mat2[i,] <- mat[i,]
  netVisual_circle(mat2,vertex.weight = groupSize,weight.scale = T,arrow.width = 0.2,
                   arrow.size = 0.1,edge.weight.max = max(mat),title.name = rownames(mat)[i])
}
dev.off()
